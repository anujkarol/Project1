import { IRequestUser } from '../reducers/interface';
import * as constants from '../../redux/constants';

interface IAddUser {
  type: typeof constants.ADMIN_ADD_USER;
  payload: FormData;
}

interface IAddUserSuccess {
  type: typeof constants.ADMIN_ADD_USER_SUCCESS;
  status: string;
  message: string;
}

interface IAddUserFailure {
  type: typeof constants.ADMIN_ADD_USER_FAILURE;
  status: string;
  message: string;
}

export interface UploadStart {
  type: typeof constants.UPLOAD;
  file: FormData;
  documentType: string;
  isUploaded: boolean;
}

interface UploadSuccess {
  type: typeof constants.UPLOAD_SUCCESS;
  message: string;
  isUploaded: boolean;
}

interface UploadFailure {
  type: typeof constants.UPLOAD_FAILURE;
  message: string;
  isUploaded: boolean;
}

interface UpdateMessage {
  type: typeof constants.UPDATE_MESSAGE;
  message: string;
}

interface Logout {
  type: typeof constants.LOGOUT;
}

interface LogoutSuccess {
  type: typeof constants.LOGOUT_SUCCESS;
}

interface LogoutFailure {
  type: typeof constants.LOGOUT_FAILURE;
}

export interface DownloadStart {
  type: typeof constants.DOWNLOAD;
  documentType: string;
}

interface DownloadSuccess {
  type: typeof constants.DOWNLOAD_SUCCESS;
  message: string;
}

interface DownloadFailure {
  type: typeof constants.DOWNLOAD_FAILURE;
  message: string;
}

interface IServerCheck {
  type: typeof constants.SERVER_CHECK;
}

interface IServerUp {
  type: typeof constants.SERVER_DOWN;
  message: string;
  isServerDown: boolean;
}

interface IServerDown {
  type: typeof constants.SERVER_UP;
  message: string;
  isServerDown: boolean;
}

export interface EmailListObject {
  staffId: string;
  promoCode: string;
  emailIds: string;
  campaignType: string;
}

export interface EmailListObjectWithId {
  staffId: string;
  promoCode: string;
  emailIds: string;
  campaignType: string;
  id: string;
}
interface EmailList {
  type: typeof constants.EMAIL;
  list: EmailListObject[];
}

interface EmailListSuccess {
  type: typeof constants.EMAIL_SEND_SUCCESS;
  message:string
}

interface EmailListFailure {
  type: typeof constants.EMAIL_SEND_FAILURE;
  message:string
}

interface EmailSendStatus {
  type: typeof constants.EMAIL_SEND_STATUS;
  message:string
}

interface BdeData {
  type: typeof constants.GET_BDE_PARTNER_DATA;
  page: number;
  selectedTab: string;
}

interface BdeDataSuccess {
  type: typeof constants.GET_BDE_PARTNER_DATA_SUCCESS;
  partnerList: object[];
  totalRecords: number;
}

interface BdeDataFailure {
  type: typeof constants.GET_BDE_PARTNER_DATA_FAILURE;
  message: string;
}

interface LoginSubmit {
  type: typeof constants.LOGIN_SUBMIT;
  userName: string;
  password: string;
  
}

interface LoginSuccess {
  type: typeof constants.LOGIN_SUCCESS;
  token: string;
  role:string
}

interface LoginFailure {
  type: typeof constants.LOGIN_FAILURE;
  message: string;
  role:string
}

interface GetPromoCode {
  type: typeof constants.PROMO_CODE;
}

interface GetPromoCodeSuccess {
  type: typeof constants.PROMO_CODE_SUCCESS;
  list: object[];
}
interface GetPromoCodeFailure {
  type: typeof constants.PROMO_CODE_FAILURE;
  message: string;
}

interface GetStaffId {
  type: typeof constants.STAFF_ID;
}

interface GetStaffIdSuccess {
  type: typeof constants.STAFF_ID_SUCCESS;
  list: object[];
}

interface GetStaffIdFailure {
  type: typeof constants.STAFF_ID_FAILURE;
  message: string;
}

interface IVerifyRequest {
  type: typeof constants.VERIFY_1BANKID;
  userId: string;
}

interface IVerifyRequestSuccess {
  type: typeof constants.VERIFY_1BANKID_SUCCESS;
  userName: string;
  message: string;
  isValid1BankId: boolean;
}

interface IVerifyRequestFailure {
  type: typeof constants.VERIFY_1BANKID_FAILURE;
  userName: string;
  message: string;
  isValid1BankId: boolean;
  status: string;
}
interface IAdminUserRequest {
  type: typeof constants.ADMIN_REQUESTED_USER;
  page: number;
}

interface IAdminUserSuccess {
  type: typeof constants.ADMIN_REQUESTED_USER_SUCCESS;
  totalRecords: number;
  users: Array<IRequestUser>;
  message: string;
}

interface IAdminUserFailure {
  type: typeof constants.ADMIN_REQUESTED_USER_FAILURE;
  message: string;
  users: [];
}

export type AddUserActionType =
  | IAdminUserRequest
  | IAdminUserSuccess
  | IAdminUserFailure;
export type IStaffIdAction = GetStaffId | GetStaffIdSuccess | GetStaffIdFailure;

export type IPromoCodeAction =
  | GetPromoCode
  | GetPromoCodeSuccess
  | GetPromoCodeFailure;
export type ILoginAction = LoginSubmit | LoginSuccess | LoginFailure;
export type IBdeDataAction = BdeData | BdeDataSuccess | BdeDataFailure;
export type IEmailActions = EmailList | EmailListSuccess | EmailListFailure | EmailSendStatus;
export type ILogoutAction = Logout | LogoutSuccess | LogoutFailure;
export type IUploadAction =
  | UploadStart
  | UploadSuccess
  | UploadFailure
  | UpdateMessage;
export type IDownloadAction = DownloadStart | DownloadSuccess | DownloadFailure;
export type IServerAction = IServerCheck | IServerUp | IServerDown;
export type IAddUserAction = IAddUser | IAddUserSuccess | IAddUserFailure;

export type VerifyUserAction =
  | IVerifyRequest
  | IVerifyRequestSuccess
  | IVerifyRequestFailure;
