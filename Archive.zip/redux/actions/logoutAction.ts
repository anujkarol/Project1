import { LOGOUT, LOGOUT_FAILURE, LOGOUT_SUCCESS } from '../constants';
import { ILogoutAction } from './interface';

export const logout = (): ILogoutAction => ({
  type: LOGOUT,
});

export const logoutSuccess = (): ILogoutAction => ({
  type: LOGOUT_SUCCESS,
});

export const logoutFailure = (): ILogoutAction => ({
  type: LOGOUT_FAILURE,
});
