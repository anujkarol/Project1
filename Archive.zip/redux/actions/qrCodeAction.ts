import {
  GET_QR_CODE_LIST,
  GET_QR_CODE_LIST_FAILURE,
  GET_QR_CODE_LIST_SUCCESS,
  CLEAR_QR_CODE_LIST,
} from '../constants';

export const generateQrCode = (list: object[] = []): any => ({
  type: GET_QR_CODE_LIST,
  list,
});

export const generateQrCodeSuccess = (list: [] = []): any => ({
  type: GET_QR_CODE_LIST_SUCCESS,
  list,
});

export const clearQrCodeList = (): any => ({
  type: CLEAR_QR_CODE_LIST,
  list: [],
});

export const generateQrCodeFailure = (message: string): any => ({
  type: GET_QR_CODE_LIST_FAILURE,
  message,
});
