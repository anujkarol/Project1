import { DOWNLOAD, DOWNLOAD_FAILURE, DOWNLOAD_SUCCESS } from '../constants';
import { IDownloadAction } from './interface';

export const downloadStart = (documentType: string): IDownloadAction => ({
  type: DOWNLOAD,
  documentType,
});

export const downloadSuccess = (message: string): IDownloadAction => ({
  type: DOWNLOAD_SUCCESS,
  message,
});

export const downloadFailure = (message: string): IDownloadAction => ({
  type: DOWNLOAD_FAILURE,
  message,
});
