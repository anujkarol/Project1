import {
  ADMIN_ADD_USER,
  ADMIN_ADD_USER_FAILURE,
  ADMIN_ADD_USER_SUCCESS,
} from '../constants';
import { IAddUserAction } from './interface';

const addUser = (payload: FormData): IAddUserAction => ({
  type: ADMIN_ADD_USER,
  payload,
});

const addUserSuccess = (): IAddUserAction => ({
  type: ADMIN_ADD_USER_SUCCESS,
  status: 'Check Action',
  message: 'Check Action Message',
});

const addUserFailure = (): IAddUserAction => ({
  type: ADMIN_ADD_USER_FAILURE,
  status: 'Check Action Status',
  message: 'Check Action Message',
});

export const AddUserActions = {
  addUser,
  addUserSuccess,
  addUserFailure,
};
