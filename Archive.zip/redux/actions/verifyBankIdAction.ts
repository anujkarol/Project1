import {
  VERIFY_1BANKID,
  VERIFY_1BANKID_FAILURE,
  VERIFY_1BANKID_SUCCESS,
} from '../constants';

import { VerifyUserAction } from './interface';

const verify1BankIdActionInitiate = (userId: string): VerifyUserAction => ({
  type: VERIFY_1BANKID,
  userId,
});

const verify1BankIdActionSuccess = (
  userName = '',
  message = '',
  isValid1BankId = false,
): VerifyUserAction => ({
  type: VERIFY_1BANKID_SUCCESS,
  userName,
  message,
  isValid1BankId,
});

const verify1BankIdActionFailure = (
  userName = '',
  message = '',
  isValid1BankId = false,
  status = '',
): VerifyUserAction => ({
  type: VERIFY_1BANKID_FAILURE,
  userName,
  message,
  isValid1BankId,
  status,
});

export const verifyBankIdAction = {
  verify1BankIdActionInitiate,
  verify1BankIdActionSuccess,
  verify1BankIdActionFailure,
};
