import { LOGIN_FAILURE, LOGIN_SUBMIT, LOGIN_SUCCESS } from '../constants';
import { ILoginAction } from './interface';

export const loginSubmit = (
  userName: string,
  password: string,
): ILoginAction => ({
  type: LOGIN_SUBMIT,
  userName,
  password,
});

export const loginSuccess = (token: string, role:string='user'): ILoginAction => ({
  type: LOGIN_SUCCESS,
  token,
  role
});

export const loginFailure = (message: string, role:string=''): ILoginAction => ({
  type: LOGIN_FAILURE,
  message,
  role
});
 