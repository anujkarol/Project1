import { SERVER_UP, SERVER_DOWN, SERVER_CHECK } from '../constants';
import { IServerAction } from './interface';

export const serverCheck = (): IServerAction => {
  return { type: SERVER_CHECK };
};
export const serverDownAction = (message: string): IServerAction => {
  return { type: SERVER_DOWN, message, isServerDown: true };
};

export const serverUpAction = (message: string): IServerAction => {
  return { type: SERVER_UP, message, isServerDown: false };
};
