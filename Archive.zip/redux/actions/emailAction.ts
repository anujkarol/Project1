import { EMAIL, EMAIL_SEND_FAILURE, EMAIL_SEND_SUCCESS , EMAIL_SEND_STATUS} from '../constants';
import { IEmailActions, EmailListObject } from './interface';

export const sendEmailList = (list: EmailListObject[] = []): IEmailActions => ({
  type: EMAIL,
  list,
});

export const sendEmailSuccess = (message:string): IEmailActions => ({
  type: EMAIL_SEND_SUCCESS,
  message,
});

export const sendEmailFailure = (message:string): IEmailActions => ({
  type: EMAIL_SEND_FAILURE,
  message
});


export const sendEmailStatus = (message: string): any => ({
  type: EMAIL_SEND_STATUS,
  message,
});
