import { IPromoCodeAction } from './interface';
import {
  PROMO_CODE,
  PROMO_CODE_FAILURE,
  PROMO_CODE_SUCCESS,
} from '../constants';

export const getPromoCode = (): IPromoCodeAction => ({
  type: PROMO_CODE,
});

export const getPromoCodeSuccess = (list: object[]): IPromoCodeAction => ({
  type: PROMO_CODE_SUCCESS,
  list,
});

export const getPromoCodeFailure = (message: string): IPromoCodeAction => ({
  type: PROMO_CODE_FAILURE,
  message,
});
