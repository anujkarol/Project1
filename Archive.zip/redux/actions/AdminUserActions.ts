import { IRequestUser } from '../reducers/interface';
import {
  ADMIN_REQUESTED_USER,
  ADMIN_REQUESTED_USER_FAILURE,
  ADMIN_REQUESTED_USER_SUCCESS,
} from '../constants';

import { AddUserActionType } from './interface';

const requestUserInitiate = (page = 1): AddUserActionType => ({
  type: ADMIN_REQUESTED_USER,
  page,
});

const requestUserSuccess = (
  users: Array<IRequestUser>,
  totalRecords: number,
  message: string,
): any => ({
  type: ADMIN_REQUESTED_USER_SUCCESS,
  users,
  totalRecords,
  message,
});

const requestUserError = (
  message: string,
  users: [] = [],
): AddUserActionType => ({
  type: ADMIN_REQUESTED_USER_FAILURE,
  message,
  users,
});

export const manageUserActions = {
  requestUserInitiate,
  requestUserSuccess,
  requestUserError,
};
