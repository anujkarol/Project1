import {
  GET_BDE_PARTNER_DATA,
  GET_BDE_PARTNER_DATA_FAILURE,
  GET_BDE_PARTNER_DATA_SUCCESS,
} from '../constants';
import { IBdeDataAction } from './interface';

export const getPartnerList = (
  page = 1,
  selectedTab: string,
): IBdeDataAction => ({
  type: GET_BDE_PARTNER_DATA,
  page,
  selectedTab,
});

export const getPartnerListSuccess = (
  partnerList: object[],
  totalRecords: number,
): IBdeDataAction => ({
  type: GET_BDE_PARTNER_DATA_SUCCESS,
  partnerList,
  totalRecords,
});

export const getPartnerListFailure = (message: string): IBdeDataAction => ({
  type: GET_BDE_PARTNER_DATA_FAILURE,
  message,
});
