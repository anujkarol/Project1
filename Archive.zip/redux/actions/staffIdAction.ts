import { IStaffIdAction } from './interface';
import { STAFF_ID, STAFF_ID_FAILURE, STAFF_ID_SUCCESS } from '../constants';
// import { sendEmail, sendEmailSuccess, sendEmailFailure } from './interface';

export const getStaffIdList = (): IStaffIdAction => ({
  type: STAFF_ID,
});

export const getStaffIdListSuccess = (list: object[]): IStaffIdAction => ({
  type: STAFF_ID_SUCCESS,
  list,
});

export const STAFFID_FAILURE = (message: string): IStaffIdAction => ({
  type: STAFF_ID_FAILURE,
  message,
});
