import {
  UPLOAD,
  UPLOAD_FAILURE,
  UPLOAD_SUCCESS,
  UPDATE_MESSAGE,
} from '../constants';
import { IUploadAction } from './interface';

export const uploadStart = (
  file: FormData,
  documentType: string,
  isUploaded = false,
): IUploadAction => ({
  type: UPLOAD,
  file,
  documentType,
  isUploaded,
});

export const uploadSuccess = (
  message: string,
  isUploaded: boolean,
): IUploadAction => ({
  type: UPLOAD_SUCCESS,
  message,
  isUploaded,
});

export const uploadFailure = (
  message: string,
  isUploaded: boolean,
): IUploadAction => ({
  type: UPLOAD_FAILURE,
  message,
  isUploaded,
});

export const updateMessage = (message: string): IUploadAction => ({
  type: UPDATE_MESSAGE,
  message,
});
