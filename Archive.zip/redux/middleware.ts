import { applyMiddleware, compose } from 'redux';

import { createLogger } from 'redux-logger';
import createSagaMiddleware from 'redux-saga';

const ColorsObject = {
  title: () => 'yellow',
  prevState: () => '#9E9E9E',
  action: () => 'white',
  nextState: () => 'cyan',
  error: () => '#ff3333',
};
const loggerMiddleware = createLogger({
  collapsed: true,
  duration: true,
  timestamp: true,
  level: 'info',
  colors: ColorsObject,
  logger: console,
  logErrors: true,
  diff: true,
});
const composeEnhancers =
  (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

export const sagaMiddleware = createSagaMiddleware({
  onError(error) {
    setImmediate(() => {
      console.log('Saga Error handled from Middleware.ts', error);
      throw error;
    });
  },
});

const middleware = [loggerMiddleware, sagaMiddleware];
export const Enhancers = composeEnhancers(applyMiddleware(...middleware));
