import * as constants from '../constants';

import { AddUserActionType } from '../actions/interface';
import { IAdminUserState } from './interface';

const initialState: IAdminUserState = {
  users: [],
  message: '',
  isLoading: false,
  totalRequestedRecordCount: 0,
};

export default function adminUserReducer(
  state = initialState,
  action: AddUserActionType,
) {
  switch (action.type) {
    case constants.ADMIN_REQUESTED_USER:
      return {
        isLoading: true,
      };

    case constants.ADMIN_REQUESTED_USER_SUCCESS:
      return {
        users: action.users,
        message: action.message,
        isLoading: false,
        totalRequestedRecordCount: action.totalRecords,
      };

    case constants.ADMIN_REQUESTED_USER_FAILURE:
      return {
        users: action.users,
        message: action.message,
        isLoading: false,
      };

    default:
      return state;
  }
}
