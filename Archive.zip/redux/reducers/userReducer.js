import * as types from '../constants';

const initialState = {
  items: {
    userGroup: '',
    user1BankId: '',
    userRole: '',
    userRights: [],
    token: '',
  },
};

const UserReducer = (state = { initialState }, action) => {
  switch (action.type) {
    case types.GETALL_REQUEST:
      return {
        loading: true,
      };
    case types.GETALL_SUCCESS:
      return {
        ...state,
        items: action.users,
      };
    case types.GETALL_FAILURE:
      return {
        error: action.error,
      };

    case types.SET_TOKEN:
      return {
        token: action.token,
      };

    default:
      return state;
  }
};

export default UserReducer;
