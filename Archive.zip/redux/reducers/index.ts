import { combineReducers } from 'redux';
import UserReducer from './userReducer';
import adminUserReducer from './adminUserReducer';
import downloadReducer from './downloadReducer';
import emailReducer from './emailReducer';
import getBdeDataReducer from './getBdeDataReducer';
import loginReducer from './loginReducer';
import logoutReducer from './logoutReducer';
import manageAddUserReducer from './addUserReducer';
import promoCodeReducer from './promoCodeReducer';
import qrCodeReducer from './qrCodeReducer';
import serverReducer from './serverReducer';
import staffIdReducer from './staffIdReducer';
import uploadReducer from './uploadReducer';
import verifyBankIdReducer from './verifyBankIdReducer';

const rootReducer = combineReducers({
  loginReducer,
  qrCodeReducer,
  serverReducer,
  promoCodeReducer,
  emailReducer,
  staffIdReducer,
  uploadReducer,
  downloadReducer,
  logoutReducer,
  getBdeDataReducer,
  adminUserReducer,
  verifyBankIdReducer,
  UserReducer,
  manageAddUserReducer,
});

export default rootReducer;
