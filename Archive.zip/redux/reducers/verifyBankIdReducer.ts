import * as constants from '../constants';
import { VerifyUserAction } from '../actions/interface';

import { IVerifyState } from './interface';

const initialState: IVerifyState = {
  userName: '',
  error: '',
  isLoading: false,
  isValid1BankId: false,
  status: '',
};

export default function verifyBankIdReducer(
  state = initialState,
  action: VerifyUserAction,
) {
  switch (action.type) {
    case constants.VERIFY_1BANKID:
      return {
        isLoading: true,
      };

    case constants.VERIFY_1BANKID_SUCCESS:
      return {
        isLoading: false,
        userName: action.userName,
        error: action.message,
        isValid1BankId: true,
      };

    case constants.VERIFY_1BANKID_FAILURE:
      return {
        error: action.message,
        isLoading: false,
        userName: action.userName,
        isValid1BankId: false,
        status: action.status,
      };

    default:
      return state;
  }
}
