import { IPromoCodeReducerState } from './interface';
import { STAFF_ID, STAFF_ID_FAILURE, STAFF_ID_SUCCESS } from '../constants';
import { IStaffIdAction } from '../actions/interface';

const initialState: IPromoCodeReducerState = {
  list: [],
  isLoading: false,
};

const staffIdReducer = (state = initialState, action: IStaffIdAction) => {
  switch (action.type) {
    case STAFF_ID:
      return {
        ...state,
        isLoading: true,
        list: [],
      };
    case STAFF_ID_SUCCESS:
      return {
        ...state,
        isLoading: false,
        list: action.list,
      };
    case STAFF_ID_FAILURE:
      return {
        ...state,
        isLoading: false,
        list: [],
        message: action.message,
      };
    default:
      return state;
  }
};

export default staffIdReducer;
