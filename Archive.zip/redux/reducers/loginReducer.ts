import { ILoginReducerState } from './interface';
import { LOGIN_FAILURE, LOGIN_SUBMIT, LOGIN_SUCCESS } from '../constants';
import { ILoginAction } from '../actions/interface';

const initialState: ILoginReducerState = {
  token: '',
  errorMessage: '',
  isLoading: false,
  role:''
};

const loginReducer = (state = initialState, action: ILoginAction) => {
  switch (action.type) {
    case LOGIN_SUBMIT: 
      return {
        ...state,
        isLoading: true,
      };

    case LOGIN_SUCCESS:
      return { 
        ...state,
        isLoading: false,
        token: action.token,
        role:action.role 
      };

    case LOGIN_FAILURE:
      return {
        ...state,
        isLoading: false,
        errorMessage: action.message,
        role:''
      };

    default:
      return state;
  }
};

export default loginReducer;
