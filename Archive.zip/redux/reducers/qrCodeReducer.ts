import {
  GET_QR_CODE_LIST,
  GET_QR_CODE_LIST_FAILURE,
  GET_QR_CODE_LIST_SUCCESS,
  CLEAR_QR_CODE_LIST,
} from '../constants';
import { IQRCodeReducerAction, IQRCodeReducerState } from './interface';

const initialState: IQRCodeReducerState = {
  list: [],
  isLoading: false,
  message: '',
};

const qrCodeReducer = (state = initialState, action: IQRCodeReducerAction) => {
  switch (action.type) {
    case GET_QR_CODE_LIST:
      return {
        ...state,
        isLoading: true,
      };
    case GET_QR_CODE_LIST_SUCCESS:
      return {
        ...state,
        isLoading: false,
        list: action.list,
      };
    case CLEAR_QR_CODE_LIST:
      return {
        ...state,
        isLoading: false,
        list: action.list,
      };
    case GET_QR_CODE_LIST_FAILURE:
      return {
        ...state,
        isLoading: false,
        message: action.message,
      };
    default:
      return state;
  }
};

export default qrCodeReducer;
