import { IServerReducerState } from './interface';
import { SERVER_DOWN, SERVER_UP, SERVER_CHECK } from '../constants';
import { IServerAction } from '../actions/interface';

const initialState: IServerReducerState = {
  isServerDown: false,
  message: '',
};

const serverReducer = (state = initialState, action: IServerAction) => {
  switch (action.type) {
    case SERVER_CHECK:
      return {
        ...state,
      };
    case SERVER_DOWN:
      return {
        ...state,
        isServerDown: action.isServerDown,
        message: 'server Down  from reducer',
      };
    case SERVER_UP:
      return {
        ...state,
        isServerDown: action.isServerDown,
        message: 'server Down  from reducer',
      };
    default:
      return state;
  }
};

export default serverReducer;
