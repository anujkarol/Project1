import { IPromoCodeReducerState } from './interface';
import {
  PROMO_CODE,
  PROMO_CODE_FAILURE,
  PROMO_CODE_SUCCESS,
} from '../constants';
import { IPromoCodeAction } from '../actions/interface';

const initialState: IPromoCodeReducerState = {
  list: [],
  isLoading: false,
};

const promoCodeReducer = (state = initialState, action: IPromoCodeAction) => {
  switch (action.type) {
    case PROMO_CODE:
      return {
        ...state,
        isLoading: true,
        list: [],
      };
    case PROMO_CODE_SUCCESS:
      return {
        ...state,
        isLoading: false,
        list: action.list,
      };
    case PROMO_CODE_FAILURE:
      return {
        ...state,
        isLoading: false,
        list: [],
        message: action.message,
      };
    default:
      return state;
  }
};

export default promoCodeReducer;
