import { EmailListObject } from '../actions/interface';

export interface ILoginReducerState {
  token: string;
  errorMessage: string;
  isLoading: boolean;
  role:string
}

export interface IEmailReducerState {
  list: EmailListObject[];
  isLoading: boolean;
  message:string
}

export interface IPromoCodeReducerState {
  list: object;
  isLoading: boolean;
}

export interface IQRCodeReducerState {
  list: [];
  isLoading: boolean;
  message: string;
}

export interface IQRCodeReducerAction {
  message: string;
  list: object[];
  type: string;
}

export interface IServerReducerState {
  isServerDown: boolean;
  message: string;
}

export interface IUploadReducerState {
  attachment: FormData | string;
  isLoading: boolean;
  message: string;
  documentType: string;
  isUploaded: boolean;
}

export interface IDownloadReducerState {
  documentType: string;
  isDownloaded: boolean;
}

export interface IBDEReducerState {
  isServerDown: boolean;
  message: string;
}

export interface ILogOutReducerState {
  isLoading: boolean;
}

export interface IAddUserState {
  payload: FormData;
  isLoading: boolean;
  status: string;
  message: string;
}

export interface IUsers {
  checker: string;
  checkerTs: string;
  id: number;
  maker: string;
  makerTs: string;
  user1BankId: string;
  userGroup: string;
  userLifeCycle: string;
  userName: string;
  userRole: string;
  userStatus: string;
  version: number;
  submissionTs: string;
  CheckerDetails: {
    user1BankId: string;
    userName: string;
  };
}

export interface IUser {
  id: number;
  version: number;
}
export interface IRequestUser extends IUsers {
  originalname: string;
  usersAudits: [
    {
      columnName: string;
      columnValue: string;
      id: number;
      messageKey: number;
      timeStamp: string;
      version: number;
    },
  ];
}
export interface IAdminUserState {
  users: Array<IRequestUser>;
  message: string;
  isLoading: boolean;
  totalRequestedRecordCount: number;
}
export interface IVerifyState {
  userName: string;
  error: string;
  isLoading: boolean;
  isValid1BankId: boolean;
  status: string;
}
