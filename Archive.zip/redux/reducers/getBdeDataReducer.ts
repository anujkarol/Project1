import {
  GET_BDE_PARTNER_DATA,
  GET_BDE_PARTNER_DATA_FAILURE,
  GET_BDE_PARTNER_DATA_SUCCESS,
} from '../constants';

const initialState: any = {
  partnerList: [],
  isPartnerListLoading: false,
  totalRecords: 0,
};

const getBdeDataReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case GET_BDE_PARTNER_DATA:
      return {
        ...state,
        isPartnerListLoading: true,
        totalRecords: 0,
      };

    case GET_BDE_PARTNER_DATA_SUCCESS:
      return {
        ...state,
        isPartnerListLoading: false,
        partnerList: action.partnerList,
        totalRecords: action.totalRecords,
      };

    case GET_BDE_PARTNER_DATA_FAILURE:
      return {
        ...state,
        isLoading: false,
        isPartnerListLoading: [],
        errorMessage: action.message,
        totalRecords: 0,
      };

    default:
      return state;
  }
};

export default getBdeDataReducer;
