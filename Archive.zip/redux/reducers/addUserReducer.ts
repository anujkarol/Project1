import * as constants from '../constants';

import { IAddUserAction } from '../actions/interface';
import { IAddUserState } from './interface';

const initialState: IAddUserState = {
  payload: new FormData(),
  isLoading: false,
  status: '',
  message: '',
};

export default function manageAddUserReducer(
  state = initialState,
  action: IAddUserAction,
) {
  switch (action.type) {
    case constants.ADMIN_ADD_USER:
      return {
        user: action.payload,
        isLoading: true,
        status: '',
        message: '',
      };

    case constants.ADMIN_ADD_USER_SUCCESS:
      return {
        isLoading: false,
        status: action.status,
        message: action.message,
      };

    case constants.ADMIN_ADD_USER_FAILURE:
      return {
        user: {},
        isLoading: false,
        status: action.status,
        message: action.message,
      };

    default:
      return state;
  }
}
