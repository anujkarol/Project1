import { DOWNLOAD, DOWNLOAD_FAILURE, DOWNLOAD_SUCCESS } from '../constants';
import { IDownloadReducerState } from './interface';
import { IDownloadAction } from '../actions/interface';

const initialState: IDownloadReducerState = {
  documentType: 'Partner',
  isDownloaded: false,
};

const downloadReducer = (state = initialState, action: IDownloadAction) => {
  switch (action.type) {
    case DOWNLOAD:
      return {
        ...state,
        isDownloaded: true,
        documentType: action.documentType,
      };
    case DOWNLOAD_SUCCESS:
      return {
        ...state,
        isDownloaded: false,
      };
    case DOWNLOAD_FAILURE:
      return {
        ...state,
        isDownloaded: false,
        message: action.message,
      };
    default:
      return state;
  }
};

export default downloadReducer;
