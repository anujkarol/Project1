import { call, put } from 'redux-saga/effects';
import { VERIFY_1BANKID_SUCCESS, VERIFY_1BANKID_FAILURE } from '../constants';

import { instance } from '../../helpers/interceptor';

export function* verifyBankIdSaga() {
  try {
    const response = yield call(() =>
      instance({
        method: 'GET',
        // url: endPoints.generateQRCode,
      }),
    );
    const status = response.data.isValid1BankId;
    const { userName } = response.data;
    if (status) {
      yield put({
        type: VERIFY_1BANKID_SUCCESS,
        userName,
        isValid1BankId: true,
        message: 'User Name Found',
      });
    } else if (response.data.status === 'Error') {
      yield put({
        type: VERIFY_1BANKID_FAILURE,
        message: response.data.message,
        isValid1BankId: false,
        userName: '',
        status: 'Duplicate',
      });
    } else {
      yield put({
        type: VERIFY_1BANKID_FAILURE,
        message: 'USER NAME NOT FOUND',
        isValid1BankId: false,
        userName: '',
        status: '',
      });
    }
  } catch (e) {
    yield put({
      type: VERIFY_1BANKID_FAILURE,
      message: e.message,
    });
  }
}
