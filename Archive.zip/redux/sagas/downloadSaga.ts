import { call, put, delay } from 'redux-saga/effects';

import endPoints from '../../helpers/endPoints';
import { instance } from '../../helpers/interceptor';

import { DownloadStart } from '../actions/interface';
import { DOWNLOAD_SUCCESS, DOWNLOAD_FAILURE } from '../constants';
import { authHeader } from '../../helpers/authHeader';

export function* downloadSaga(action: DownloadStart) {
  const headers = authHeader();

  const { documentType } = action;

  try {
    const response = yield call(() =>
      instance({
        method: 'GET',
        url: `${endPoints.download}?documentType=${documentType}`,
        headers,
      }),
    );
    let blob = new Blob([response.data], { type: 'application/csv' });
    let link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = `${documentType}.csv`;
    link.click();

    yield put({
      type: DOWNLOAD_SUCCESS,
    });
  } catch (error) {
    yield put({
      type: DOWNLOAD_FAILURE,
      message: error.message,
    });
  }
}
