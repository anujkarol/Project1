import { call, put } from 'redux-saga/effects';
import { ADMIN_ADD_USER_FAILURE, ADMIN_ADD_USER_SUCCESS } from '../constants';

import endPoints from '../../helpers/endPoints';
import { instance } from '../../helpers/interceptor';
import { authHeader } from '../../helpers/authHeader';

export function* addUserSaga(action: any) {
  const headers = authHeader();
  try {
    const user = action.payload;
    const response = yield call(() =>
      instance({
        method: 'POST',
        url: endPoints.createUser,
        data: {
          userName: user,
        },
        headers,
      }),
    );

    const { status } = response.data;
    const { message } = response.data;
    if (status === 'Success') {
      yield put({ type: ADMIN_ADD_USER_SUCCESS, status, message });
    }
  } catch (e) {
    yield put({
      type: ADMIN_ADD_USER_FAILURE,
      message: 'message',
      status: 'message',
    });
  }
}
