import { call, put } from 'redux-saga/effects';
import {
  ADMIN_REQUESTED_USER_SUCCESS,
  ADMIN_REQUESTED_USER_FAILURE,
} from '../constants';

import { instance } from '../../helpers/interceptor';

export function* usersSaga() {
  try {
    // const url = `${endPoints.getUsers}${pageNo}`;

    // const response = yield call(() => getData(url));

    const response = yield call(() =>
      instance({
        method: 'GET',
        // url: endPoints.generateQRCode,
      }),
    );

    const { status } = response.data;
    const message = response.data.message || '';

    if (status !== 'Error') {
      const payload = response.data;
      yield put({
        type: ADMIN_REQUESTED_USER_SUCCESS,
        users: payload.users,
        totalRecords: payload.pagination.totalRecCnt,
        message,
      });
    } else {
      yield put({
        type: ADMIN_REQUESTED_USER_FAILURE,
        message,
        users: [],
      });
    }
  } catch (e) {
    yield put({
      type: ADMIN_REQUESTED_USER_FAILURE,
      message: e.message,
      users: [],
    });
  }
}
