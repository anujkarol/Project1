import { put, call } from 'redux-saga/effects';
import { STAFF_ID_FAILURE, STAFF_ID_SUCCESS } from '../constants';
import { instance } from '../../helpers/interceptor';
import endPoints from '../../helpers/endPoints';
import { authHeader } from '../../helpers/authHeader';

// import { Brnach } from '../../stub/promo/promoDetailsList';

export function* staffIdSaga() {
  const headers = authHeader();
  try {
    const response:any = yield call(() =>
      instance({
        method: 'GET',
        url: endPoints.getStaffData,
        headers,
      }),
    );
   
    

    const { data } = response;
    yield put({
      type: STAFF_ID_SUCCESS,
      list: data,
    });
  } catch {
    yield put({
      type: STAFF_ID_FAILURE,
      message: 'RESPONSE FAILS FROM SAGA',
    });
  }
}
