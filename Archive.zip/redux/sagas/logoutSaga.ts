import { put } from 'redux-saga/effects';
import { LOGOUT_SUCCESS, LOGOUT_FAILURE } from '../constants';

export function* logoutSaga() {
  try {
    localStorage.removeItem('token');

    yield put({
      type: LOGOUT_SUCCESS,
    });
  } catch {
    yield put({
      type: LOGOUT_FAILURE,
      message: 'RESPONSE FAILS FROM SAGA',
    });
  }
}
