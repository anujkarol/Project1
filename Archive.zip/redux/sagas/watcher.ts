import { takeLatest } from 'redux-saga/effects';
import { QrSaga } from './qrCodeSaga';
import { addUserSaga } from './addUserSaga';
import { downloadSaga } from './downloadSaga';
import { emailSaga } from './emailSaga';
import { getBdeDataSaga } from './getBdeDataSaga';
import { promoCodeSaga } from './promoCodeSaga';
import { serverDownSaga } from './serverDownSaga';
import { staffIdSaga } from './staffIdSaga';
import { uploadSaga } from './uploadSaga';
import { usersSaga } from './usersSaga';
import { verifyBankIdSaga } from './verifyBankIdSaga';
import { LoginSaga } from './loginSaga';
import { logoutSaga } from './logoutSaga';

export default function* watcherSaga() {
  yield takeLatest('LOGIN_SUBMIT', LoginSaga);
  yield takeLatest('LOGOUT', logoutSaga);
  yield takeLatest('GET_QR_CODE_LIST', QrSaga);
  yield takeLatest('SERVER_RESPONSE_DOWN', serverDownSaga);
  yield takeLatest('PROMO_CODE', promoCodeSaga);
  yield takeLatest('EMAIL', emailSaga);
  yield takeLatest('STAFF_ID', staffIdSaga);
  yield takeLatest('DOWNLOAD', downloadSaga);
  yield takeLatest('UPLOAD', uploadSaga);
  yield takeLatest('ADMIN_REQUESTED_USER', usersSaga);
  yield takeLatest('ADMIN_ADD_USER', addUserSaga);
  yield takeLatest('GET_BDE_PARTNER_DATA', getBdeDataSaga);
  yield takeLatest('VERIFY_1BANKID', verifyBankIdSaga);
}
