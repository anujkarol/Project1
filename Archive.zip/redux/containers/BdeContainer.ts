import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { Dispatch } from 'redux';
import * as actions from '../actions';

import BDE from '../../pages/BDE';
import { IBDEState } from './interface';

const mapStateToProps = (state: IBDEState) => ({
  partnerList: state.getBdeDataReducer.partnerList,
  isPartnerDataLoading: state.getBdeDataReducer.isPartnerListLoading,
  isServerDown: state.serverReducer.isServerDown,
  isUploading: state.uploadReducer.isLoading,
  isDownloaded: state.downloadReducer.isDownloaded,
  message: state.uploadReducer.message,
  totalRecords: state.getBdeDataReducer.totalRecords,
  uploadStatus: state.uploadReducer.isUploaded,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  getPartnerList: (page: number, selectedTab: string) =>
    dispatch(actions.getPartnerList(page, selectedTab)),
  fileUpload: (attachment: FormData, documentType: string) =>
    dispatch(actions.uploadStart(attachment, documentType)),
  fileDownload: (documentType: string) =>
    dispatch(actions.downloadStart(documentType)),
  updateMessage: (message: string) => {
    dispatch(actions.updateMessage(message));
  },
});

export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(BDE),
);
