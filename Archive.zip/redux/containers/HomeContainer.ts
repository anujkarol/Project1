import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { Dispatch } from 'redux';
import Home from '../../pages/Home/Home';
import * as actions from '../actions';

const mapStateToProps = (state: any) => ({
  isServerDown: state.serverReducer.isServerDown,
  userRole: state.loginReducer.role,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  logout: () => dispatch(actions.logout()),
});
export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(Home),
);
