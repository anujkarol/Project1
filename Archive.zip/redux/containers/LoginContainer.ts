import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { Dispatch } from 'redux';
import * as actions from '../actions';

import LoginPage from '../../pages/Login';
import { ILoginState } from './interface';

const mapStateToProps = (state: ILoginState) => ({
  token: state.loginReducer.token,
  message: state.loginReducer.errorMessage,
  isLoading: state.loginReducer.isLoading,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  loginSubmit: (userName: string, password: string) =>
    dispatch(actions.loginSubmit(userName, password)),
});

export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(LoginPage),
);
