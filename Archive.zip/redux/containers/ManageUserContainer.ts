import { Dispatch } from 'redux';
import { connect } from 'react-redux';
import {
  AddUserActions,
  manageUserActions,
  verifyBankIdAction,
} from '../actions';

import ManageUser from '../../pages/ManageUser';

const s = (state: any) => {
  const {
    users,
    isLoading,
    error,
    totalRequestedRecordCount: totalCount,
  } = state.adminUserReducer;

  const { items: userDetails } = state.UserReducer;

  const {
    status: addUserStatus,
    isLoading: isUserAdded,
  } = state.manageAddUserReducer;

  const { commonReducer } = state;
  const { UserReducer } = state;

  const {
    isLoading: isVerifying,
    userName: verifyUserName,
    isValid1BankId,
    status: verifyStatus,
  } = state.verifyBankIdReducer;

  return {
    users,
    isLoading,
    error,
    totalCount,

    addUserStatus,
    isUserAdded,

    // isServerDown,
    userDetails,
    commonReducer,
    UserReducer,

    isVerifying,
    verifyUserName,
    isValid1BankId,
    verifyStatus,
  };
};

const d = (dispatch: Dispatch | any) => ({
  getUsers: (pageNo = 1) => {
    dispatch(manageUserActions.requestUserInitiate(pageNo));
  },
  addUser: (payload: FormData) => {
    dispatch(AddUserActions.addUser(payload));
  },
  verifyUser: (userId = '') => {
    dispatch(verifyBankIdAction.verify1BankIdActionInitiate(userId));
  },
});

export default connect(s, d)(ManageUser);
