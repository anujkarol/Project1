import {
  IQRCodeReducerState,
  IPromoCodeReducerState,
  IUploadReducerState,
  IServerReducerState,
  IDownloadReducerState,
  ILoginReducerState,
} from '../reducers/interface';

export interface InitialState {
  serverReducer: IServerReducerState;
  loginReducer: any;
  emailReducer: any;
  staffIdReducer: any;
  logoutReducer: any;
  getBdeDataReducer: any;
  adminUserReducer: any;
  verifyBankIdReducer: any;
  UserReducer: any;
  manageAddReducer: any;
  qrCodeReducer: IQRCodeReducerState;
  promoCodeReducer: IPromoCodeReducerState;
  uploadReducer: IUploadReducerState;
  downloadReducer: IDownloadReducerState;
}
export interface IState {
  qrCodeReducer: IQRCodeReducerState;
  promoCodeReducer: IPromoCodeReducerState;
  emailReducer: any;
  staffIdReducer: any;
}

export interface IBDEState {
  getBdeDataReducer: any;
  uploadReducer: IUploadReducerState;
  downloadReducer: IDownloadReducerState;
  serverReducer: IServerReducerState;
}

export interface ILoginState {
  loginReducer: ILoginReducerState;
}
