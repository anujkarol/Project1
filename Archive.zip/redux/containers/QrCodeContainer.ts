import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import * as actions from '../actions';
import { IState } from './interface';
import QrCode from '../../pages/QRCode';
import { EmailListObject } from '../actions/interface';

const mapStateToProps = (state: IState) => ({
  QrCodeList: state.qrCodeReducer.list,
  EmailMessage:state.emailReducer.message,
  message: state.qrCodeReducer.message,
  isLoading: state.qrCodeReducer.isLoading,
  staffDataList: state.staffIdReducer.list,
  emailLoader: state.emailReducer.isLoading,
  promoCodeList: state.promoCodeReducer.list,
  isStaffIdLoading: state.promoCodeReducer.isLoading,
  isPromoCodeLoading: state.promoCodeReducer.isLoading,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  sendEmail: (list: EmailListObject[]) => dispatch(actions.sendEmailList(list)),
  getPromoCodeList: () => dispatch(actions.getPromoCode()),
  getStaffDataList: () => dispatch(actions.getStaffIdList()),
  saveQrListInState: (list: EmailListObject[]) =>
    dispatch(actions.generateQrCode(list)),
  clearQrListInState: () => dispatch(actions.clearQrCodeList()),
  updateEmailStatus: (message: string) => {
    dispatch(actions.sendEmailStatus(message));
  },
});

export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(QrCode),
);
