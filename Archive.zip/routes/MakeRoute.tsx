import React, { Suspense } from 'react';
import { Route, Redirect } from 'react-router';
import PrivateRoute from './PrivateRoute';
import { IRoute } from './interface';
import Loader from '../components/Loader';

const MakeRoute = (route: IRoute) => {

  const getRoute = (props: any) => {
    const { history, match, location } = props;

    return (route.protected ?
      <PrivateRoute component={route.component} history={history} location={location} match={match} /> : <route.component history={history} location={location} match={match} routes={route.routes} />)
  }
  return (
    <Suspense fallback={<Loader />}>
      <Route
        path={route.path}
        render={props =>
          route.redirect ? (
            <Redirect to={route.redirect} />
          ) : getRoute(props)}
      />
    </Suspense>
  );
};
export default MakeRoute;
