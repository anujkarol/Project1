import React from 'react';
import { RouteProps, match, StaticContext } from 'react-router';
import { Location, History } from 'history';

export interface IRoute {
  path: string;
  exact: boolean;
  component?: any;
  routes?: IRoute[];
  redirect?: string;
  protected?: boolean;
}

export interface IRouteProps {
  routes: IRoute[];
}

export interface IPrivateProps extends RouteProps {
  isAuthenticated: true;
  render: (props: any) => React.ReactNode;

  history?: History<any>;
  location?: Location<any>;
  match?: match<any>;
  staticContext?: StaticContext | undefined;
  component?: any;
}
