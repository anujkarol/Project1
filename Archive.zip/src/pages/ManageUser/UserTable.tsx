import React, { ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { Column } from '../../components/Table/Column';
import { Row } from '../../components/Table/Row';
import { Table } from '../../components/Table';
import { IUserTableProps } from './interface';
import TableNoRecord from '../Common/TableNoRecord';
import Button from '../../components/Button/index';
import Loader from '../../components/Loader/index';
import { Dash } from '../../components/icons/Dash';
import TableHeader from '../Common/TableHeader';

const colWidth = [150, 150, 250, 100, 200, 300];
export const UserTable: React.FC<IUserTableProps> = ({
  content = [],
  userRole,
  isUserListLoading = false,
  handleUserAction,
  downloadFile,
}) => {
  const { t } = useTranslation();

  const pendingRows = content.filter((item: any) => item.status === 'PENDING');
  const aprovedRows = content.filter((item: any) => item.status === 'APPROVED');

  const rejectedRows = content.filter(
    (item: any) => item.status === 'REJECTED',
  );

  const newRows = [...pendingRows, ...aprovedRows, ...rejectedRows];

  if (isUserListLoading) {
    return <Loader />;
  }

  const tableRows = newRows.map(
    (item: any, index: number): ReactElement => {
      const isAddUserButtonVisible: boolean =
        userRole.toLowerCase() !== 'maker' &&
        item.status.toLowerCase() === 'pending';
      const userStatus =
        item.status.toLowerCase() !== 'pending' ? (
          `${item.status} by ${item.updatedBy}`
        ) : (
          <b>{item.status}</b>
        );
      return (
        <Row key={index} isShift header={false}>
          <Column width={150}>{item.submittedDate}</Column>
          <Column width={150}>{item.addedBy}</Column>
          <Column width={250}>{item.name}</Column>
          <Column width={100}>
            <Button
              component="a"
              capitalize={false}
              onClick={() => downloadFile(item)}
              use="ghost"
              size="medium"
              sequence="first"
              style={{ minWidth: 'inherit' }}
            >
              {t('table.download')}
            </Button>
          </Column>
          <Column width={200}>
            {item.updatedOn ? item.updatedOn : <Dash top="0px" />}
          </Column>
          {isAddUserButtonVisible ? (
            <Column width={300}>
              <Button
                use="green"
                shape="pill"
                size="medium"
                capitalize={false}
                onClick={() => handleUserAction(item.userName, 'approve')}
              >
                {t('buttons.approve')}
              </Button>
              <span style={{ margin: '0 10px' }} />
              <Button
                use="primary"
                shape="pill"
                size="medium"
                capitalize={false}
                onClick={() => handleUserAction(item.userName, 'reject')}
              >
                {t('buttons.reject')}
              </Button>
            </Column>
          ) : (
            <Column width={300}>{userStatus}</Column>
          )}
        </Row>
      );
    },
  );

  const headers = [
    `${t('table.submission')}`,
    `${t('table.request')}`,
    `${t('table.1Bankid')}`,
    `${t('table.download')}`,
    `${t('table.approval')}`,
    `${t('table.status')}`,
  ];
  return (
    <>
      <Table isShift={false}>
        <TableHeader
          isShift={false}
          header
          tablelHeaders={headers}
          colWidth={colWidth}
        />
        {!content.length ? (
          <TableNoRecord message={t('errors.noRecord')} />
        ) : (
          tableRows
        )}
      </Table>
    </>
  );
};

export default UserTable;
