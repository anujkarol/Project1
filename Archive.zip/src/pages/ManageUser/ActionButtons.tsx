import React, { ReactElement } from 'react';

import { useTranslation } from 'react-i18next';
import Button from '../../components/Button';
import { ButtonWrapper } from '../BDE/styles';
import { IActionButtonProps } from './interface';

const ActionButtons: React.FC<IActionButtonProps> = ({
  openAddUserModal,
  deleteUserTable,
  isShowAddUser,
  isShowDeleteUser,
}): ReactElement => {

  const { t } = useTranslation();
  return (
    <ButtonWrapper style={{ marginTop: '40px' }}>
      {isShowAddUser && (
        <Button
          component="button"
          icon="add"
          capitalize={false}
          onClick={openAddUserModal}
          use="ghost"
          size="medium"
        >
          {t('buttons.addUser')}
        </Button>
      )}
      {isShowDeleteUser && (
        <Button
          component="button"
          icon="add"
          capitalize={false}
          onClick={deleteUserTable}
          use="ghost"
          size="medium"
        >
          {t('buttons.deleteUser')}
        </Button>
      )}
    </ButtonWrapper>
  );
};

export default ActionButtons;
