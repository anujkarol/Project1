interface IUser {
  name: string;
  userName: string;
  email: string;
  submittedDate: string;
  addedBy: string;
  status: string;
  updatedBy: string;
  updatedOn: string;
}

export interface IUserTableProps {
  content: IUser[];
  userRole: string;
  isUserListLoading: boolean;
  handleUserAction: (name: string, action: string) => void;
  downloadFile: (item: any) => void;
}

export interface IAddUserState {
  ibankid: string;
  isBtnDisabled: boolean;
  disabledvalue: string;
  attachment: File | string;
  error: boolean;
  attached: boolean;
  fileName: string;
  errorMessage: string;
  isValid1BankId: boolean;
}

export interface IAddUserProps {
  addUser: (user: FormData) => void;
  verifyUser: (value: string) => void;
  isShow: boolean;
  handleCloseModal: () => void;
  isValid1BankId: boolean;
  verifyName: string;
  isVerifying: boolean;
  message: string;
  email: string;
}

export interface IManageUserState {
  isAddUserModal: boolean;
}

export interface IManageUserProps {
  getUsers: () => void;
  users: IUser[];
  isUserAdded: boolean;
  isUserAddedMessage: string;
  role: string;
  name: string;
  isUserListLoading: boolean;
  userAction: (name: string, action: string) => void;
  userAddStatus: (userAddedStatus: boolean) => void;
  userAddedStatus: boolean;
  downloadFile: (item: any) => void;
  isFileDownloaded: boolean;
}

export interface IActionButtonProps {
  openAddUserModal: () => void;
  deleteUserTable: () => void;
  isShowAddUser: () => void;
  isShowDeleteUser: () => void;
}
