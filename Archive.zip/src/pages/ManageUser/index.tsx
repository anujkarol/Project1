import React from 'react';

import { WithTranslation } from 'react-i18next';
import Button from '../../components/Button';
import { ButtonWrapper } from '../BDE/styles';
import PageHeader from '../Common/PageHeader';
import UserTable from './UserTable';
import { Wrapper } from '../QRCode/style';
import { IManageUserState, IManageUserProps } from './interface';
import { Add } from '../../components/icons/Add';
import AddUserContainer from '../../redux/containers/AddUserContainer';
import Status from '../Common/StatusModal';
import { GLOBAL_CONFIG } from '../../helpers/global';
import Loader from '../../components/Loader/index';

class ManageUser extends React.Component<
  IManageUserProps & WithTranslation,
  IManageUserState
> {
  constructor(props: IManageUserProps & WithTranslation) {
    super(props);
    this.state = {
      isAddUserModal: false,
    };
  }

  componentDidMount() {
    const { getUsers } = this.props;
    getUsers();
  }

  openAddUserModal = () => {
    const { isAddUserModal } = this.state;
    const { userAddStatus } = this.props;
    userAddStatus(false);
    this.setState({
      isAddUserModal: !isAddUserModal,
    });
  };

  handleCloseModal = (): void => {
    const { isAddUserModal } = this.state;
    this.setState({
      isAddUserModal: !isAddUserModal,
    });
  };

  handleUserAction = (name = '', action = 'approve') => {
    const { userAction, getUsers } = this.props;
    userAction(name, action);
    getUsers();
  };

  handleCloseStatusModal = (): void => {
    const { getUsers, isUserAdded, userAddStatus } = this.props;

    userAddStatus(false);
    if (isUserAdded) {
      getUsers();
    }
  };

  downloadFile = (item: any) => {
    const { downloadFile } = this.props;
    const { fileKey } = item;
    downloadFile(fileKey);
  };

  render() {
    const { isAddUserModal } = this.state;
    const {
      users = [],
      t,
      role = 'MAKER',
      isUserListLoading = false,
      name = '',
      isUserAddedMessage = '',
      isUserAdded = false,
      userAddedStatus = false,
      isFileDownloaded = false,
    } = this.props;

    const isAddUserBtnEnabled = role
      ? role.toLowerCase() !== 'checker'
      : 'MAKER';

    return (
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <Wrapper>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <PageHeader title={GLOBAL_CONFIG.PAGE3} userName={name} />

            <ButtonWrapper style={{ marginTop: '40px' }}>
              {isAddUserBtnEnabled && (
                <Button
                  component="button"
                  icon="add"
                  capitalize={false}
                  onClick={this.openAddUserModal}
                  use="ghost"
                  size="medium"
                  sequence="last"
                >
                  <Add />
                  {t('buttons.addUser')}
                </Button>
              )}
            </ButtonWrapper>
          </div>

          {isFileDownloaded && <Loader />}

          <UserTable
            content={users}
            userRole={role}
            isUserListLoading={isUserListLoading}
            handleUserAction={this.handleUserAction}
            downloadFile={this.downloadFile}
          />

          <br />
          <br />

          {isAddUserModal && (
            <AddUserContainer
              isShow={isAddUserModal}
              handleCloseModal={this.handleCloseModal}
            />
          )}

          <Status
            isShow={userAddedStatus}
            icon={isUserAdded ? 'success' : 'warning'}
            message={isUserAddedMessage}
            closeModal={this.handleCloseStatusModal}
          />
        </Wrapper>
      </div>
    );
  }
}

export default ManageUser;
