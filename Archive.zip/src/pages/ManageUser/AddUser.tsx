import * as React from 'react';

import Button from '../../components/Button';
import Form from '../../components/Form';
import Input from '../../components/Input/Input';
import { LeftCol } from '../QRCode/style';
import Loader from '../../components/Loader';
import Modal from '../../components/Modal';
import {
  checkFileSize,
  validateRegEx,
  checkMimeType,
} from '../../helpers/validations';
import { withTranslation, WithTranslation } from 'react-i18next';
import { IAddUserState, IAddUserProps } from './interface';
import InputFile from '../../components/Input/InputFile';
import Context from '../../components/Context';
import { GLOBAL_CONFIG } from '../../helpers/global';
import { USER_APPROVAL } from '../../redux/constants/index';

class AddUser extends React.Component<
  IAddUserProps & WithTranslation,
  IAddUserState
> {
  constructor(props: IAddUserProps & WithTranslation) {
    super(props);
    this.state = {
      ibankid: '',
      isBtnDisabled: true,
      disabledvalue: '',
      attachment: '',
      attached: false,
      fileName: '',
      error: false,
      errorMessage: '',
      isValid1BankId: false,
    };
  }

  handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    const isBankIdValid: boolean = validateRegEx(value);
    const isEmpty: boolean = value === '';

    const error = !isBankIdValid && !isEmpty;

    this.setState({
      ibankid: value,
      isBtnDisabled: error,
    });
  };

  handleFileInputChange = (e: any) => {
    const { t } = this.props;
    const file: File = e.target.files[0];
    const fileName: string = file.name;

    const fileSize = checkFileSize(file, 2000000);
    const fileType = checkMimeType(file, GLOBAL_CONFIG.FILE_TYPES_APPROVAL);
    const errorMessage = !fileSize
      ? `${t('errors.checkFileSize')}`
      : !fileType
      ? 'Please upload a file in supported format only.'
      : '';

    if (errorMessage) {
      this.setState({ attached: false, errorMessage, error: true });
    } else {
      this.setState({
        attachment: file,
        fileName,
        attached: true,
        error: false,
      });
    }
  };

  componentWillUnmount() {
    this.setState({
      disabledvalue: '',
    });
  }

  static getDerivedStateFromProps(
    props: IAddUserProps & WithTranslation,
    state: IAddUserState,
  ) {
    if (props.isValid1BankId !== state.isValid1BankId) {
      return {
        isValid1BankId: props.isValid1BankId,
      };
    }
    return null;
  }

  handleSubmit = (e: React.SyntheticEvent<EventTarget>): void => {
    const { ibankid, attachment } = this.state;
    const { addUser, email, verifyName, handleCloseModal } = this.props;
    e.preventDefault();
    const userDetailsRequest = {
      userName: ibankid,
      mail: email,
      name: verifyName,
    };
    const formData: FormData = new FormData();
    formData.append('userDetailsRequest', JSON.stringify(userDetailsRequest));
    formData.append('file', attachment);
    formData.append('documentType', USER_APPROVAL);
    console.log(formData);

    addUser(formData);
    handleCloseModal();
  };

  handleBlur = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const { verifyUser } = this.props;
    const { value } = e.target as HTMLInputElement;
    if (value !== '' && validateRegEx(value)) {
      verifyUser(value);
    }
  };

  componentDidUpdate(prevPops: IAddUserProps & WithTranslation) {
    if (this.props !== prevPops) {
      const { verifyName } = this.props;
      this.setState({
        disabledvalue: verifyName,
      });
    }
  }

  public render() {
    const {
      handleCloseModal,
      t,
      isShow = false,
      isVerifying = false,
      message = '',
    } = this.props;
    const {
      ibankid,
      disabledvalue,
      attachment,
      attached,
      fileName,
      errorMessage,
      isValid1BankId,
    } = this.state;

    let isButtonDisabled = true;

    if (ibankid === '' || !attached) {
      isButtonDisabled = true;
    } else if (isValid1BankId) {
      isButtonDisabled = false;
    } else {
      isButtonDisabled = true;
    }

    return (
      <Modal
        isShow={isShow}
        isCloseIcon={true}
        handleCloseModal={handleCloseModal}
        title="Add Admin User"
      >
        <Form type="inline">
          {isVerifying && <Loader />}
          <LeftCol>
            <Input
              name="ibankid"
              value={ibankid}
              type="email"
              label="Enter 1Bank ID"
              handleBlur={this.handleBlur}
              handleInputChange={this.handleInputChange}
              error={!isValid1BankId}
              errorMessage={message}
            />

            <Input
              name="name"
              value={disabledvalue || ''}
              disabled={true}
              type="text"
              label="Name"
            />

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                flexDirection: 'column',
              }}
            >
              <Context>
                [Supported format:
                {GLOBAL_CONFIG.FILE_TYPES_APPROVAL.toString()}]
              </Context>
              <br />
              <InputFile
                label="Attachment"
                type="file"
                value={attachment}
                name="attachment"
                error={errorMessage}
                onInputChange={this.handleFileInputChange}
                fileName={fileName}
                attached={attached}
                context="Please upload the file less than 2 MB."
              />
            </div>
          </LeftCol>
        </Form>
        <div style={{ marginTop: '48px' }}>
          <Button
            use={'primary'}
            shape={'square'}
            size={'normal'}
            disabled={isButtonDisabled}
            capitalize={false}
            onClick={this.handleSubmit}
          >
            {t('buttons.add')}
          </Button>
        </div>
      </Modal>
    );
  }
}
export default withTranslation()(AddUser);
