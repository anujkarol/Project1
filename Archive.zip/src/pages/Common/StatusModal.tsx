import React from 'react';
import Modal from '../../components/Modal';
import { Warning } from '../../components/icons/Warning';
import { Success } from '../../components/icons/Success';

interface IStatusModal {
  isShow: boolean;
  closeModal: () => void;
  icon: string;
  message: string;
  style?: any;
}

const StatusModal: React.FC<IStatusModal> = ({
  isShow,
  closeModal,
  icon,
  message = 'Successful',
}) => (
  <Modal isCloseIcon isShow={isShow} handleCloseModal={closeModal}>
    <div>
      {icon === 'warning' ? (
        <Warning height="75px" width="75px" color="#ff3333" />
      ) : (
        <Success height="75px" width="75px" color="#13c998" />
      )}
    </div>
    <h3>{message}</h3>
  </Modal>
);

export default StatusModal;
