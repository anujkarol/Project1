import React from 'react';
import { shallow } from 'enzyme';
import Pageheader from './PageHeader';

describe('Page Header', () => {
  it('should render correctly in "debug" mode', () => {
    const component = shallow(<Pageheader debug />);

    expect(component).toMatchSnapshot();
  });

  it('should render correctly with props', () => {
    // expect(component);
  });
});
