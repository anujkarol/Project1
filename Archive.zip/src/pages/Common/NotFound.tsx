import React from 'react';
import styledComponents from 'styled-components';
import { useTranslation } from 'react-i18next';
import Button from '../../components/Button';
import { history } from '../../helpers/history';

export const Wrapper = styledComponents.div`
    display:flex;
    height:500px;
    justify-content:center;
    align-items:center
    flex-direction:column
`;

const NotFound: React.FC = () => {
  const { t } = useTranslation();
  const handleLocation = () => {
    history.push('/');
  };

  return (
    <Wrapper>
      <h1>{t('errors.lbl_page_not_found')}</h1>
      <div className="mTop-20">
        <Button capitalize use="primary btn" onClick={() => handleLocation()}>
          {t('errors.lbl_got_back_to_login')}
        </Button>
      </div>
    </Wrapper>
  );
};

export default NotFound;
