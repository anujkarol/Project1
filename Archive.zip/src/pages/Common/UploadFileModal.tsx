import React from 'react';
import { withTranslation, WithTranslation } from 'react-i18next';
import { checkFileSize, checkMimeType } from '../../helpers/validations';

import Button from '../../components/Button';
import Context from '../../components/Context';
import InputFile from '../../components/Input/InputFile';
import Modal from '../../components/Modal';
import { GLOBAL_CONFIG } from '../../helpers/global';

interface IUploadFilesModalState {
  attachment: string;
  attached: boolean;
  fileName: string;
  error: string;
}

interface IUploadFilesModalProps {
  handleFileUpload: any;
  title: string;
  isShow: boolean;
  closeModal: () => void;
}

class UploadFilesModal extends React.Component<
  IUploadFilesModalProps & WithTranslation,
  IUploadFilesModalState
> {
  constructor(props: any) {
    super(props);
    this.state = {
      attachment: '',
      attached: false,
      fileName: '',
      error: '',
    };
  }

  handleUpload = () => {
    const { attachment, attached } = this.state;
    const { handleFileUpload } = this.props;
    handleFileUpload(attachment, attached);
  };

  checkError = (file: File) => {
    const { t } = this.props;

    const fileNameCheck = file.name.length > 40;
    const fileSize = checkFileSize(file, 2000000);
    const fileType = checkMimeType(file, GLOBAL_CONFIG.FILE_TYPES);

    if (!fileSize) {
      return `${t('errors.checkFileSize')}`;
    }
    if (!fileType) {
      return `${t('errors.checkFileType')}`;
    }
    if (fileNameCheck) {
      return `${t('errors.wrong_file_name')}`;
    }
    return '';
  };

  handleInputChange = (e: React.SyntheticEvent<EventTarget> | any) => {
    const file: any = e.target.files[0];
    const fileName: string = file.name;

    const error = this.checkError(file);

    if (error) {
      this.setState({ attached: false, error });
    } else {
      this.setState({
        error,
        attachment: file,
        fileName,
        attached: true,
      });
    }
  };

  render() {
    const { t, title, isShow, closeModal } = this.props;
    const { attachment, error, fileName, attached } = this.state;

    return (
      <>
        <Modal
          isCloseIcon
          isShow={isShow}
          title={title}
          handleCloseModal={closeModal}
        >
          <Context>{t('labels.context')}</Context>
          <div
            style={{
              display: 'flex',
              marginTop: '50px',
              alignItems: 'center',
              flexDirection: 'column',
            }}
          >
            <InputFile
              label="Attachment"
              type="file"
              value={attachment}
              name="attachment"
              error={error}
              onInputChange={this.handleInputChange}
              fileName={fileName}
              attached={attached}
              context={t('labels.context')}
            />
            <div style={{ alignSelf: 'center', marginTop: '25px' }}>
              <Button
                component="button"
                capitalize={false}
                onClick={this.handleUpload}
                use="primary"
                size="normal"
                disabled={!attached}
              >
                {t('buttons.upload')}
              </Button>
            </div>
          </div>
        </Modal>
      </>
    );
  }
}

export default withTranslation()(UploadFilesModal);
