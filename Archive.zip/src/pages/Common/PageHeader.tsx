import React, { ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { NameHeader, Title } from '../../assets/style';

import { IPageHeaderProps } from '../QRCode/interface';

const PageHeader: React.FC<IPageHeaderProps> = ({
  userName = 'User Name',
  title = 'Page Name',
}): ReactElement => {
  const { t } = useTranslation();
  return (
    <div>
      <NameHeader>
        {t('labels.welcome_back')}
        &nbsp;
        {userName}
      </NameHeader>
      <Title>{title}</Title>
    </div>
  );
};

export default PageHeader;
