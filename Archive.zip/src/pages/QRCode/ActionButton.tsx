import React, { ReactElement } from 'react';

import Button from '../../components/Button';
import { ButtonWrapper } from '../BDE/styles';
import { IActionButtonProps } from './interface';

const ActionButton: React.FC<IActionButtonProps> = ({
  handlePrimary,
  isDisabled = false,
  handleSecondary,
  labels,
}): ReactElement => (
  <ButtonWrapper style={{ marginTop: '24px', minHeight: 'auto' }}>
    <Button
      style={{ marginRight: '20px' }}
      component="button"
      capitalize={false}
      onClick={handlePrimary}
      disabled={isDisabled}
      use="primary"
      size="normal"
    >
      {labels[0]}
    </Button>
    {labels[1].toLowerCase() !== 'clear' && (
      <Button
        component="button"
        capitalize={false}
        onClick={handleSecondary}
        use="secondary"
        size="normal"
      >
        {labels[1]}
      </Button>
    )}
  </ButtonWrapper>
);

export default ActionButton;
