import React, { ReactNode, useState } from 'react';

import ActionButton from './ActionButton';
import Checkbox from '../../components/Checkbox';
import { Column } from '../../components/Table/Column';
import { Row } from '../../components/Table/Row';
import { Table } from '../../components/Table';
import { TableCheckBox } from '../../components/Checkbox/styles';
import { IRecordsProps } from './interface';
import TableNoRecord from '../Common/TableNoRecord';

const RecordSet = (
  records: object[],
  isShift: boolean,
  isChecked: any,
  handleChange: (e: any, item: any) => any,
) => {
  return records.map(
    (item: any): ReactNode => {
      return (
        <Row key={`index-${item.id}`} header={false} isShift={isShift}>
          {isShift && (
            <TableCheckBox>
              <Checkbox
                onChange={(e: React.SyntheticEvent<EventTarget>) =>
                  handleChange(e, item)
                }
                checked={isChecked.get(item.id)}
                value={item.id}
              />
            </TableCheckBox>
          )}
          <Column width={150}>{item.emailIds}</Column>
          <Column width={100}>{item.staffId}</Column>
          <Column width={150}>{item.promoCode}</Column>
          <Column width={200}>{item.campaignType}</Column>
        </Row>
      );
    },
  );
};
const Records: React.FC<IRecordsProps> = ({
  records,
  isShift,
  handleRecordDelete,
  handleDeleteCancel,
  handleCancel,
  handleSubmit,
  t,
}) => {
  const [recordsSet, setChange] = useState<{
    isChecked: any;
    selectedRecord: object[];
  }>({
    isChecked: new Map(),
    selectedRecord: [],
  });

  const [selectAll, setSelectAll] = useState(false);

  const handleBtnDeleteCancel = () => {
    setChange({
      selectedRecord: [],
      isChecked: new Map(),
    });
    setSelectAll(false);
    handleDeleteCancel();
  };
  const handleSelectAll = (e: React.SyntheticEvent<EventTarget>): void => {
    const target: {
      value: string;
      checked: boolean;
    } = e.target as HTMLInputElement;

    const isItemChecked: boolean = target.checked;

    setSelectAll(!selectAll);

    let checkAll: any;

    for (const record of records) {
      checkAll = isChecked.set(record.id, true);
    }

    if (isItemChecked) {
      setChange((prevState: any) => ({
        ...recordsSet,
        selectedRecord: records,
        isChecked: checkAll,
      }));
    } else {
      setChange((prevState: any) => ({
        ...recordsSet,
        selectedRecord: [],
        isChecked: new Map(),
      }));
    }
  };

  const handleChange = (
    e: React.SyntheticEvent<EventTarget>,
    item: object,
  ): void => {
    const target: {
      value: string;
      checked: boolean;
    } = e.target as HTMLInputElement;
    const val: string = target.value;
    const isItemChecked: boolean = target.checked;
    setChange({
      ...recordsSet,
      isChecked: isChecked.set(val, isItemChecked),
    });

    if (isItemChecked) {
      setChange((prevState: any) => ({
        ...recordsSet,
        selectedRecord: prevState.selectedRecord.concat(item),
      }));
      if (records.length - 1 === selectedRecord.length) {
        setSelectAll(!selectAll);
      }
    } else {
      const newRecords = recordsSet.selectedRecord.filter(
        (item: any): boolean => {
          return item.id !== val;
        },
      );
      setChange({
        ...recordsSet,
        selectedRecord: newRecords,
      });
      if (records.length === selectedRecord.length) {
        setSelectAll(!selectAll);
      }
    }
  };

  const handleDelete = (): void => {
    const arrayNew: Array<any> = [...recordsSet.selectedRecord];
    setSelectAll(false);
    handleRecordDelete(arrayNew);
    setChange({
      ...recordsSet,
      selectedRecord: [],
    });
  };

  const { selectedRecord, isChecked } = recordsSet;

  let tableRows: any = [];
  tableRows = RecordSet(records, isShift, isChecked, handleChange);

  if (!tableRows.length) {
    tableRows = <TableNoRecord message={t('errors.noRecordQR')} />;
  }
  return (
    <div>
      <Table isShift={isShift}>
        <Row header={true} isShift={false}>
          {isShift && (
            <TableCheckBox>
              <Checkbox
                onChange={(e: React.SyntheticEvent<EventTarget>) =>
                  handleSelectAll(e)
                }
                checked={selectAll}
                value={1}
              />
            </TableCheckBox>
          )}
          <Column width={150}>{t('table.email_id')}</Column>
          <Column width={100}>{t('table.staff_id')}</Column>
          <Column width={150}>{t('table.promo_code')}</Column>
          <Column width={200}>{t('table.promo_type')}</Column>
        </Row>
        {tableRows}
      </Table>

      {records.length > 0 && !isShift && (
        <ActionButton
          labels={['Generate QR Code', 'Cancel']}
          handlePrimary={handleSubmit}
          handleSecondary={handleCancel}
        />
      )}

      {selectedRecord.length > 0 && isShift && (
        <ActionButton
          labels={['Delete', 'Cancel']}
          handlePrimary={handleDelete}
          handleSecondary={handleBtnDeleteCancel}
        />
      )}
    </div>
  );
};

export default Records;
