import { ChangeEvent } from 'react';

export interface IActionButtonProps {
  handlePrimary: () => void;
  handleSecondary: () => void;
  isDisabled?: boolean;
  labels: string[];
}
export interface IRecordModalState {
  email: string;
  emailError: boolean;
  staffId: object[];
  category: string;
  selectedPromoCode: string;
  startDate: string;
  endDate: string;
}
export interface IRecordModalProps {
  records: object[];
  isShift: boolean;
  isAddMoreDisabled: boolean;
  handleRecordDelete: () => void;
  handleDeleteCancel: () => void;
  handleCancel: (e: any, user: string) => void;
  handleSubmit: () => void;
}

export interface RecordsData {
  campaignType: string;
  email: string;
  id: string;
  promoCode: string;
  staffId: string;
}

export interface IRecordsProps {
  records: RecordsData[];
  isShift: boolean;
  handleRecordDelete: (records: object[]) => void;
  handleCancel: any;
  handleSubmit: () => void;
  handleDeleteCancel: any;
  t: any;
}

export interface IPageHeaderProps {
  userName: string;
  title: string;
}
export interface IPromoCodeListProps {
  isPromoCodeLoading?: boolean;
  selectedPromoCodeValue: object[];
  handleSelect: (e: ChangeEvent<HTMLSelectElement>) => void;
  startDate: string;
  endDate: string;
  defaultVal: string;
  promoCodeList: any;
}

export interface IQrCodeState {
  isModalOpen: boolean;
  isShift: boolean;
  isDeleteRecordDisabled: boolean;
}
export interface IQrCodeProps {
  QrCodeList: any;
  getPromoCodeList: any;
  getStaffDataList: any;
  saveQrListInState: any;
  clearQrListInState: any;
  sendEmail: any;
  promoCodeList: [];
  t: any;
  staffDataList: [];
  isStaffIdLoading: any;
  isPromoCodeLoading: any;
  EmailMessage: string;
  updateEmailStatus: any;
  emailLoader: boolean;
  name: string;
  StatusModalState?: boolean;
}

export interface IPromoCode {
  allowMgmCodeInput: boolean;
  dynamicTncEn: 'string';
  dynamicTncZh: 'string';
  mgmCodeValidation: boolean;
  mpCode: 'string';
  promoCode: 'string';
  promoCodeValidateEndDate: 'yyyy-MM-dd';
  promoCodeValidateStartDate: 'yyyy-MM-dd';
  promoId: 'string';
}
