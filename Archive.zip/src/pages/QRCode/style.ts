import styledComponents from 'styled-components';

export const Subtitle = styledComponents.div`
  font-size:12px;
  color:#999;
  text-align:left;
  padding-top:10px;
  p{
    font-size:14px;
    margin-top:10px
  }
`;
Subtitle.displayName = 'Subtitle';

export const Wrapper = styledComponents.div`
    display:flex;
    width: 1200px;
    margin: 0 auto;
    flex-direction:column;
`;
Wrapper.displayName = 'Wrapper';

export const TextArea = styledComponents.textarea`
  font-size: 18px;
  color: #000000;
  outline:0;
  width: 100%;
  max-width:100%;
  height: 100px;
  padding:2px 10px;
  border: 1px solid #dadee6;
  box-shadow: none;
  border-radius: 0;
  font-weight: 500;
  box-sizing:border-box;
  &:focus{
    font-weight: 400;
  }
`;

TextArea.displayName = 'TextArea';

export const LeftCol = styledComponents.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  margin-top: 0px;
`;
LeftCol.displayName = 'LeftCol';

export const RightCol = styledComponents.div`
  display: flex;
  flex-direction: column;
  width: 60%;
  align-items: center;
  justify-content: center;

`;
RightCol.displayName = 'RightCol';

export const Img = styledComponents.img`
  min-height:300px;
  min-width:300px;
  padding:24px;
  display:flex
`;

export const ListWrapper = styledComponents.div`
  display: flex;
  justify-content: space-between;
  margin-bottom:24px;
`;
ListWrapper.displayName = 'ListWrapper';
