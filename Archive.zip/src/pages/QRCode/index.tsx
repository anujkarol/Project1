/* eslint-disable import/no-unresolved */
import React, { Suspense } from 'react';
import { v4 } from 'uuid';
import Button from '../../components/Button';
import { ButtonWrapper } from '../BDE/styles';
import Loader from '../../components/Loader';
import PageHeader from '../Common/PageHeader';
import Records from './Records';
import { Wrapper } from './style';
import { Add } from '../../components/icons/Add';
import { Cancel } from '../../components/icons/Cancel';
import { IQrCodeState, IQrCodeProps } from './interface';
import { EmailListObjectWithId } from '../../redux/actions/interface';

const AddRecordModal = React.lazy(() => import('./RecordModal'));
const Status = React.lazy(() => import('../Common/StatusModal'));

const QRRecords = (
  staffId: any,
  emailIds: string,
  promoCode: string,
  campaignType: string,
) => {
  if (staffId.length > 0) {
    return staffId.map((staffIdItem: any) => ({
      emailIds,
      staffId: staffIdItem,
      promoCode,
      campaignType,
      id: v4(),
    }));
  }

  return [
    {
      emailIds,
      staffId: '',
      promoCode,
      campaignType,
      id: v4(),
    },
  ];
};

class QrCode extends React.Component<IQrCodeProps, IQrCodeState> {
  constructor(props: IQrCodeProps) {
    super(props);
    this.state = {
      isModalOpen: false,
      isShift: false,
      isDeleteRecordDisabled: true,
    };
  }

  componentDidMount() {
    const { QrCodeList } = this.props;
    const { isDeleteRecordDisabled } = this.state;
    if (QrCodeList.length !== 0) {
      this.setState({
        isDeleteRecordDisabled: !isDeleteRecordDisabled,
      });
    }
  }

  handleModalState = () => {
    const { isModalOpen } = this.state;

    const { getPromoCodeList, getStaffDataList } = this.props;
    getPromoCodeList();
    getStaffDataList();

    this.setState({
      isModalOpen: !isModalOpen,
    });
  };

  handleAddMoreClick = (
    emailIds: string,
    staffId: object[],
    promoCode: string,
    campaignType: string,
  ) => {
    const { isModalOpen } = this.state;
    const { saveQrListInState, QrCodeList } = this.props;

    const newRecords = QRRecords(staffId, emailIds, promoCode, campaignType);

    const updatedRecords: EmailListObjectWithId[] = [].concat(
      QrCodeList,
      ...newRecords,
    );

    this.setState({
      isModalOpen: !isModalOpen,
      isDeleteRecordDisabled: false,
    });
    saveQrListInState(updatedRecords);
  };

  handleCancel = () => {
    const { clearQrListInState } = this.props;
    clearQrListInState();
    this.setState({
      isDeleteRecordDisabled: true,
    });
  };

  handleDeleteCancel = () => {
    const { isShift } = this.state;
    this.setState({
      isShift: !isShift,
    });
  };

  handleDelete = () => {
    this.handleDeleteCancel();
  };

  handleRecordDelete = (recordsData: any): void => {
    const { QrCodeList, saveQrListInState } = this.props;
    const oldRecords = [...QrCodeList];
    const newRecords: EmailListObjectWithId[] | [] = oldRecords.filter(
      x => !recordsData.includes(x),
    );
    saveQrListInState(newRecords);

    this.setState({
      isDeleteRecordDisabled: newRecords.length < 1,
      isShift: !(newRecords.length < 1),
    });
  };

  handleSubmit = () => {
    const { sendEmail, QrCodeList } = this.props;
    const generateQrData: EmailListObjectWithId[] = QrCodeList.map(
      (data: any) => ({
        staffId: data.staffId,
        promoCode: data.promoCode,
        emailIds: data.emailIds,
        campaignType: data.campaignType !== 'Partner' ? 'ROAD_SHOW' : 'PARTNER',
      }),
    );

    sendEmail(generateQrData);
  };

  statusHandleCloseModal = (): void => {
    const { updateEmailStatus } = this.props;
    updateEmailStatus(false);
    this.handleCancel();
  };

  render() {
    const { isModalOpen, isShift, isDeleteRecordDisabled } = this.state;
    const {
      promoCodeList = [],
      t,
      staffDataList = [],
      QrCodeList = [],
      isStaffIdLoading,
      isPromoCodeLoading,
      EmailMessage,
      emailLoader,
      name,
      StatusModalState = false,
    } = this.props;

    return (
      <Wrapper>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <PageHeader title="QR Code Generator" userName={name} />
          <ButtonWrapper style={{ marginTop: '40px' }}>
            <Button
              component="button"
              capitalize={false}
              onClick={this.handleModalState}
              disabled={isShift}
              use="ghost"
              size="medium"
            >
              <Add />
              {t('buttons.create_records')}
            </Button>
            <Button
              component="button"
              capitalize={false}
              onClick={this.handleDelete}
              disabled={isDeleteRecordDisabled}
              use="ghost"
              size="medium"
              sequence="last"
            >
              <Cancel />
              {t('buttons.delete_records')}
            </Button>
          </ButtonWrapper>
        </div>
        <Records
          records={QrCodeList}
          isShift={isShift}
          handleRecordDelete={this.handleRecordDelete}
          handleCancel={this.handleCancel}
          handleDeleteCancel={this.handleDeleteCancel}
          handleSubmit={this.handleSubmit}
          t={t}
        />
        {emailLoader && <Loader />}

        <Suspense fallback={<Loader />}>
          {isModalOpen && (
            <AddRecordModal
              isShow={isModalOpen}
              promoCodeList={promoCodeList}
              staffCodeList={staffDataList}
              handleModalState={this.handleModalState}
              handleAddMoreClick={this.handleAddMoreClick}
              isPromoCodeLoading={isPromoCodeLoading}
              isStaffIdLoading={isStaffIdLoading}
              t={t}
            />
          )}

          <Status
            isShow={StatusModalState}
            closeModal={this.statusHandleCloseModal}
            style={{ marginTop: '50px' }}
            icon={!EmailMessage ? 'warning' : 'success'}
            message={EmailMessage}
          />
        </Suspense>
      </Wrapper>
    );
  }
}

export default QrCode;
