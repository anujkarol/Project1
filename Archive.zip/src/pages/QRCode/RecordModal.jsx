import React, { useState } from 'react';

import { LeftCol, ListWrapper } from './style';
import ActionButton from './ActionButton';
import Input from '../../components/Input/Input';
import Modal from '../../components/Modal';
import Radio from '../../components/Radio';
import { emailValidation } from '../../helpers/validations';
import MultiSelect from '../../components/Multiselect';
import Loader from '../../components/Loader';

const RecordModal = ({
  t,
  handleModalState,
  promoCodeList,
  staffCodeList,
  isShow,
  isStaffIdLoading,
  isPromoCodeLoading,
  handleAddMoreClick,
}) => {
  const [email, setEmail] = useState('');
  const [emailErr, setEmailError] = useState('');
  const [staffId, setStaffId] = useState([]);
  const [campaignType, setCampaignType] = useState('Partner');
  const [selectedPromoCode, setSelectedPromoCode] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndtDate] = useState('');

  const onChangeHandler = e => {
    const { value } = e.target;
    const emailError = emailValidation(value);
    setEmail(value);
    setEmailError(emailError);
  };

  const handleRadioChange = e => {
    const { value } = e.target;
    setCampaignType(value);
  };

  const handleAddClick = () => {
    handleAddMoreClick(email, staffId, selectedPromoCode, campaignType);
  };

  const clearForm = () => {
    setEmail('');
    setEmailError(false);
  };

  const setValues = (selectValues, labelField) => {
    if (labelField === 'promoCode') {
      if (selectValues.length) {
        setSelectedPromoCode(selectValues[0].promoCode);
        setStartDate(selectValues[0].validityStartDate);
        setEndtDate(selectValues[0].validityEndDate);
      } else {
        setSelectedPromoCode([]);
        setStartDate('');
        setEndtDate('');
      }
    } else {
      setStaffId(selectValues);
    }
  };

  const checkError = () => {
    if (email !== '' && !emailErr) {
      if (campaignType === 'Partner' && selectedPromoCode.length === 0) {
        return true;
      }
      if (campaignType !== 'Partner' && staffId.length === 0) {
        return true;
      }
      return false;
    }
    return true;
  };

  const btnDisabled = checkError();
  const isStaffIdDropdownDisabled = campaignType === 'Partner';
  if (isStaffIdLoading || isPromoCodeLoading) return <Loader />;

  return (
    <Modal
      isShow={isShow}
      isCloseIcon
      handleCloseModal={handleModalState}
      title="Add Record to Generate QR Code"
    >
      <div
        style={{
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'center',
        }}
      >
        <LeftCol>
          <Input
            name="email"
            value={email}
            type="email"
            label={t('labels.email')}
            handleInputChange={onChangeHandler}
            error={emailErr}
            errorMessage={t('errors.error_email')}
            inFieldClear={email.length}
            clearField={clearForm}
          />
          <ListWrapper>
            <div style={{ width: '48%' }}>
              <MultiSelect
                multi
                handle
                options={staffCodeList}
                valueField="staffId"
                labelField="staffId"
                title="Staff Id"
                dropdownRenderer
                contentRenderer
                placeholder="Select Staff Id"
                selectedValues={setValues}
                disabled={isStaffIdDropdownDisabled}
                searchable={false}
                clearable
                closeOnSelect={false}
              />
            </div>
            <div style={{ width: '48%' }}>
              <MultiSelect
                multi={false}
                handle
                options={promoCodeList}
                valueField="promoCode"
                values={[]}
                labelField="promoCode"
                title="Promo Code"
                dropdownRenderer={false}
                contentRenderer={false}
                placeholder="Select Promo Code"
                selectedValues={setValues}
                searchable={false}
                clearable
                closeOnSelect
              />
              <div
                style={{
                  textAlign: 'left',
                  color: '#999',
                  marginTop: '16px',
                  fontSize: '14px',
                }}
              >
                <p style={{ display: 'flex', justifyContent: 'space-between' }}>
                  {t('labels.start_date')}
                  <span>{startDate}</span>
                </p>
                <p
                  style={{
                    marginTop: '8px',
                    display: 'flex',
                    justifyContent: 'space-between',
                  }}
                >
                  {t('labels.end_date')}
                  <span>{endDate}</span>
                </p>
              </div>
            </div>
          </ListWrapper>

          <Radio
            value={campaignType}
            title={['Partner', 'Branch + Roadshow']}
            name="Partner"
            isChecked={campaignType}
            handleInputChange={e => handleRadioChange(e)}
            radioLayout="inline"
            label="Generate QR Code for"
          />
        </LeftCol>
      </div>

      <ActionButton
        handlePrimary={handleAddClick}
        isDisabled={btnDisabled}
        handleSecondary={clearForm}
        labels={['Add', 'Clear']}
      />
    </Modal>
  );
};

export default RecordModal;
