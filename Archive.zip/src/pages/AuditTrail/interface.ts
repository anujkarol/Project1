export interface IRecord {
  uploadedBy: string;
  uploadTime: string;
  fileKey: string;
  fileName: string;
  status: string;
  failReason: string;
}

export interface IAuditTrailProps {
  name: string;
  getAuditList: (documentType: string) => void;
  records: IRecord[];
  isDownloaded: boolean;
  isFileDownloaded: boolean;
  downloadFile: (documentType: string, fileName: string) => void;
}

export interface IAuditRecords {
  records: IRecord[];
  isDownloaded: boolean;
  handleDownloadFile: (item: any) => void;
}
