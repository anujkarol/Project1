import React, { useEffect, ChangeEvent, useState } from 'react';
import { useTranslation } from 'react-i18next';
import AuditRecords from './AuditRecords';
import PageHeader from '../Common/PageHeader';
import { Wrapper, ButtonWrapper } from './styles';
import Button from '../../components/Button';
import { IAuditTrailProps, IRecord } from './interface';
import { GLOBAL_CONFIG } from '../../helpers/global';
import Radio from '../../components/Radio/index';
import {
  BDE_STAFF_TAB,
  PROMO_CODE_TAB,
  STAFF_LABEL,
} from '../../redux/constants';
import Loader from '../../components/Loader';

const RadioButtonsLabels = ['Staff', 'Promo'];
const STAFF = STAFF_LABEL;

const selectedTab = (value: string) => {
  return value === STAFF ? BDE_STAFF_TAB : PROMO_CODE_TAB;
};
const AuditTrail: React.FC<IAuditTrailProps> = ({
  name = '',
  getAuditList,
  records = [],
  isDownloaded = false,
  downloadFile,
  isFileDownloaded,
}) => {
  const { t } = useTranslation();

  const [radioValue, setRadiovalue] = useState('Staff');

  const handleRefresh = (): void => {
    const documentType: string = selectedTab(radioValue);
    getAuditList(documentType);
  };

  const handleRadioChange = (e: ChangeEvent<HTMLInputElement>): void => {
    const { value } = e.target as HTMLInputElement;
    const documentType: string = selectedTab(value);

    setRadiovalue(value);
    getAuditList(documentType);
  };

  useEffect(() => {
    getAuditList(BDE_STAFF_TAB);
  }, [getAuditList]);

  const handleDownloadFile = (record: IRecord) => {
    const { fileKey, fileName } = record;
    downloadFile(fileKey, fileName);
  };

  return (
    <Wrapper>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <PageHeader title={GLOBAL_CONFIG.PAGE4} userName={name} />
        <ButtonWrapper style={{ marginTop: '40px' }}>
          <Button
            component="button"
            capitalize={false}
            onClick={handleRefresh}
            use="oval"
            size="medium"
          >
            {t('buttons.refresh')}
          </Button>
        </ButtonWrapper>
      </div>
      <Radio
        value={radioValue}
        title={RadioButtonsLabels}
        name="codeMaintenance"
        isChecked={radioValue}
        handleInputChange={(e: ChangeEvent<HTMLInputElement>) =>
          handleRadioChange(e)
        }
        radioLayout="inline"
      />
      <br />
      {isFileDownloaded && <Loader />}
      <AuditRecords
        records={records}
        isDownloaded={isDownloaded}
        handleDownloadFile={handleDownloadFile}
      />
    </Wrapper>
  );
};
export default AuditTrail;
