import React, { ReactNode } from 'react';
import { v4 } from 'uuid';
import { Column } from '../../components/Table/Column';
import { Row } from '../../components/Table/Row';
import { Table } from '../../components/Table';
import { IAuditRecords, IRecord } from './interface';
import TableHeader from '../Common/TableHeader';
import Button from '../../components/Button/index';

const colWidth = [100, 180, 200, 70, 300];
const headers = ['1BankId', 'Timestamp', 'File Name', 'Status', 'Reason'];

const LazyLoader = React.lazy(() => import('../../components/Loader'));
const NoRecords = React.lazy(() => import('../Common/TableNoRecord'));

const AuditRecords: React.FC<IAuditRecords> = ({
  records = [],
  isDownloaded = false,
  handleDownloadFile,
}) => {
  if (isDownloaded) return <LazyLoader />;

  const tableRows = records.map(
    (item: IRecord): ReactNode => (
      <Row key={v4()} header={false}>
        <Column width={100}>{item.uploadedBy}</Column>
        <Column width={180}>{item.uploadTime}</Column>
        <Column width={200}>
          <Button
            component="a"
            capitalize={false}
            onClick={() => handleDownloadFile(item)}
            use="ghost"
            size="medium"
            sequence="first"
            style={{ minWidth: 'inherit' }}
          >
            {item.fileName}
          </Button>
        </Column>
        <Column width={70}>{item.status}</Column>
        <Column width={300}>{item.failReason}</Column>
      </Row>
    ),
  );

  return (
    <Table isShift={false}>
      <TableHeader
        isShift={false}
        header
        tablelHeaders={headers}
        colWidth={colWidth}
      />
      {!records.length ? <NoRecords /> : tableRows}
    </Table>
  );
};

export default AuditRecords;
