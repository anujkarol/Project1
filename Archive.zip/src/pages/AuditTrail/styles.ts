import styledComponents from 'styled-components';

export const ButtonWrapper = styledComponents.div`
    display:flex;
    justify-content:center;
    min-height:100px;
    align-items: center;
`;
ButtonWrapper.displayName = 'ButtonWrapper';

export const Wrapper = styledComponents.div`
    display:flex;
    width: 1200px;
    margin: 0 auto;
    flex-direction:column;
`;
Wrapper.displayName = 'Wrapper';
