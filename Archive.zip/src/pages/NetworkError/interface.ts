export interface INetworkErrorProps {
  handleBtnTryAgain: (e: React.MouseEvent<HTMLButtonElement>) => void;
  message?: string;
}
