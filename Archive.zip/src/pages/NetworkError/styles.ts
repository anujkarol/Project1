import styledComponents from 'styled-components';

export const Container = styledComponents.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    vertical-align: middle;
    height: calc(100vh - 66px);
    top: 0;
    width: 100%;
    justify-content: center;
    left: 0;
`;
Container.displayName = 'Container';

export const Title = styledComponents.h3`
    margin-bottom:12px;
    padding-bottom:10px;
`;
Title.displayName = 'Title';
