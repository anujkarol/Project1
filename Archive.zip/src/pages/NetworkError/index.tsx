import React, { ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { Container, Title } from './styles';

import Button from '../../components/Button';
import { INetworkErrorProps } from './interface';
import errorImg from '../../assets/images/error-img.png';

const NetworkError: React.FC<INetworkErrorProps> = ({
  handleBtnTryAgain,
  message = '',
}): ReactElement => {
  const { t } = useTranslation();
  return (
    <Container>
      <img src={errorImg} alt="DBS Error" />
      <Title>{message}</Title>
      <p>{t('errors.try_again')}</p>
      <div style={{ marginTop: '20px' }}>
        <Button
          component="button"
          capitalize={false}
          onClick={handleBtnTryAgain}
          use="primary"
          size="normal"
        >
          {t('buttons.retry')}
        </Button>
      </div>
    </Container>
  );
};

export default NetworkError;
