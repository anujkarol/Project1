import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Container,
  ErrorBanner,
  Header,
  InputWrapper,
  Label,
  LoginForm,
  LoginInput,
} from './styles';

import Button from '../../components/Button';
import Error from '../../components/Error/Error';
import { ILoginProps } from './interface';
import logo from '../../assets/images/dbs_logo.svg';
import Loader from '../../components/Loader';

const LoginPage: React.FC<ILoginProps> = ({
  message,
  loginSubmit,
  isLoading = false,
}) => {
  const [userName, handleUsername] = useState<string>('');
  const [password, handlePassword] = useState<string>('');
  const [emptyError, handleEmptyError] = useState<boolean>(false);
  const errorMessage = message;
  const { t } = useTranslation();

  useEffect(() => {
    localStorage.removeItem('token');
  }, []);

  const handleSubmit = (e: React.ChangeEvent<HTMLFormElement>): void => {
    e.preventDefault();
    if (userName && password) {
      loginSubmit(userName, password);
    } else {
      handleEmptyError(true);
    }
  };

  return (
    <Container>
      <LoginForm>
        <Header>
          <img src={logo} alt="DBS Graceful Degradation" />
          <span>{t('header')}</span>
        </Header>
        {errorMessage !== '' && (
          <ErrorBanner>
            <strong>{t('note')}:</strong>
            &nbsp;
            {errorMessage}
          </ErrorBanner>
        )}

        <form name="form">
          {isLoading && <Loader />}
          <InputWrapper>
            <LoginInput
              type="text"
              name="user1BankId"
              value={userName}
              className={userName !== '' ? ' not-empty' : ''}
              onChange={(e: any) => handleUsername(e.target.value)}
              autoComplete="off"
              maxLength={30}
            />

            <Label htmlFor="User Name">{t('labels.1BankId')}</Label>
            <Error isShow={emptyError && !userName}>
              {t('errors.userName_required')}
            </Error>
          </InputWrapper>
          <InputWrapper>
            <LoginInput
              type="password"
              name="password"
              value={password}
              className={password !== '' ? ' not-empty' : ''}
              onChange={(e: any) => handlePassword(e.target.value)}
              autoComplete="off"
              maxLength={20}
            />
            <Label htmlFor="Password">{t('labels.password')}</Label>
            <Error isShow={emptyError && !password}>
              {t('errors.password_required')}
            </Error>
          </InputWrapper>
          <div style={{ marginTop: '24px' }}>
            <Button
              component="button"
              style={{ width: '100%' }}
              capitalize={false}
              onClick={(e: any) => handleSubmit(e)}
              use="primary"
              size="normal"
            >
              {t('buttons.submit')}
            </Button>
          </div>
        </form>
      </LoginForm>
    </Container>
  );
};
export default LoginPage;
