import { Input } from './../../components/Input/styles';
import bgImage from '../../assets/images/pre-login-background.png';
import styledComponents from 'styled-components';

export const Wrapper = styledComponents.div`
  display: flex;
  justify-content: flex-end;
  align-items:flex-start;
`;
Wrapper.displayName = 'Wrapper';

export const Container = styledComponents.div`
  background-repeat: no-repeat;
  position: fixed;
  height: 100%;
  width: 100%;
  background: url(${bgImage});
  background-size:cover;
  display: flex;
  justify-content: flex-end;
  align-items:flex-start;
`;
Container.displayName = 'Container';

export const LoginForm = styledComponents.div`
  width: 290px;
  margin-right: 130px;
  margin-top: 10%;
  background: #fff;
  border-top: 4px solid #ff3333;
  padding: 20px 24px 30px 24px;
  border-left: 1px solid #666872;
  box-shadow: 0 10px 10px 0 rgba(0, 0, 0, 0.30), 0 6px 3px 0 rgba(0, 0, 0, 0.23);
`;
LoginForm.displayName = 'LoginForm';

export const Header = styledComponents.div`
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  color: #909090;
  font-size: 13px;
  margin-top: 8px;
  font-weight: bold;
  img {
    width: 30%;
    height: 1%;
    margin-bottom:8px;
  }
`;
Header.displayName = 'Header';

export const InputWrapper = styledComponents.div`
  position: relative;
  margin: 0;
  padding: 0;
  margin: 48px 0px 0px;
`;
InputWrapper.displayName = 'InputWrapper';

export const Label = styledComponents.label`
  color: #909090;
  font-size: 14px;
  font-weight: 400;
  position: absolute;
  pointer-events: none;
  left: 0;
  top: 2px;
  text-align: left;
  transition: .2s ease all;
`;
Label.displayName = 'Label';

export const LoginInput = styledComponents(Input)`
  border: 0;
  height: 30px;
  padding: 1px 0 5px 0px;
  border-bottom: 1px solid #dadee6;
  transition: .2s ease all;
  margin-bottom:6px;
  &:focus:not([readonly])~label{
    color: #909090;
    top: -25px;
    font-size: 12px;
  }
  &:valid.not-empty~label {
    color: #909090;
    top: -25px;
    font-size: 12px;
  }
`;

LoginInput.displayName = 'LoginInput';

export const ErrorBanner = styledComponents.div`
  background: #ffe8e8;
  color: #ff3333;
  border: 1px solid #ff3333;
  margin-bottom: 12px;
  font-size: 12px;
  padding: 8px 6px;
  margin: 0 auto;
  margin-top: 15px;
`;
ErrorBanner.displayName = 'ErrorBanner';
