export interface ILoginProps {
  loginSubmit: (userName: string, password: string) => void;
  message: string;
  isLoading?: boolean;
}
