import { History } from 'history';

export interface IHomeProps {
  isServerDown: () => void;
  userRole: string;
  logout: () => void;
  history: History;
  isServerDownMessage: string;
  returnToPage: () => void;
}
