import React, { Suspense, useState, useEffect } from 'react';
import { WithTranslation } from 'react-i18next';
import { history } from '../../helpers/history';

import { GLOBAL_CONFIG } from '../../helpers/global';
import Header from '../../components/Header';
import { IHomeProps } from './interface';
import Loader from '../../components/Loader';
import NetworkError from '../NetworkError';

const Home: React.FC<IHomeProps & WithTranslation> = ({
  userRole = 'maker',
  isServerDown,
  logout,
  isServerDownMessage = '',
  returnToPage,
  t,
}) => {
  const [activeHeader, setHeader] = useState<string>(
    GLOBAL_CONFIG.DEFAULT_PAGE,
  );

  const handleHeader = (header: string): void => {
    setHeader(header);
  };
  const handleBtnTryAgain = (): void => {
    setHeader(activeHeader);
    returnToPage();
  };

  const handleLogOut = (): void => {
    history.push('/');
    logout();
  };

  useEffect(() => {
    window.addEventListener('storage', function(e) {
      if (
        e.oldValue != null &&
        e.newValue != null &&
        e.oldValue !== e.newValue
      ) {
        history.push('/');
      }
    });

    if (!userRole) {
      history.push('/');
    }
  });
  let Component: any = null;

  switch (activeHeader) {
    case GLOBAL_CONFIG.PAGE4:
      Component = React.lazy(() =>
        import('../../redux/containers/AuditTrailContainer'),
      );
      break;
    case GLOBAL_CONFIG.PAGE3:
      Component = React.lazy(() =>
        import('../../redux/containers/ManageUserContainer'),
      );
      break;
    case GLOBAL_CONFIG.PAGE2:
      Component = React.lazy(() =>
        import('../../redux/containers/BdeContainer'),
      );
      break;

    default:
      Component = React.lazy(() =>
        import('../../redux/containers/QrCodeContainer'),
      );

      break;
  }

  const navItems =
    userRole.toLocaleLowerCase() === 'maker'.toLocaleLowerCase() ||
    userRole.toLocaleLowerCase() === 'checker'.toLocaleLowerCase()
      ? [
          GLOBAL_CONFIG.PAGE1,
          GLOBAL_CONFIG.PAGE2,
          GLOBAL_CONFIG.PAGE3,
          GLOBAL_CONFIG.PAGE4,
        ]
      : [GLOBAL_CONFIG.PAGE1, GLOBAL_CONFIG.PAGE2, GLOBAL_CONFIG.PAGE4];
  return (
    <>
      <Header
        activeHeader={handleHeader}
        activeTitle={activeHeader}
        navItems={navItems}
        handleLogOut={handleLogOut}
      />
      {!isServerDown ? (
        <Suspense fallback={<Loader />}>
          <Component />
        </Suspense>
      ) : (
        <NetworkError
          handleBtnTryAgain={handleBtnTryAgain}
          message={isServerDownMessage}
        />
      )}
    </>
  );
};

export default Home;
