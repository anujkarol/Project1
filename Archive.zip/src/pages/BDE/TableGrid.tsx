import React from 'react';
import { ITableGrid } from './interface';
import Loader from '../../components/Loader';
import { Table } from '../../components/Table';
import TableNoRecord from '../Common/TableNoRecord';
import TableHeader from '../Common/TableHeader';
import Rows from '../../components/Table/Rows';

const TableGrid: React.FC<ITableGrid> = ({
  rows = [],
  message = '',
  isPartnerDataLoading = false,
  tablelHeaders = [],
  colWidth = [],
}) => {
  if (isPartnerDataLoading) {
    return <Loader />;
  }

  return (
    <div>
      <Table isShift={false}>
        <TableHeader
          isShift={false}
          header
          tablelHeaders={tablelHeaders}
          colWidth={colWidth}
        />
        {!rows.length ? (
          <TableNoRecord message={message} />
        ) : (
          Rows(rows, colWidth)
        )}
      </Table>
    </div>
  );
};

TableGrid.displayName = 'TableGrid';

export default TableGrid;
