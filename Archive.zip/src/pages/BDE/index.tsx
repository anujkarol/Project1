import React, { Suspense, ChangeEvent } from 'react';
import { WithTranslation } from 'react-i18next';
import { Wrapper } from './styles';
import Radio from '../../components/Radio';
import PageHeader from '../Common/PageHeader';
import ActionButtons from './ActionButtons';
import Loader from '../../components/Loader';
import Pagination from '../../components/Pagination';
import { GLOBAL_CONFIG } from '../../helpers/global';
import { IBDEState, IBDEProps } from './interface';
import {
  BDE_STAFF_TAB,
  PROMO_CODE_TAB,
  STAFF_LABEL,
} from '../../redux/constants';

const Status = React.lazy(() => import('../Common/StatusModal'));
const UploadComponent = React.lazy(() => import('../Common/UploadFileModal'));
const TabContent = React.lazy(() => import('./TableGrid'));

const StaffColWidth = [50, 100, 150, 150, 150, 150, 300];
const PromoColWidth = [120, 120, 120, 80, 80, 80, 200, 200];

const STAFF = STAFF_LABEL;

class BDE extends React.Component<IBDEProps & WithTranslation, IBDEState> {
  constructor(props: IBDEProps & WithTranslation) {
    super(props);
    this.state = {
      isShowUploadModal: false,
      currentPage: 1,
      selectMsgSubTab: STAFF,
    };
  }

  componentDidMount() {
    const { getPartnerList } = this.props;

    const selectedTab = this.selectedTab();
    getPartnerList(1, selectedTab);
  }

  selectedTab = (): string => {
    const { selectMsgSubTab } = this.state;
    const selectedTab: string =
      selectMsgSubTab === STAFF ? BDE_STAFF_TAB : PROMO_CODE_TAB;

    return selectMsgSubTab === STAFF ? BDE_STAFF_TAB : PROMO_CODE_TAB;
  };

  handleMsgChange = (e: ChangeEvent<HTMLInputElement>): void => {
    const { value } = e.target as HTMLInputElement;
    const { getPartnerList } = this.props;
    const ListType: string = value === STAFF ? BDE_STAFF_TAB : PROMO_CODE_TAB;
    getPartnerList(1, ListType);
    this.setState({
      selectMsgSubTab: value,
      currentPage: 1,
    });
  };

  handleDownload = (): void => {
    const { fileDownload } = this.props;

    const documentType: string = this.selectedTab();
    fileDownload(documentType);
  };

  handleUploadModal = (): void => {
    const { isShowUploadModal } = this.state;
    this.setState({
      isShowUploadModal: !isShowUploadModal,
    });
  };

  handleFileUpload = (attachment: File): void => {
    const { fileUpload } = this.props;
    const documentType: string = this.selectedTab();
    const formData: FormData = new FormData();
    formData.append('file', attachment);
    fileUpload(formData, documentType);
    this.setState({
      isShowUploadModal: false,
    });
  };

  statusHandleCloseModal = (): void => {
    const { updateMessage, getPartnerList, uploadStatus } = this.props;
    updateMessage('');
    const ListType: string = this.selectedTab();
    if (uploadStatus) getPartnerList(1, ListType);

    this.setState({
      isShowUploadModal: false,
    });
  };

  handlePageChange = (currentPage = 1): void => {
    const { getPartnerList } = this.props;
    const ListType: string = this.selectedTab();
    getPartnerList(currentPage, ListType);
    this.setState({
      currentPage,
    });
  };

  handleRefresh = () => {
    const { getPartnerList } = this.props;
    const ListType: string = this.selectedTab();
    getPartnerList(1, ListType);
  };

  render() {
    const { currentPage, isShowUploadModal, selectMsgSubTab } = this.state;

    const {
      t,
      isPartnerDataLoading = false,
      isDownloaded = false,
      partnerList = [],
      pageSize = GLOBAL_CONFIG.ITEMS_PER_PAGE,
      isServerDown = false,
      isUploading = false,
      totalRecords = 1,
      uploadStatus = false,
      name = '',
      message = '',
      tablelHeaders = [],
    } = this.props;

    if (isServerDown) return;

    const Staff = `${t('labels.staff')}`;
    const Promo = `${t('labels.promo')}`;
    const RadioButtonsLabels = [Staff, Promo];
    const colWidth = selectMsgSubTab === Staff ? StaffColWidth : PromoColWidth;

    return (
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          marginBottom: '24px',
        }}
      >
        {(isDownloaded || isUploading) && <Loader />}

        <Wrapper>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <PageHeader title={GLOBAL_CONFIG.PAGE2} userName={name} />
            <ActionButtons
              handleUploadModal={this.handleUploadModal}
              handleDownload={this.handleDownload}
              isDisabled={!partnerList.length}
              selectedTab={selectMsgSubTab}
              handleRefresh={this.handleRefresh}
            />
          </div>
          <Radio
            value={selectMsgSubTab}
            title={RadioButtonsLabels}
            name="codeMaintenance"
            isChecked={selectMsgSubTab}
            handleInputChange={(e: ChangeEvent<HTMLInputElement>) =>
              this.handleMsgChange(e)
            }
            radioLayout="inline"
          />
          <br />
          <br />

          <Suspense fallback={<Loader />}>
            <TabContent
              rows={partnerList}
              tablelHeaders={tablelHeaders}
              message={t('table.msg_no_record')}
              isPartnerDataLoading={isPartnerDataLoading}
              colWidth={colWidth}
            />
            {isShowUploadModal && (
              <UploadComponent
                isShow={isShowUploadModal}
                closeModal={this.handleUploadModal}
                handleFileUpload={this.handleFileUpload}
                title={t('labels.file_upload')}
              />
            )}

            <Status
              isShow={message !== ''}
              closeModal={this.statusHandleCloseModal}
              style={{ marginTop: '50px' }}
              icon={!uploadStatus ? 'warning' : 'success'}
              message={message}
            />
          </Suspense>
          <Pagination
            itemsCount={totalRecords}
            pageSize={pageSize}
            currentPage={currentPage}
            onPageChange={this.handlePageChange}
          />
        </Wrapper>
      </div>
    );
  }
}

export default BDE;
