import React, { ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { ButtonWrapper } from '../BDE/styles';
import Button from '../../components/Button';
import { IActionButtonsProps } from './interface';
import { Download } from '../../components/icons/Download';
import { Upload } from '../../components/icons/Upload';

const ActionButtons: React.FC<IActionButtonsProps> = ({
  handleUploadModal,
  handleDownload,
  isDisabled = true,
  selectedTab,
  handleRefresh,
}): ReactElement => {
  const { t } = useTranslation();
  return (
    <ButtonWrapper style={{ marginTop: '40px' }}>
      <Button
        component="button"
        capitalize={false}
        onClick={handleUploadModal}
        use="ghost"
        size="medium"
      >
        <Upload width="24px" height="24px" />
        {t('buttons.upload')}
        &nbsp;
        {selectedTab}
      </Button>

      <Button
        component="button"
        capitalize={false}
        onClick={handleDownload}
        disabled={isDisabled}
        use="ghost"
        size="medium"
      >
        <Download width="24px" height="24px" />
        {t('buttons.download')}
      </Button>

      <Button
        component="button"
        capitalize={false}
        onClick={handleRefresh}
        disabled={isDisabled}
        use="oval"
        size="medium"
      >
        {t('buttons.refresh')}
      </Button>
    </ButtonWrapper>
  );
};

export default ActionButtons;
