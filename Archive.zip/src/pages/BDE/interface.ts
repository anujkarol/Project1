interface IStaffList {
  email: string;
  remark: string;
  staffId: string;
  staffName: string;
  staffSlNo: string;
  validityEndDate: string;
  validityStartDate: string;
}

interface IPromoList {
  allowMgmCodeInput: string;
  dynamicTncEn: string;
  dynamicTncZh: string;
  mgmCodeValidation: string;
  mpCode: string;
  promoCode: string;
  promoCodeValidateEndDate: string;
  promoCodeValidateStartDate: string;
  promoId?: string;
}

export interface IActionButtonsProps {
  handleUploadModal: () => void;
  handleDownload: () => void;
  isDisabled: boolean;
  selectedTab: string;
  handleRefresh: () => void;
}
export interface ITableGrid {
  rows: IStaffList[] | IPromoList[];
  message: string;
  isPartnerDataLoading: boolean;
  tablelHeaders: string[];
  colWidth: number[];
}
export interface IBDEProps {
  getPartnerList: (pageNo: number, ListType: string) => void;
  fileDownload: (documentType: string) => void;
  fileUpload: (formData: FormData, documentType: string) => void;
  updateMessage: (message: string) => void;
  uploadStatus: boolean;
  userName: string;
  isPartnerDataLoading: boolean;
  isDownloaded: boolean;
  partnerList: Array<IStaffList> | Array<IPromoList>;
  pageSize: number;
  isServerDown: boolean;
  isUploading: boolean;
  totalRecords: number;
  message: string;
  name: string;
  tablelHeaders: string[];
}
export interface IBDEState {
  isShowUploadModal: boolean;
  currentPage: number;
  selectMsgSubTab: string;
}
