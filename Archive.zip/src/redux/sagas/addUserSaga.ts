import { call, put } from 'redux-saga/effects';
import { ADMIN_ADD_USER_FAILURE, ADMIN_ADD_USER_SUCCESS } from '../constants';

import endPoints from '../../helpers/endPoints';
import { instance } from '../../helpers/interceptor';
import { authHeader } from '../../helpers/authHeader';

export function* addUserSaga(action: any) {
  const headers = authHeader();
  try {
    const { user } = action;
    yield call(() =>
      instance({
        method: 'POST',
        url: endPoints.createUser,
        data: user,
        headers,
      }),
    );

    const message = 'User Successfully Added';
    yield put({ type: ADMIN_ADD_USER_SUCCESS, status: true, message });
  } catch (e) {
    yield put({
      type: ADMIN_ADD_USER_FAILURE,
      message: e.message,
      status: false,
    });
  }
}
