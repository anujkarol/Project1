import { put, call } from 'redux-saga/effects';
import { EMAIL_SEND_FAILURE, EMAIL_SEND_SUCCESS } from '../constants';
import { instance } from '../../helpers/interceptor';
import endPoints from '../../helpers/endPoints';
import { authHeader } from '../../helpers/authHeader';

export function* emailSaga(action: any) {
  const headers = authHeader();
  try {
    const { list } = action;
    yield call(() =>
      instance({
        method: 'POST',
        url: endPoints.sendEmail,
        data: list,
        timeout: 200000,
        headers,
      }),
    );

    yield put({
      type: EMAIL_SEND_SUCCESS,
      message: 'Email Sent Successfully',
    });
  } catch (error) {
    yield put({
      type: EMAIL_SEND_FAILURE,
      message: '',
    });
  }
}
