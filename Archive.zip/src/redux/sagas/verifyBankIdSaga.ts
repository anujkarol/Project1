import { call, put } from 'redux-saga/effects';
import { VERIFY_1BANKID_SUCCESS, VERIFY_1BANKID_FAILURE } from '../constants';

import { instance } from '../../helpers/interceptor';
import endPoints from '../../helpers/endPoints';
import { authHeader } from '../../helpers/authHeader';
import { IVerifyUserActionTypes } from '../actions/interface';

export function* verifyBankIdSaga(action: IVerifyUserActionTypes) {
  const headers = authHeader();
  try {
    const response = yield call(() =>
      instance({
        method: 'GET',
        url: `${endPoints.verifyUser}/${action.userName}`,
        headers,
      }),
    );
    const { name, mail, userName } = response.data;
    yield put({
      type: VERIFY_1BANKID_SUCCESS,
      userName,
      mail,
      name,
      isValid1BankId: true,
      message: '',
    });
  } catch (error) {
    yield put({
      type: VERIFY_1BANKID_FAILURE,
      message: error.message,
    });
  }
}
