import { call, put } from 'redux-saga/effects';
import { AUDIT_TRAIL_SUCCESS, AUDIT_TRAIL_FAILURE } from '../constants';

import endPoints from '../../helpers/endPoints';
import { instance } from '../../helpers/interceptor';
import { authHeader } from '../../helpers/authHeader';

export function* auditSaga(action: any) {
  const headers = authHeader();

  const { documentType } = action;

  try {
    const response = yield call(() =>
      instance({
        method: 'GET',
        url: `${endPoints.audit}?documentType=${documentType}`,
        headers,
      }),
    );
    const { data } = response;

    yield put({
      type: AUDIT_TRAIL_SUCCESS,
      list: data,
    });
  } catch (error) {
    yield put({
      type: AUDIT_TRAIL_FAILURE,
      message: error.message,
    });
  }
}
