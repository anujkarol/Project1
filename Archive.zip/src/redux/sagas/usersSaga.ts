import { call, put } from 'redux-saga/effects';
import {
  ADMIN_REQUESTED_USER_SUCCESS,
  ADMIN_REQUESTED_USER_FAILURE,
} from '../constants';

import { instance } from '../../helpers/interceptor';
import { authHeader } from '../../helpers/authHeader';
import endPoints from '../../helpers/endPoints';

export function* usersSaga() {
  const headers = authHeader();
  try {
    const response = yield call(() =>
      instance({
        method: 'GET',
        url: endPoints.retrieveUserList,
        headers,
      }),
    );

    const { data } = response;

    yield put({
      type: ADMIN_REQUESTED_USER_SUCCESS,
      users: data,
    });
  } catch (error) {
    yield put({
      type: ADMIN_REQUESTED_USER_FAILURE,
      users: [],
    });
  }
}
