import { put, call } from 'redux-saga/effects';
import {
  GET_BDE_PARTNER_DATA_SUCCESS,
  GET_BDE_PARTNER_DATA_FAILURE,
} from '../constants';
import endPoints from '../../helpers/endPoints';
import { instance } from '../../helpers/interceptor';
import { authHeader } from '../../helpers/authHeader';

export function* getBdeDataSaga(action: any) {
  const headers = authHeader();
  const { selectedTab, page } = action;
  try {
    const response = yield call(() =>
      instance({
        method: 'GET',
        url: `${endPoints.partnerList}?page=${page - 1}&type=${selectedTab}`,
        headers,
      }),
    );
    let partnerList: object[];
    const { totalRecords, headerNames } = response.data;

    const TableHeaders: any = headerNames.split(',');

    if (selectedTab === 'BDE_STAFF') {
      partnerList = response.data.staffDetails;
    } else {
      partnerList = response.data.promoDetails;
    }
    yield put({
      type: GET_BDE_PARTNER_DATA_SUCCESS,
      partnerList,
      totalRecords,
      headerNames: TableHeaders,
    });
  } catch (error) {
    yield put({
      type: GET_BDE_PARTNER_DATA_FAILURE,
      message: error.message,
    });
  }
}
