import { put, call } from 'redux-saga/effects';
import { PROMO_CODE_SUCCESS, PROMO_CODE_FAILURE } from '../constants';
import { instance } from '../../helpers/interceptor';
import endPoints from '../../helpers/endPoints';
import { authHeader } from '../../helpers/authHeader';

export function* promoCodeSaga() {
  const headers = authHeader();
  try {
    const response = yield call(() =>
      instance({
        method: 'GET',
        url: endPoints.getPromoCode,
        headers,
      }),
    );

    const { data } = response;

    yield put({
      type: PROMO_CODE_SUCCESS,
      list: data,
    });
  } catch (error) {
    yield put({
      type: PROMO_CODE_FAILURE,
      message: error.message,
    });
  }
}
