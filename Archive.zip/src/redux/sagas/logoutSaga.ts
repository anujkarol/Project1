import { put, call } from 'redux-saga/effects';
import { LOGOUT_SUCCESS, LOGOUT_FAILURE } from '../constants';
import { instance } from '../../helpers/interceptor';
import endPoints from '../../helpers/endPoints';
import { authHeader } from '../../helpers/authHeader';

export function* logoutSaga() {
  const headers = authHeader();
  try {
    localStorage.removeItem('token');

    yield call(() =>
      instance({
        method: 'POST',
        url: endPoints.logout,
        headers,
      }),
    );

    yield put({
      type: LOGOUT_SUCCESS,
    });
  } catch (error) {
    yield put({
      type: LOGOUT_FAILURE,
      message: error.message,
    });
  }
}
