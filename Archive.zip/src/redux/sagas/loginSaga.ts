import { call, put } from 'redux-saga/effects';

import endPoints from '../../helpers/endPoints';
import { instance } from '../../helpers/interceptor';
import { LOGIN_SUCCESS, LOGIN_FAILURE } from '../constants';
import { history } from '../../helpers/history';

export function* LoginSaga(action: any) {
  const { userName, password } = action;
  try {
    const data = {
      userName,
      password,
    };

    const response = yield call(() =>
      instance({
        method: 'POST',
        url: endPoints.login,
        data,
      }),
    );

    const { accessToken, role, name } = response.data;


    yield put({
      type: LOGIN_SUCCESS,
      role,
      name
    });

    localStorage.setItem('token', accessToken);
    history.push('/Home');
  } catch (error) {
    localStorage.removeItem('token');
    yield put({
      type: LOGIN_FAILURE,
      message: error.message,
    });
  }
}
