import { call, put } from 'redux-saga/effects';

import endPoints from '../../helpers/endPoints';
import { instance } from '../../helpers/interceptor';
import { DOWNLOAD_FILE_SUCCESS, DOWNLOAD_FILE_FAILURE } from '../constants';
import { authHeader } from '../../helpers/authHeader';

export function* downloadApprovalSaga(action: any) {
  const headers = authHeader();

  try {
    const { documentType, fileName } = action;

    const saveFileName = !fileName ? documentType : fileName;

    const response = yield call(() =>
      instance({
        method: 'GET',
        url: `${endPoints.downloadFileWithFileKey}?fileKey=${documentType}`,
        headers,
        responseType: 'arraybuffer',
      }),
    );

    const type = response.headers['content-type'];

    const blob =
      typeof File === 'function'
        ? new File([response.data], fileName, { type })
        : new Blob([response.data], { type });

    const URL = window.URL || window.webkitURL;
    const downloadUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `${saveFileName}`;
    document.body.appendChild(link);
    link.click();

    yield put({
      type: DOWNLOAD_FILE_SUCCESS,
    });
  } catch (error) {
    yield put({
      type: DOWNLOAD_FILE_FAILURE,
      message: error.message,
    });
  }
}
