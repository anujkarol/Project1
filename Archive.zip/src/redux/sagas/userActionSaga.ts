import { call, put } from 'redux-saga/effects';

import endPoints from '../../helpers/endPoints';
import { instance } from '../../helpers/interceptor';

import { USER_ACTION_SUCCESS, USER_ACTION_FAILURE } from '../constants';
import { authHeader } from '../../helpers/authHeader';

export function* userActionSaga(action: any) {
  const headers = authHeader();

  try {
    const userAction = action.action;
    const userActionUpdated =
      userAction === 'approve' ? 'APPROVED' : 'REJECTED';
    const data = {
      userAction: userActionUpdated,
      userName: action.name,
    };
    yield call(() =>
      instance({
        method: 'POST',
        url: endPoints.userAction,
        headers,
        data,
      }),
    );

    yield put({
      type: USER_ACTION_SUCCESS,
      message: `User ${userAction} Succesfully`,
      status: true,
    });
  } catch (error) {
    yield put({
      type: USER_ACTION_FAILURE,
      message: error.message,
      status: false,
    });
  }
}
