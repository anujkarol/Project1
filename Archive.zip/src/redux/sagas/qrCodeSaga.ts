import { put } from 'redux-saga/effects';
import {
  GET_QR_CODE_LIST_SUCCESS,
  GET_QR_CODE_LIST_FAILURE,
} from '../constants';

export function* QrSaga(action: any) {
  try {
    const { list } = action;
    yield put({
      type: GET_QR_CODE_LIST_SUCCESS,
      list,
    });
  } catch (error) {
    yield put({
      type: GET_QR_CODE_LIST_FAILURE,
      message: error.message,
    });
  }
}
