import { put, call } from 'redux-saga/effects';
import { UPLOAD_SUCCESS, UPLOAD_FAILURE } from '../constants/index';
import { instance } from '../../helpers/interceptor';
import endPoints from '../../helpers/endPoints';

import { authHeader } from '../../helpers/authHeader';
import { UploadStart } from '../actions/interface';

export function* uploadSaga(action: UploadStart) {
  const headers = authHeader();
  const { file, documentType = 'PROMO_CODE' } = action;
  try {
    yield call(() =>
      instance({
        method: 'POST',
        url: `${endPoints.upload}?documentType=${documentType}`,
        data: file,
        headers,
      }),
    );
    yield put({
      type: UPLOAD_SUCCESS,
      message: 'File Uploaded Successfully',
      isUploaded: true,
    });
  } catch (error) {
    yield put({
      type: UPLOAD_FAILURE,
      message: error.message,
      isUploaded: false,
    });
  }
}
