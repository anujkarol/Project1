import { LOGOUT, LOGOUT_FAILURE, LOGOUT_SUCCESS } from '../constants';
import { ILogoutActionTypes } from './interface';

const logout = (): ILogoutActionTypes => ({
  type: LOGOUT,
});

const logoutSuccess = (): ILogoutActionTypes => ({
  type: LOGOUT_SUCCESS,
});

const logoutFailure = (): ILogoutActionTypes => ({
  type: LOGOUT_FAILURE,
});

export const logoutAction = {
  logout,
  logoutSuccess,
  logoutFailure,
};
