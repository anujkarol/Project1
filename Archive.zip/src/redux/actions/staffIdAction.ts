import { IStaffIdActionTypes } from './interface';
import { STAFF_ID, STAFF_ID_FAILURE, STAFF_ID_SUCCESS } from '../constants';

const getStaffIdList = (): IStaffIdActionTypes => ({
  type: STAFF_ID,
});

const getStaffIdListSuccess = (list: object[]): IStaffIdActionTypes => ({
  type: STAFF_ID_SUCCESS,
  list,
});

const getStaffIdListFailure = (message: string): IStaffIdActionTypes => ({
  type: STAFF_ID_FAILURE,
  message,
});

export const staffIdAction = {
  getStaffIdList,
  getStaffIdListSuccess,
  getStaffIdListFailure,
};
