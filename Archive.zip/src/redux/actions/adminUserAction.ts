import {
  ADMIN_REQUESTED_USER,
  ADMIN_REQUESTED_USER_FAILURE,
  ADMIN_REQUESTED_USER_SUCCESS,
} from '../constants';

import { IAdminUserActionTypes } from './interface';

const requestUserInitiate = (): IAdminUserActionTypes => ({
  type: ADMIN_REQUESTED_USER,
});

const requestUserSuccess = (users: object[] = []): IAdminUserActionTypes => ({
  type: ADMIN_REQUESTED_USER_SUCCESS,
  users,
});

const requestUserError = (
  message: string,
  users: [] = [],
): IAdminUserActionTypes => ({
  type: ADMIN_REQUESTED_USER_FAILURE,
  users,
});

export const adminUserAction = {
  requestUserInitiate,
  requestUserSuccess,
  requestUserError,
};
