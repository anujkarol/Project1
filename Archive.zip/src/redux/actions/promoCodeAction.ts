import { IPromoCodeActionTypes } from './interface';
import {
  PROMO_CODE,
  PROMO_CODE_FAILURE,
  PROMO_CODE_SUCCESS,
} from '../constants';

const getPromoCode = (): IPromoCodeActionTypes => ({
  type: PROMO_CODE,
});

const getPromoCodeSuccess = (list: object[]): IPromoCodeActionTypes => ({
  type: PROMO_CODE_SUCCESS,
  list,
});

const getPromoCodeFailure = (message: string): IPromoCodeActionTypes => ({
  type: PROMO_CODE_FAILURE,
  message,
});

export const promoCodeAction = {
  getPromoCode,
  getPromoCodeSuccess,
  getPromoCodeFailure,
};
