import {
  USER_ACTION,
  USER_ACTION_SUCCESS,
  USER_ACTION_FAILURE,
} from '../constants';
import { IUserActionTypes } from './interface';

const userAction = (name: string, action: string): IUserActionTypes => ({
  type: USER_ACTION,
  name,
  action,
});

const userActionSuccess = (
  message: string,
  status: boolean,
): IUserActionTypes => ({
  type: USER_ACTION_SUCCESS,
  message,
  status,
});

const userActionFailure = (
  message: string,
  status: boolean,
): IUserActionTypes => ({
  type: USER_ACTION_FAILURE,
  message,
  status,
});

export const userActions = {
  userAction,
  userActionSuccess,
  userActionFailure,
};
