import {
  EMAIL,
  EMAIL_SEND_FAILURE,
  EMAIL_SEND_SUCCESS,
  EMAIL_SEND_STATUS,
} from '../constants';
import { IEmailActionTypes, EmailListObject } from './interface';

const sendEmailList = (list: EmailListObject[] = []): IEmailActionTypes => ({
  type: EMAIL,
  list,
});

const sendEmailSuccess = (message: string): IEmailActionTypes => ({
  type: EMAIL_SEND_SUCCESS,
  message,
});

const sendEmailFailure = (message: string): IEmailActionTypes => ({
  type: EMAIL_SEND_FAILURE,
  message,
});

const sendEmailStatus = (modalState: boolean): any => ({
  type: EMAIL_SEND_STATUS,
  modalState,
});

export const emailAction = {
  sendEmailList,
  sendEmailSuccess,
  sendEmailFailure,
  sendEmailStatus,
};
