import {
  GET_BDE_PARTNER_DATA,
  GET_BDE_PARTNER_DATA_FAILURE,
  GET_BDE_PARTNER_DATA_SUCCESS,
} from '../constants';
import { IBdeDataActionTypes } from './interface';

const getPartnerList = (
  page = 1,
  selectedTab: string,
): IBdeDataActionTypes => ({
  type: GET_BDE_PARTNER_DATA,
  page,
  selectedTab,
});

const getPartnerListSuccess = (
  partnerList: object[],
  totalRecords: number,
  headerNames: '',
): IBdeDataActionTypes => ({
  type: GET_BDE_PARTNER_DATA_SUCCESS,
  partnerList,
  totalRecords,
  headerNames,
});

const getPartnerListFailure = (
  message: string,
  headerNames: string,
): IBdeDataActionTypes => ({
  type: GET_BDE_PARTNER_DATA_FAILURE,
  message,
  headerNames,
});

export const getBdeDataAction = {
  getPartnerList,
  getPartnerListSuccess,
  getPartnerListFailure,
};
