import {
  VERIFY_1BANKID,
  VERIFY_1BANKID_FAILURE,
  VERIFY_1BANKID_SUCCESS,
} from '../constants';

import { IVerifyUserActionTypes } from './interface';

const verify1BankIdActionInitiate = (
  userName = '',
): IVerifyUserActionTypes => ({
  type: VERIFY_1BANKID,
  userName,
});

const verify1BankIdActionSuccess = (
  userName = '',
  message = '',
  isValid1BankId = true,
  name: '',
  mail: '',
): IVerifyUserActionTypes => ({
  type: VERIFY_1BANKID_SUCCESS,
  userName,
  message,
  isValid1BankId,
  name,
  mail,
});

const verify1BankIdActionFailure = (
  userName = '',
  message = '',
  isValid1BankId = false,
  name: '',
  mail: '',
): IVerifyUserActionTypes => ({
  type: VERIFY_1BANKID_FAILURE,
  userName,
  message,
  isValid1BankId,
  name,
  mail,
});

export const verifyBankIdAction = {
  verify1BankIdActionInitiate,
  verify1BankIdActionSuccess,
  verify1BankIdActionFailure,
};
