import { LOGIN_FAILURE, LOGIN_SUBMIT, LOGIN_SUCCESS } from '../constants';
import { ILoginActionTypes } from './interface';

const loginSubmit = (
  userName: string,
  password: string,
): ILoginActionTypes => ({
  type: LOGIN_SUBMIT,
  userName,
  password,
});

const loginSuccess = (
  token: string,
  role = '',
  name = '',
): ILoginActionTypes => ({
  type: LOGIN_SUCCESS,
  token,
  role,
  name,
});

const loginFailure = (message = '', role = ''): ILoginActionTypes => ({
  type: LOGIN_FAILURE,
  message,
  role,
});

export const loginAction = {
  loginSubmit,
  loginSuccess,
  loginFailure,
};
