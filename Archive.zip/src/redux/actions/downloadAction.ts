import { DOWNLOAD, DOWNLOAD_FAILURE, DOWNLOAD_SUCCESS } from '../constants';
import { IDownloadActionTypes } from './interface';

const downloadStart = (documentType: string): IDownloadActionTypes => ({
  type: DOWNLOAD,
  documentType,
});

const downloadSuccess = (message: string): IDownloadActionTypes => ({
  type: DOWNLOAD_SUCCESS,
  message,
});

const downloadFailure = (message: string): IDownloadActionTypes => ({
  type: DOWNLOAD_FAILURE,
  message,
});

export const downloadAction = {
  downloadStart,
  downloadSuccess,
  downloadFailure,
};
