import {
  AUDIT_TRAIL,
  AUDIT_TRAIL_FAILURE,
  AUDIT_TRAIL_SUCCESS,
} from '../constants';
import { IAuditActionTypes } from './interface';

const getAuditReport = (documentType: string): IAuditActionTypes => ({
  type: AUDIT_TRAIL,
  documentType,
});

const getAuditReportSuccess = (list: object[] = []): IAuditActionTypes => ({
  type: AUDIT_TRAIL_SUCCESS,
  list,
});

const getAuditReportFailure = (message: string): IAuditActionTypes => ({
  type: AUDIT_TRAIL_FAILURE,
  message,
});

export const auditAction = {
  getAuditReport,
  getAuditReportSuccess,
  getAuditReportFailure,
};
