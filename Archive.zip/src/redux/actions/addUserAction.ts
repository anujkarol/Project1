import {
  ADMIN_ADD_USER,
  ADMIN_ADD_USER_FAILURE,
  ADMIN_ADD_USER_SUCCESS,
  ADMIN_ADD_USER_STATUS,
} from '../constants';
import { IAddUserActionTypes } from './interface';

const addUser = (user: FormData): IAddUserActionTypes => ({
  type: ADMIN_ADD_USER,
  user,
});

const addUserSuccess = ({
  name = '',
  mail = '',
  message = '',
  isValid1BankId = true,
}): IAddUserActionTypes => ({
  type: ADMIN_ADD_USER_SUCCESS,
  status: true,
  message,
  name,
  mail,
  isValid1BankId,
});

const addUserFailure = ({
  name = '',
  mail = '',
  message = '',
  isValid1BankId = true,
}): IAddUserActionTypes => ({
  type: ADMIN_ADD_USER_FAILURE,
  status: false,
  message,
  name,
  mail,
  isValid1BankId,
});

const addUserStatus = (userAddedStatus: boolean): IAddUserActionTypes => ({
  type: ADMIN_ADD_USER_STATUS,
  userAddedStatus,
});

export const addUserAction = {
  addUser,
  addUserSuccess,
  addUserFailure,
  addUserStatus,
};
