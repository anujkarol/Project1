import {
  DOWNLOAD_FILE,
  DOWNLOAD_FILE_FAILURE,
  DOWNLOAD_FILE_SUCCESS,
} from '../constants';
import { IDownloadFileActionTypes } from './interface';
import { BDE_STAFF_TAB } from '../constants/index';

export const downloadFileStart = (
  documentType = BDE_STAFF_TAB,
  fileName = '',
): IDownloadFileActionTypes => ({
  type: DOWNLOAD_FILE,
  documentType,
  fileName,
});

export const downloadFileSuccess = (
  message: string,
): IDownloadFileActionTypes => ({
  type: DOWNLOAD_FILE_SUCCESS,
  message,
});

export const downloadFileFailure = (
  message: string,
): IDownloadFileActionTypes => ({
  type: DOWNLOAD_FILE_FAILURE,
  message,
});

export const downloadFileActions = {
  downloadFileStart,
  downloadFileSuccess,
  downloadFileFailure,
};
