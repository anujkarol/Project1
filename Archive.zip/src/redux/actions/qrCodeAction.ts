import {
  GET_QR_CODE_LIST,
  GET_QR_CODE_LIST_FAILURE,
  GET_QR_CODE_LIST_SUCCESS,
  CLEAR_QR_CODE_LIST,
} from '../constants';
import { IQrCodeTypes, EmailListObject } from './interface';

const generateQrCode = (list: EmailListObject[] = []): IQrCodeTypes => ({
  type: GET_QR_CODE_LIST,
  list,
});

const generateQrCodeSuccess = (list: EmailListObject[] = []): IQrCodeTypes => ({
  type: GET_QR_CODE_LIST_SUCCESS,
  list,
});

const clearQrCodeList = (list: EmailListObject[] = []): IQrCodeTypes => ({
  type: CLEAR_QR_CODE_LIST,
  list,
});

const generateQrCodeFailure = (message: string): IQrCodeTypes => ({
  type: GET_QR_CODE_LIST_FAILURE,
  message,
});

export const qrCodeAction = {
  generateQrCode,
  generateQrCodeSuccess,
  clearQrCodeList,
  generateQrCodeFailure,
};
