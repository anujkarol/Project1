import {
  UPLOAD,
  UPLOAD_FAILURE,
  UPLOAD_SUCCESS,
  UPDATE_MESSAGE,
} from '../constants';
import { IUploadActionTypes } from './interface';

const uploadStart = (
  file: FormData,
  documentType: string,
  isUploaded = false,
): IUploadActionTypes => ({
  type: UPLOAD,
  file,
  documentType,
  isUploaded,
});

const uploadSuccess = (
  message: string,
  isUploaded: boolean,
): IUploadActionTypes => ({
  type: UPLOAD_SUCCESS,
  message,
  isUploaded,
});

const uploadFailure = (
  message: string,
  isUploaded: boolean,
): IUploadActionTypes => ({
  type: UPLOAD_FAILURE,
  message,
  isUploaded,
});

const updateMessage = (message: string): IUploadActionTypes => ({
  type: UPDATE_MESSAGE,
  message,
});

export const uploadAction = {
  uploadStart,
  uploadSuccess,
  uploadFailure,
  updateMessage,
};
