import { withTranslation } from 'react-i18next';
import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import {
  emailAction,
  qrCodeAction,
  staffIdAction,
  promoCodeAction,
} from '../actions';
import { AppState } from '../store';
import QrCode from '../../pages/QRCode';
import {
  EmailListObject,
  IEmailActionTypes,
  IPromoCodeActionTypes,
  IQrCodeTypes,
  IStaffIdActionTypes,
} from '../actions/interface';

const mapStateToProps = (state: AppState) => ({
  QrCodeList: state.qrCodeReducer.list,
  EmailMessage: state.emailReducer.message,
  StatusModalState: state.emailReducer.modalState,
  message: state.qrCodeReducer.message,
  isLoading: state.qrCodeReducer.isLoading,
  staffDataList: state.staffIdReducer.list,
  emailLoader: state.emailReducer.isLoading,
  promoCodeList: state.promoCodeReducer.list,
  isStaffIdLoading: state.promoCodeReducer.isLoading,
  isPromoCodeLoading: state.promoCodeReducer.isLoading,
  name: state.loginReducer.name,
});

const mapDispatchToProps = (
  dispatch: Dispatch<
    | IEmailActionTypes
    | IPromoCodeActionTypes
    | IStaffIdActionTypes
    | IQrCodeTypes
  >,
) => ({
  sendEmail: (list: EmailListObject[]) =>
    dispatch(emailAction.sendEmailList(list)),
  getPromoCodeList: () => dispatch(promoCodeAction.getPromoCode()),
  getStaffDataList: () => dispatch(staffIdAction.getStaffIdList()),
  saveQrListInState: (list: EmailListObject[]) =>
    dispatch(qrCodeAction.generateQrCode(list)),
  clearQrListInState: () => dispatch(qrCodeAction.clearQrCodeList()),
  updateEmailStatus: (modalState: boolean) => {
    dispatch(emailAction.sendEmailStatus(modalState));
  },
});

export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(QrCode),
);
