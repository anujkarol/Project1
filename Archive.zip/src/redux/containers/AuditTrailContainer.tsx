import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { Dispatch } from 'redux';
import { auditAction, downloadFileActions } from '../actions';
import { AppState } from '../store';
import AuditTrail from '../../pages/AuditTrail';
import {
  IAuditActionTypes,
  IDownloadFileActionTypes,
} from '../actions/interface';

const mapStateToProps = (state: AppState) => ({
  name: state.loginReducer.name,
  records: state.auditReducer.list,
  isFileDownloaded: state.downloadFileReducer.isFileDownloaded,
  isDownloaded: state.auditReducer.isDownloaded,
});
const mapDispatchToProps = (
  dispatch: Dispatch<IAuditActionTypes | IDownloadFileActionTypes>,
) => ({
  getAuditList: (documentType = '') =>
    dispatch(auditAction.getAuditReport(documentType)),
  downloadFile: (documentType = '', fileName = '') =>
    dispatch(downloadFileActions.downloadFileStart(documentType, fileName)),
});

export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(AuditTrail),
);
