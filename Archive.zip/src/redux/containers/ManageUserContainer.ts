import { Dispatch } from 'redux';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import {
  adminUserAction,
  verifyBankIdAction,
  userActions,
  addUserAction,
  downloadFileActions,
} from '../actions';

import ManageUser from '../../pages/ManageUser';
import { AppState } from '../store';
import {
  IAdminUserActionTypes,
  IAddUserActionTypes,
  IDownloadFileActionTypes,
  IUserActionTypes,
  IVerifyUserActionTypes,
} from '../actions/interface';

const mapStateToProps = (state: AppState) => {
  const { users, isLoading: isUserListLoading } = state.adminUserReducer;
  const { name, role } = state.loginReducer;
  const { isFileDownloaded } = state.downloadFileReducer;

  const {
    status: isUserAdded,
    message: isUserAddedMessage,
    userAddedStatus,
  } = state.addUserReducer;

  return {
    role,
    users,
    name,
    isUserListLoading,
    isUserAdded,
    isUserAddedMessage,
    userAddedStatus,
    isFileDownloaded,
  };
};

const mapDispatchToProps = (
  dispatch: Dispatch<
    | IAdminUserActionTypes
    | IVerifyUserActionTypes
    | IUserActionTypes
    | IAddUserActionTypes
    | IDownloadFileActionTypes
  >,
) => ({
  getUsers: () => {
    dispatch(adminUserAction.requestUserInitiate());
  },
  verifyUser: (userId = '') => {
    dispatch(verifyBankIdAction.verify1BankIdActionInitiate(userId));
  },
  userAction: (name: string, action: string) => {
    dispatch(userActions.userAction(name, action));
  },
  downloadFile: (documentType = '') => {
    dispatch(downloadFileActions.downloadFileStart(documentType));
  },
  userAddStatus: (userAddedStatus: boolean) => {
    dispatch(addUserAction.addUserStatus(userAddedStatus));
  },
});

export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(ManageUser),
);
