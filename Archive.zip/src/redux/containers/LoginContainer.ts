import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { Dispatch } from 'redux';

import LoginPage from '../../pages/Login';
import { AppState } from '../store';
import { ILoginActionTypes } from '../actions/interface';
import { loginAction } from '../actions/loginAction';

const mapStateToProps = (state: AppState) => ({
  token: state.loginReducer.token,
  message: state.loginReducer.errorMessage,
  isLoading: state.loginReducer.isLoading,
  isServerDown: state.serverReducer.isServerDown,
});

const mapDispatchToProps = (dispatch: Dispatch<ILoginActionTypes>) => ({
  loginSubmit: (userName: string, password: string) =>
    dispatch(loginAction.loginSubmit(userName, password)),
});

export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(LoginPage),
);
