import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { Dispatch } from 'redux';
import { downloadAction, getBdeDataAction, uploadAction } from '../actions';

import BDE from '../../pages/BDE';
import { AppState } from '../store';
import {
  IBdeDataActionTypes,
  IUploadActionTypes,
  IDownloadActionTypes,
} from '../actions/interface';

const mapStateToProps = (state: AppState) => ({
  partnerList: state.getBdeDataReducer.partnerList,
  isPartnerDataLoading: state.getBdeDataReducer.isPartnerListLoading,
  isServerDown: state.serverReducer.isServerDown,
  isUploading: state.uploadReducer.isLoading,
  isDownloaded: state.downloadReducer.isDownloaded,
  message: state.uploadReducer.message,
  totalRecords: state.getBdeDataReducer.totalRecords,
  uploadStatus: state.uploadReducer.isUploaded,
  name: state.loginReducer.name,
  tablelHeaders: state.getBdeDataReducer.headerNames,
});
const mapDispatchToProps = (
  dispatch: Dispatch<
    IBdeDataActionTypes | IUploadActionTypes | IDownloadActionTypes
  >,
) => ({
  getPartnerList: (page: number, selectedTab: string) =>
    dispatch(getBdeDataAction.getPartnerList(page, selectedTab)),
  fileUpload: (attachment: FormData, documentType: string) =>
    dispatch(uploadAction.uploadStart(attachment, documentType)),
  fileDownload: (documentType: string) =>
    dispatch(downloadAction.downloadStart(documentType)),
  updateMessage: (message: string) => {
    dispatch(uploadAction.updateMessage(message));
  },
});

export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(BDE),
);
