import { Dispatch } from 'redux';
import { connect } from 'react-redux';
import { addUserAction, adminUserAction, verifyBankIdAction } from '../actions';
import { AppState } from '../store';

import AddUser from '../../pages/ManageUser/AddUser';
import {
  IAdminUserActionTypes,
  IAddUserActionTypes,
  IVerifyUserActionTypes,
} from '../actions/interface';

const s = (state: AppState) => {
  const {
    isLoading: isVerifying,
    userName: verifyUserName,
    isValid1BankId,
    message,
    mail: email,
    name: verifyName,
  } = state.verifyBankIdReducer;

  return {
    isVerifying,
    verifyUserName,
    isValid1BankId,
    message,
    email,
    verifyName,
  };
};

const d = (
  dispatch: Dispatch<
    IAdminUserActionTypes | IVerifyUserActionTypes | IAddUserActionTypes
  >,
) => ({
  getUsers: () => {
    dispatch(adminUserAction.requestUserInitiate());
  },
  addUser: (user: FormData) => {
    dispatch(addUserAction.addUser(user));
  },
  verifyUser: (userName = '') => {
    dispatch(verifyBankIdAction.verify1BankIdActionInitiate(userName));
  },
});

export default connect(s, d)(AddUser);
