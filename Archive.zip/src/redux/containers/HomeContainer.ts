import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { Dispatch } from 'redux';
import Home from '../../pages/Home/Home';
import { AppState } from '../store';
import { ILogoutActionTypes, IServerActionTypes } from '../actions/interface';
import { logoutAction } from '../actions/logoutAction';
import { serverCheckAction } from '../actions/serverCheckAction';

const mapStateToProps = (state: AppState) => ({
  isServerDown: state.serverReducer.isServerDown,
  userRole: state.loginReducer.role,
  isServerDownMessage: state.serverReducer.message,
});

const mapDispatchToProps = (
  dispatch: Dispatch<IServerActionTypes | ILogoutActionTypes>,
) => ({
  logout: () => dispatch(logoutAction.logout()),
  returnToPage: () => dispatch(serverCheckAction.serverUpAction('Up')),
});
export default withTranslation()(
  connect(mapStateToProps, mapDispatchToProps)(Home),
);
