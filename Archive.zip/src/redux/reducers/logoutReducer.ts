import { LOGOUT, LOGOUT_FAILURE, LOGOUT_SUCCESS } from '../constants';
import { ILogOutReducerState } from './interface';
import { ILogoutActionTypes } from '../actions/interface';

const initialState: ILogOutReducerState = {
  isLoading: false,
};

const logoutReducer = (state = initialState, action: ILogoutActionTypes) => {
  switch (action.type) {
    case LOGOUT:
      return {
        ...state,
        isLoading: true,
      };
    case LOGOUT_SUCCESS:
      return {
        ...state,
        isLoading: false,
      };
    case LOGOUT_FAILURE:
      return {
        ...state,
        isLoading: false,
      };
    default:
      return state;
  }
};

export default logoutReducer;
