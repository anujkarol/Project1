import {
  EMAIL,
  EMAIL_SEND_FAILURE,
  EMAIL_SEND_SUCCESS,
  EMAIL_SEND_STATUS,
} from '../constants';
import { IEmailReducerState } from './interface';
import { IEmailActionTypes } from '../actions/interface';

const initialState: IEmailReducerState = {
  list: [],
  isLoading: false,
  message: '',
  modalState: false,
};

const emailReducer = (state = initialState, action: IEmailActionTypes) => {
  switch (action.type) {
    case EMAIL:
      return {
        ...state,
        isLoading: true,
      };
    case EMAIL_SEND_SUCCESS:
      return {
        ...state,
        isLoading: false,
        message: action.message,
        modalState: true,
      };
    case EMAIL_SEND_FAILURE:
      return {
        ...state,
        isLoading: false,
        message: action.message,
        modalState: true,
      };
    case EMAIL_SEND_STATUS:
      return {
        ...state,
        isLoading: false,
        modalState: action.modalState,
      };
    default:
      return state;
  }
};

export default emailReducer;
