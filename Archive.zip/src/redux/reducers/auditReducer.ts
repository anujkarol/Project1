import {
  AUDIT_TRAIL,
  AUDIT_TRAIL_SUCCESS,
  AUDIT_TRAIL_FAILURE,
} from '../constants';
import { IAuditActionTypes } from '../actions/interface';

const initialState: any = {
  documentType: 'Partner',
  isDownloaded: false,
  list: [],
};

const auditReducer = (state = initialState, action: IAuditActionTypes) => {
  switch (action.type) {
    case AUDIT_TRAIL:
      return {
        ...state,
        isDownloaded: true,
        documentType: action.documentType,
      };
    case AUDIT_TRAIL_SUCCESS:
      return {
        ...state,
        isDownloaded: false,
        list: action.list,
      };
    case AUDIT_TRAIL_FAILURE:
      return {
        ...state,
        isDownloaded: false,
        message: action.message,
        list: [],
      };
    default:
      return state;
  }
};

export default auditReducer;
