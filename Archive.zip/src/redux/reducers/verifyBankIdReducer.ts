import * as constants from '../constants';
import { IVerifyUserActionTypes } from '../actions/interface';

import { IVerifyState } from './interface';

const initialState: IVerifyState = {
  userName: '',
  error: '',
  isLoading: false,
  isValid1BankId: true,
  message: '',
  mail: '',
  name: '',
};

export default function verifyBankIdReducer(
  state = initialState,
  action: IVerifyUserActionTypes,
) {
  switch (action.type) {
    case constants.VERIFY_1BANKID:
      return {
        isLoading: true,
      };

    case constants.VERIFY_1BANKID_SUCCESS:
      return {
        isLoading: false,
        userName: action.userName,
        message: action.message,
        isValid1BankId: true,
        name: action.name,
        mail: action.mail,
      };

    case constants.VERIFY_1BANKID_FAILURE:
      return {
        isLoading: false,
        userName: '',
        isValid1BankId: false,
        message: action.message,
        name: '',
        mail: '',
      };

    default:
      return state;
  }
}
