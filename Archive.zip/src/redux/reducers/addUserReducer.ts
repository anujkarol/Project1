import * as constants from '../constants';

import { IAddUserActionTypes } from '../actions/interface';
import { IAddUserState } from './interface';

const initialState: IAddUserState = {
  isLoading: false,
  status: false,
  message: '',
  name: '',
  mail: '',
  userAddedStatus: false,
};

export default function addUserReducer(
  state = initialState,
  action: IAddUserActionTypes,
) {
  switch (action.type) {
    case constants.ADMIN_ADD_USER:
      return {
        ...state,
        user: action.user,
        isLoading: true,
        status: false,
        message: '',
      };

    case constants.ADMIN_ADD_USER_SUCCESS:
      return {
        isLoading: false,
        status: action.status,
        message: action.message,
        userAddedStatus: true,
      };

    case constants.ADMIN_ADD_USER_FAILURE:
      return {
        user: {},
        isLoading: false,
        status: action.status,
        message: action.message,
        name: '',
        mail: '',
        userAddedStatus: true,
      };

    case constants.ADMIN_ADD_USER_STATUS:
      return {
        ...state,
        userAddedStatus: action.userAddedStatus,
      };

    default:
      return state;
  }
}
