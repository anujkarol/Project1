import { IUserActionTypes } from '../actions/interface';
import * as types from '../constants';

const initialState = {
  userAction: 'APPROVED',
  userName: '',
  isLoading: false,
};

const userActionReducer = (state = initialState, action: IUserActionTypes) => {
  switch (action.type) {
    case types.USER_ACTION:
      return {
        isLoading: true,
      };
    case types.USER_ACTION_SUCCESS:
      return {
        ...state,
        message: action.message,
        isLoading: false,
      };
    case types.USER_ACTION_FAILURE:
      return {
        ...state,
        message: action.message,
        isLoading: false,
      };
    default:
      return state;
  }
};

export default userActionReducer;
