import * as constants from '../constants';

import { IAdminUserActionTypes } from '../actions/interface';
import { IAdminUserState } from './interface';

const initialState: IAdminUserState = {
  users: [],
  isLoading: false,
};

export default function adminUserReducer(
  state = initialState,
  action: IAdminUserActionTypes,
) {
  switch (action.type) {
    case constants.ADMIN_REQUESTED_USER:
      return {
        ...state,
        isLoading: true,
      };

    case constants.ADMIN_REQUESTED_USER_SUCCESS:
      return {
        ...state,
        users: action.users,
        isLoading: false,
      };

    case constants.ADMIN_REQUESTED_USER_FAILURE:
      return {
        ...state,
        users: [],
        isLoading: false,
      };

    default:
      return state;
  }
}
