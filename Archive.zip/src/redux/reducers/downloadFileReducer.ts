import {
  DOWNLOAD_FILE,
  DOWNLOAD_FILE_SUCCESS,
  DOWNLOAD_FILE_FAILURE,
} from '../constants';
import { IDownloadReducerState } from './interface';
import { IDownloadActionTypes } from '../actions/interface';

const initialState: any = {
  isFileDownloaded: false,
};

const downloadFileReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case DOWNLOAD_FILE:
      return {
        ...state,
        isFileDownloaded: true,
      };
    case DOWNLOAD_FILE_SUCCESS:
      return {
        ...state,
        isFileDownloaded: false,
      };
    case DOWNLOAD_FILE_FAILURE:
      return {
        ...state,
        isFileDownloaded: false,
        message: action.message,
      };
    default:
      return state;
  }
};

export default downloadFileReducer;
