import { ILoginReducerState } from './interface';
import { LOGIN_FAILURE, LOGIN_SUBMIT, LOGIN_SUCCESS } from '../constants';
import { ILoginActionTypes } from '../actions/interface';

const initialState: ILoginReducerState = {
  token: '',
  errorMessage: '',
  isLoading: false,
  role: '',
  name: '',
};

const loginReducer = (state = initialState, action: ILoginActionTypes) => {
  switch (action.type) {
    case LOGIN_SUBMIT:
      return {
        ...state,
        isLoading: true,
      };

    case LOGIN_SUCCESS:
      return {
        ...state,
        isLoading: false,
        token: action.token,
        role: action.role,
        name: action.name,
      };

    case LOGIN_FAILURE:
      return {
        ...state,
        isLoading: false,
        errorMessage: action.message,
        role: '',
      };

    default:
      return state;
  }
};

export default loginReducer;
