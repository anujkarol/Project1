import { IUploadReducerState } from './interface';
import {
  UPLOAD,
  UPLOAD_FAILURE,
  UPLOAD_SUCCESS,
  UPDATE_MESSAGE,
} from '../constants';
import { IUploadActionTypes } from '../actions/interface';

const initialState: IUploadReducerState = {
  attachment: '',
  isLoading: false,
  message: '',
  documentType: 'PROMO_CODE',
  isUploaded: false,
};

const uploadReducer = (state = initialState, action: IUploadActionTypes) => {
  switch (action.type) {
    case UPLOAD:
      return {
        ...state,
        isLoading: true,
        isUploaded: action.isUploaded,
      };
    case UPLOAD_SUCCESS:
      return {
        ...state,
        isLoading: false,
        message: action.message,
        isUploaded: action.isUploaded,
      };
    case UPLOAD_FAILURE:
      return {
        ...state,
        isLoading: false,
        attachment: '',
        message: action.message,
        documentType: '',
        isUploaded: action.isUploaded,
      };
    case UPDATE_MESSAGE:
      return {
        ...state,
        isLoading: false,
        message: action.message,
      };
    default:
      return state;
  }
};

export default uploadReducer;
