import { EmailListObject } from '../actions/interface';

export interface ILoginReducerState {
  token: string;
  errorMessage: string;
  isLoading: boolean;
  role: string;
  name: string;
}

export interface IEmailReducerState {
  list: EmailListObject[];
  isLoading: boolean;
  message: string;
  modalState: boolean;
}

export interface IPromoCodeReducerState {
  list: object;
  isLoading: boolean;
}

export interface IQRCodeReducerState {
  list: [];
  isLoading: boolean;
  message: string;
}

export interface IQRCodeReducerAction {
  message: string;
  list: object[];
  type: string;
}

export interface IServerReducerState {
  isServerDown: boolean;
  message: string;
}

export interface IUploadReducerState {
  attachment: FormData | string;
  isLoading: boolean;
  message: string;
  documentType: string;
  isUploaded: boolean;
}

export interface IDownloadReducerState {
  documentType: string;
  isDownloaded: boolean;
}

export interface IBDEReducerState {
  isServerDown: boolean;
  message: string;
}

export interface ILogOutReducerState {
  isLoading: boolean;
}

export interface IAddUserState {
  isLoading: boolean;
  status: boolean;
  message: string;
  name: string;
  mail: string;
  userAddedStatus: boolean;
}

export interface IUser {
  id: number;
  version: number;
}

export interface IAdminUserState {
  users: object[];
  isLoading: boolean;
}
export interface IVerifyState {
  userName: string;
  error: string;
  isLoading: boolean;
  isValid1BankId: boolean;
  message: string;
  name: string;
  mail: string;
}
