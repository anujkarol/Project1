import { applyMiddleware, compose } from 'redux';
import createSagaMiddleware from 'redux-saga';

const ColorsObject = {
  title: () => 'yellow',
  prevState: () => '#9E9E9E',
  action: () => 'white',
  nextState: () => 'cyan',
  error: () => '#ff3333',
};

const composeEnhancers =
  ((window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ &&
    (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({
      trace: true,
      traceLimit: 25,
    })) ||
  compose;

export const sagaMiddleware = createSagaMiddleware({
  onError(error) {
    setImmediate(() => {
      console.log('Saga Error handled from Middleware.ts', error);
      throw error;
    });
  },
});

const middleware = [sagaMiddleware];

if (process.env.NODE_ENV !== `development`) {
  const { createLogger } = require(`redux-logger`);
  const loggerMiddleware = createLogger({
    collapsed: true,
    duration: true,
    timestamp: true,
    level: 'info',
    colors: ColorsObject,
    logger: console,
    logErrors: true,
    diff: true,
  });
  middleware.push(loggerMiddleware);
}

export const Enhancers = composeEnhancers(applyMiddleware(...middleware));
