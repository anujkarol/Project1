const GLOBAL_CONFIG = {
  FILE_SIZE: 20000000,
  WARNING_TIME: 1000 * 60 * 4,
  SIGN_OUT_TIME: 1000 * 60 * 5,
  FILE_TYPES: ['csv'],
  FILE_TYPES_APPROVAL: [
    'jpeg',
    'png',
    'jpg',
    'msg',
    'eml',
    'pdf',
    'doc',
    'docx',
    'xls',
    'xlsx',
  ],
  ITEMS_PER_PAGE: 20,
  DEFAULT_PAGE: 'QR Code',
  PAGE1: 'QR Code',
  PAGE2: 'Code Maintenance',
  PAGE3: 'Manage User',
  PAGE4: 'Audit Trail',
  API_TIMEOUT: 50000,
  campaignTypePartner: 'PARTNER',
};

// https://adminserv-devdepfo-mdhk.dev.apps.cs.sgp.dbs.com/
// const API_URL_CONST = 'https://admin-service-mdhk.sit.apps.cs.sgp.dbs.com';
const urlVal = window.location.host;
let API_URL = '';
if (urlVal.match('prod') !== null)
  API_URL = 'https://admin-service-mdhk.prod.apps.cs.sgp.dbs.com';
else API_URL = 'https://admin-service-mdhk.uat.apps.cs.sgp.dbs.com';

const environmentConst = process.env.NODE_ENV;
export { GLOBAL_CONFIG, API_URL, environmentConst, urlVal };
