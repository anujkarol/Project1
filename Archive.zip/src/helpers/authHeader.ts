export const authHeader = () => {
  if (localStorage.getItem('token') !== null) {
    const storage: Storage = localStorage;
    const key = storage.getItem('token') || '';

    if (key) {
      return { Authorization: `Bearer ${key}` };
    }
    return { Authorization: '' };
  }
  return null;
};
