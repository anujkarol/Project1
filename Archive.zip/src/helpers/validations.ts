const regExCheckbasedOnEnv = () => {
  const urlVal = window.location.host;
  if (urlVal.match('prod') == null) {
    return /\w+([-+.']\w+)*[@+](1bank.dbs|dbs|uat1bank.dbs)\.com(\W|$)/;
  }

  return /\w+([-+.']\w+)*[@+](1bank.dbs|dbs)\.com(\W|$)/;
};

export const emailValidation: any = (data: string) => {
  const regEx: RegExp = regExCheckbasedOnEnv();
  const results: string[] = data.replace(/\s/g, '').split(/,|;/);
  let error = false;
  results.forEach(result => {
    regEx.test(result) ? (error = false) : (error = true);
  });

  return error;
};

export const checkFileSize = (file: File, size: number): boolean => {
  const fileObject: File = file;

  const fileSize: boolean = fileObject.size < size;
  return !!fileSize;
};

export const checkMimeType = (file: File, types: string[]): boolean => {
  const fileObject: File = file;
  const fileName: string = fileObject.name;
  const fileType: string = fileName.substr(fileName.lastIndexOf('.') + 1);
  const checkType: boolean = types.includes(fileType.toLowerCase());
  return !!checkType;
};

export const validateRegEx = (value: string) => {
  const regex = /^[a-z0-9]+$/i;
  return regex.test(value);
};

export const formatDate = (date: string): string => {
  const d = new Date(date);
  let month = `${d.getMonth() + 1}`;
  let day = `${d.getDate()}`;
  const year = d.getFullYear();
  if (month.length < 2) month = `0${month}`;
  if (day.length < 2) day = `0${day}`;
  return [day, month, year].join('/');
};

export const formatTime = (time: string): string => {
  let timeObj = new Date(time).toLocaleTimeString(navigator.language, {
    hour: '2-digit',
    minute: '2-digit',
  });
  if (timeObj.length < 8) timeObj = `0${timeObj}`;
  return timeObj;
};

export const formatTimestamp = (date: string): string =>
  `${formatDate(date)} ${formatTime(date)}`;

export const stringToPascal = (value: string): string =>
  value.replace(/(\w)(\w*)/g, function(g0, g1, g2) {
    return g1.toUpperCase() + g2.toLowerCase();
  });

export const sorter = (prop: any) =>
  function(a: any, b: any) {
    return b[prop] - a[prop];
  };
