export interface EndPoints {
  verifyUser: string;
  login: string;
  logout: string;
  upload: string;
  download: string;
  getPromoCode: string;
  adminDetails: string;
  getStaffData: string;
  sendEmail: string;
  partnerList: string;
  retrieveUserList: string;
  createUser: string;
  userAction: string;
  audit: string;
  downloadFileWithFileKey: string;
}
