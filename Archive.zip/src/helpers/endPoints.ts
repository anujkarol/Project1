import { EndPoints } from './interface';

const endPoints: EndPoints = {
  verifyUser: 'user',
  login: 'login',
  logout: 'user/logout',
  upload: 'promo/upload',
  download: 'promo/download',
  getPromoCode: 'qrCode/promos',
  getStaffData: 'qrCode/staffs',
  sendEmail: '/qr/generateQRCode',
  adminDetails: 'admin/details',
  partnerList: 'promo/details',
  retrieveUserList: 'user/retrieveList',
  createUser: 'user/create',
  userAction: '/user/userAction',
  audit: 'promo/audit',
  downloadFileWithFileKey: 'promo/downloadFileWithFileKey',
};

export default endPoints;
