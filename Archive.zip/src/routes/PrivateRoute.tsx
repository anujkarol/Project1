import React from 'react';
import { Route, Redirect } from 'react-router-dom';

export const PrivateRoute: React.FC<any> = ({ component, ...rest }: any) => {
  if (!component) {
    throw Error('component is undefined');
  }

  const Component = component;
  const render = (props: any): any => {
    const localToken = localStorage.getItem('token');
    if (localToken) {
      return <Component {...props} />;
    }
    return <Redirect to={{ pathname: '/', state: { from: props.location } }} />;
  };

  return <Route {...rest} render={render} />;
};

export default PrivateRoute;
