import React from 'react';
import { Switch } from 'react-router';
import { IRouteProps } from './interface';
import MakeRoute from './MakeRoute';

const Routes: React.FC<IRouteProps> = ({ routes }) => (
  <Switch>
    {routes.map((route, index) => (
      <MakeRoute {...route} key={index} />
    ))}
  </Switch>
);

export default Routes;
