import { lazy } from 'react';
import AutoLogout from '../hoc/AutoLogout';
import { IRoute } from './interface';

const RoutesConfig: IRoute[] = [
  {
    path: '/',
    component: lazy(() => import('../redux/containers/LoginContainer')),
    exact: true,
  },
  {
    path: '/Home',
    component: AutoLogout(
      lazy(() => import('../redux/containers/HomeContainer')),
    ),
    exact: true,
    protected: true,
  },
  {
    path: '/ManageUser',
    component: AutoLogout(
      lazy(() => import('../redux/containers/ManageUserContainer')),
    ),
    exact: true,
    protected: true,
  },
  {
    path: '',
    component: lazy(() => import('../pages/Common/NotFound')),
    exact: true,
  },
];

export default RoutesConfig;
