import React from 'react';
import { shallow } from 'enzyme';
import Error from './Error';

describe('Error', () => {
  it('Error should render correctly in "debug" mode', () => {
    const component = shallow(<Error />);
    expect(component).toMatchSnapshot();
  });

  it('Error should show if iShow is true', () => {
    const component = shallow(<Error isShow />);
    expect(component).toMatchSnapshot();
  });

  it('Error should show if iShow is true and display message', () => {
    const component = shallow(<Error message="Error message is displayed" />);
    expect(component).toMatchSnapshot();
  });
});
