import React from 'react';
import { Container } from './styles';
import { IErrorProps } from './interface';

const Error: React.FC<IErrorProps> = ({ isShow = false, children }) => {
  if (!isShow) return null;
  return <Container>{children}</Container>;
};

export default Error;
