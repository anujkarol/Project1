export interface IErrorProps {
  children?: any;
  message?: string;
  isShow: boolean | number;
  className?: string;
}
