import styledComponents from 'styled-components';
export const Container = styledComponents.p`
    font-size: 12px;
    color: #ff3333;
    text-align:left;
    margin-top: 4px
`;
Container.displayName = 'Error';
