import { ChangeEvent, ReactNode } from 'react';
export interface ISelectProps {
  children: ReactNode;
  isDefault: boolean;
  disabled?: boolean;
  value: string | number;
  selectVal?: string;
  defaultVal?: string;
  onChange: (e: ChangeEvent<HTMLSelectElement>) => void;
}
