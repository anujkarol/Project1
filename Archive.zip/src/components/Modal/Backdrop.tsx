import React, { ReactElement } from 'react';

import { BackdropContainer } from './styles';

const BackDrop: React.FC = (): ReactElement => <BackdropContainer />;

export default BackDrop;
