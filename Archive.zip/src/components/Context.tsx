import * as React from 'react';

import styledComponents from 'styled-components';

interface IContextProps {
  children: string | React.ReactElement | React.ReactNode;
}

const Container = styledComponents.p`
  margin: 0;
  font-size: 12px;
  color: #909090;
  font-weight: 500;
  text-align: left;
  text-align:center;
  width: auto;
  bottom: -26px;
`;
Container.displayName = 'Context';

const Context: React.FC<IContextProps> = ({ children }) => (
  <Container>{children}</Container>
);

export default Context;
