import styledComponents from 'styled-components';
export const Wrapper = styledComponents.div`
  background: #fff;
  box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.08);
`;
Wrapper.displayName = 'Wrapper';

export const ContainerInner = styledComponents.div`
  width: 1200px;
  margin: 0 auto;
  display: flex;
  line-height: 64px;
`;
ContainerInner.displayName = 'ContainerInner';

export const NavItemsContainer = styledComponents.ul`
  display: flex;
  flex-grow:1;
  text-align:center;
  margin: 0;
`;

NavItemsContainer.displayName = 'NavItemsContainer';

export const NavItem = styledComponents.li`
  cursor: pointer;
  color: #6f7981;
  list-style-type:none;
  padding:0 40px;
  &.active{
    color: #172633;
    border-bottom: 2px solid #FF3333;
    font-weight: 700;
  }
`;
NavItem.displayName = 'NavItem';
