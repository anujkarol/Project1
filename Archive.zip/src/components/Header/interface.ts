export interface IHeaderProps {
  activeHeader: (activeHeader: string) => void;
  activeTitle: string;
  navItems: string[];
  handleLogOut: () => void;
}
