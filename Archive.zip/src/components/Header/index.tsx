import React, { ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { ContainerInner, NavItem, NavItemsContainer, Wrapper } from './styles';

import { IHeaderProps } from './interface';
import dbsLogo from '../../assets/images/dbs_logo.svg';

const Header: React.FC<IHeaderProps> = ({
  activeTitle,
  navItems,
  activeHeader,
  handleLogOut,
}) => {
  const { t } = useTranslation();

  function handleClick(item: string): void {
    activeHeader(item);
  }

  const navBar: ReactNode = navItems.map((navItem: string, index: number) => {
    const isActive =
      navItem.toLocaleLowerCase() === activeTitle.toLocaleLowerCase();
    return (
      <NavItem
        className={isActive ? 'active' : ''}
        onClick={() => handleClick(navItem)}
        key={`${navItem}-${index}`}
      >
        {navItem}
      </NavItem>
    );
  });

  return (
    <Wrapper>
      <ContainerInner>
        <img src={dbsLogo} alt={t('header')} style={{ marginRight: '30px' }} />
        <NavItemsContainer>{navBar}</NavItemsContainer>
        <NavItem
          onClick={() => handleLogOut()}
          style={{
            color: '#ff3333',
            textDecoration: 'none',
            textAlign: 'right',
            paddingRight: 0,
          }}
        >
          {t('buttons.logout')}
        </NavItem>
      </ContainerInner>
    </Wrapper>
  );
};

export default Header;
