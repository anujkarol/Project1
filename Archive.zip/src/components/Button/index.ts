import React from 'react';
import './Button.css';
import { IButtonProps } from './interface';

const Button: React.FC<IButtonProps> = ({
  component = 'button',
  use,
  capitalize,
  size,
  shape,
  disabled,
  style,
  onClick,
  icon,
  children,
  sequence = '',
}) => {
  const iconName = `icon ico-${icon}`;
  return React.createElement(
    component,
    {
      className: `btn ${use} ${shape} ${size} ${
        capitalize ? 'capital' : ''
      } ${icon && 'icon-button'} ${component === 'a' &&
        disabled === true &&
        'disabled'}
        ${sequence}
        `,
      disabled,
      style,
      onClick,
    },
    icon &&
      React.createElement('i', { className: `${icon && iconName}` }, null),
    children,
  );
};

Button.defaultProps = {
  component: 'button',
  disabled: false,
  size: 'normal',
  use: 'primary',
  onClick: () => {},
  shape: 'square',
  icon: '',
};

export default Button;
