export interface IButtonProps {
  component?: string;
  disabled?: boolean;
  onClick: (e: any) => void;
  size?: string;
  use?: string;
  children?: any;
  shape?: string;
  icon?: string;
  type?: string;
  capitalize: boolean;
  style?: any;
  sequence?: string;
}
