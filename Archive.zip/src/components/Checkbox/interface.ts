import { ReactElement } from 'react';

export interface ICheckboxProps {
  children?: string | number | ReactElement;
  checked?: boolean;
  disabled?: boolean | false;
  onChange: (e: React.SyntheticEvent<EventTarget>) => void;
  value?: string | number;
  name?: string;
  style?: any;
}
