import React from 'react';
import {
  Check,
  Children,
  Container,
  HiddenInput,
  StyledCheckbox,
} from './styles';

import { ICheckboxProps } from './interface';

const Checkbox: React.FC<ICheckboxProps> = ({
  disabled,
  checked,
  onChange,
  value,
  style,
  children,
}) => (
  <Container disabled={disabled}>
    <HiddenInput
      disabled={disabled}
      onChange={onChange}
      value={value}
      checked={checked}
    />
    <StyledCheckbox checked={checked}>
      <Check />
    </StyledCheckbox>

    <Children style={style}>{children}</Children>
  </Container>
);

Checkbox.defaultProps = {
  children: '',
  checked: false,
  disabled: false,
  onChange: () => {},
};

export default Checkbox;
