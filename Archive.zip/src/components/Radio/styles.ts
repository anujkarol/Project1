import styledComponents from 'styled-components';
import styledComponentsTS from 'styled-components-ts';

export const Container = styledComponents.label`
  font-size: 16px;
  color:#172633;
  margin-right: 30px;
  width:75px;
  text-align: right;
  margin-top:8px;
  display: flex;
  position: relative;
  cursor: pointer;
  user-select: none;
  line-height: 24px;
  width:auto !important;
  margin-bottom:0px;
`;
Container.displayName = 'Container';

export const Dot = styledComponents.span`
  content: "";
  position: absolute;
  top: 8px;
  left: 8px;
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background: #fff;
`;
Dot.displayName = 'Dot';

export const HiddenInput = styledComponents.input.attrs({ type: 'radio' })`
  border: 0;
  clip: rect(0 0 0 0);
  clippath: inset(50%);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  white-space: nowrap;
  width: 1px;
`;
HiddenInput.displayName = 'HiddenInput';

export const StyledRadio = styledComponentsTS<{ checked: boolean }>(
  styledComponents.div,
)`
  height: 23px;
  width: 23px;
  border-radius: 50%;
  border: 1px solid ${props => (props.checked ? '#13c998;' : '#c7cfd5;')};
  background: ${props => (props.checked ? '#13c998' : '#eeeeee')};
  ${Dot} {
    visibility: ${props => (props.checked ? 'visible' : 'hidden')}
  }
`;
StyledRadio.displayName = 'StyledRadio';

export const Children = styledComponents.span`
  padding: 2px 0 0 20px;
  font-size: 16px;
  line-height: 1.357;
  color: #172633;
  cursor: pointer;
`;
Children.displayName = 'Children';

export const RadioWrapper = styledComponents.div`
    display: flex;
    min-width: 300px;
    width:100%;
`;

RadioWrapper.displayName = 'RadioWrapper';
