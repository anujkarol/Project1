import React, { ReactNode } from 'react';
import { v4 } from 'uuid';
import { Row } from '../../components/Table/Row';
import Cols from './Columns';

const Rows = (rows: object[] = [], colWidth: number[] = []): ReactNode =>
  rows.map(
    (item: any): ReactNode => (
      <Row key={v4()} header={false} isShift={false}>
        {Cols(item, colWidth)}
      </Row>
    ),
  );

export default Rows;
