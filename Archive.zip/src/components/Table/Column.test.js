import React from 'react';
import { shallow } from 'enzyme';
import Column from './Column';

describe('MyComponent', () => {
  it('should render correctly in "debug" mode', () => {
    const component = shallow(<Column />);

    expect(component).toMatchSnapshot();
  });

  it('should render correctly in "debug" mode', () => {
    // expect(component).toHaveProperty(width);
  });
});
