import * as React from 'react';

import { IRowProps } from './interface';
import { RowsContainer } from './styles';

export const Row: React.FC<IRowProps> = ({
  header = false,
  children,
}): React.ReactElement => (
  <RowsContainer header={header}>{children}</RowsContainer>
);
