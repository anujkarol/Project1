import React, { ReactNode } from 'react';
import { v4 } from 'uuid';
import { Dash } from '../icons/Dash';
import { Column } from './Column';

const Columns = (item: any, colWidth: number[] = []): ReactNode =>
  Object.values(item).map((value: any, index: number) => {
    if (value.toString().includes('.html')) {
      return (
        <Column width={colWidth[index]} key={v4()}>
          <a href={value} target="_blank" rel="noopener noreferrer">
            {value}
          </a>
        </Column>
      );
    }
    return (
      <Column width={colWidth[index]} key={v4()}>
        {!value ? <Dash top="0" /> : value}
      </Column>
    );
  });

export default Columns;
