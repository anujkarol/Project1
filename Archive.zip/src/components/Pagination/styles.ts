import styledComponents from 'styled-components';
import styledComponentsTS from 'styled-components-ts';

export const Container = styledComponents.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  margin: 45px 0 0;
  align-items: center;
  color: #454f57;
  font-weight: normal;
`;
Container.displayName = 'Container';
const PageActiveStyle = `
color: #454f57;
cursor: default;
`;
export const Page = styledComponentsTS<{ isActive: boolean }>(
  styledComponents.span,
)`
  margin-left: 18px;
  font-size: 20px;
  color: #CACBCB;
  cursor: pointer;

  ${({ isActive }) => isActive && PageActiveStyle}
`;

Page.displayName = 'Page';
export const Title = styledComponents.span`
font-size: 12px;
`;

Title.displayName = 'Title';
