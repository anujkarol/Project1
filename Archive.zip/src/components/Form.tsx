import * as React from 'react';

import styledComponents from 'styled-components';
import styledComponentsTS from 'styled-components-ts';

interface IFormProps {
  children: any;
  type: string;
}

const ContainerStyle = `
display: flex;
flex-direction: column;
justify-content: center;
align-items: center;
`;
const Container = styledComponentsTS<{ type: string }>(styledComponents.form)`
  ${({ type }) => type && ContainerStyle}
`;
Container.displayName = 'Form';

const Form: React.FC<IFormProps> = ({ children, type }) => (
  <Container type={type}>{children}</Container>
);
export default Form;
