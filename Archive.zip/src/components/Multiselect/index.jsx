import React from 'react';

import {
  Items,
  Item,
  ItemLabel,
  DropDown,
  SearchAndToggle,
  Buttons,
} from './styles';
import Button from '../Button';
import './multiSelect.css';

class MultiSelect extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      clearable: false,
      create: false,
      keepSelectedInList: true,
      dropdownHeight: '200px',
    };
  }

  setValues = (selectValues, labelField) => {
    const { selectedValues } = this.props;

    let selectedValue = [];
    if (labelField === 'promoCode') {
      selectedValue = selectValues.map(promo => promo);
    } else {
      selectedValue = selectValues.map(staff => staff.staffId);
    }

    selectedValues(selectedValue, labelField);

    if (selectedValue.length) {
      this.setState({
        clearable: true,
      });
    } else {
      this.setState({
        clearable: false,
      });
    }
  };

  contentRenderer = ({ props, state }) => {
    const isValues = state.values.length;
    if (props.labelField === 'promoCode') {
      return isValues > 0 ? (
        <div>{state.values[0].promo}</div>
      ) : (
        'Please Select Promo Code'
      );
    }

    return isValues > 0 ? (
      <div>
        {state.values.length}
        &nbsp;of&nbsp;
        {props.options.length}
        &nbsp;Selected
      </div>
    ) : (
      'Select Staff Id(s)'
    );
  };

  dropdownRenderer = ({ props, state, methods }) => {
    const regexp = new RegExp(state.search, 'i');
    const { labelField, valueField } = this.props;
    const { keepSelectedInList } = this.state;

    return (
      <>
        <SearchAndToggle>
          <Buttons>
            <div>Select Staff Id(s)</div>
            {methods.areAllSelected() ? (
              <Button
                component="button"
                capitalize={false}
                use="ghost"
                size="medium"
                onClick={methods.clearAll}
              >
                Clear all
              </Button>
            ) : (
              <Button
                component="button"
                capitalize={false}
                use="ghost"
                size="medium"
                onClick={methods.selectAll}
              >
                Select all
              </Button>
            )}
          </Buttons>
        </SearchAndToggle>
        <Items>
          {props.options
            .filter(item => regexp.test(item[labelField]))
            .map(option => {
              if (!keepSelectedInList && methods.isSelected(option)) {
                return null;
              }

              return (
                <Item
                  disabled={option.disabled}
                  key={option[valueField]}
                  onClick={
                    option.disabled ? null : () => methods.addItem(option)
                  }
                >
                  <input
                    type="checkbox"
                    onChange={() => methods.addItem(option)}
                    checked={state.values.indexOf(option) !== -1}
                  />

                  <ItemLabel>{option[labelField]}</ItemLabel>
                </Item>
              );
            })}
        </Items>
      </>
    );
  };

  render() {
    const { create, dropdownHeight, clearable } = this.state;
    const {
      multi,
      options,
      labelField,
      valueField,
      dropdownRenderer = true,
      contentRenderer = true,
      placeholder,
      disabled,
      searchable,
      closeOnSelect,
    } = this.props;
    return (
      <DropDown
        disabled={disabled}
        placeholder={placeholder}
        clearable={clearable}
        create={create}
        searchable={searchable}
        dropdownHeight={dropdownHeight}
        multi={multi}
        values={[]}
        labelField={labelField}
        valueField={valueField}
        options={options}
        dropdownGap={0}
        onChange={values => this.setValues(values, labelField)}
        closeOnSelect={closeOnSelect}
        contentRenderer={
          contentRenderer
            ? (innerProps, innerState) =>
                this.contentRenderer(innerProps, innerState)
            : undefined
        }
        dropdownRenderer={
          dropdownRenderer
            ? (innerProps, innerState, innerMethods) =>
                this.dropdownRenderer(innerProps, innerState, innerMethods)
            : undefined
        }
      />
    );
  }
}

export default MultiSelect;
