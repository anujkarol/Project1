import styledComponents from 'styled-components';
import Select from 'react-dropdown-select';

export const DropDown = styledComponents(Select)`
  display:flex;
  width:50%;
`;

export const Items = styledComponents.div`
  overflow: auto;
  min-height: 10px;
  max-height: 200px;
`;

export const Item = styledComponents.div`
  display: flex;
  margin: 10px;
  align-items: baseline;
`;

export const ItemLabel = styledComponents.div`
  margin: 5px 10px;
`;

export const Title = styledComponents.div`
  display: flex;
  justify-content: space-between;
  align-items: baseline;
`;
export const SearchAndToggle = styledComponents.div`
  display: flex;
  flex-direction: column;
  input {
    margin: 10px 10px 0;
    line-height: 30px;
    padding: 0px 20px;
    border: 1px solid #ccc;
    border-radius: 3px;
    :focus {
      outline: none;
      border: 1px solid #000;
    }
  }
`;
export const Buttons = styledComponents.div`
  display: flex;
  justify-content: space-between;
  line-height:30px;
  padding:0 0 0 15px;
  background:#f1f1f1

`;
