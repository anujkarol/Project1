import React from 'react';

export const Dash = ({
  height = '24px',
  width = '24px',
  color = '#333',
  top = '10px',
}) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 32 32"
    style={{ width, height, position: 'relative', top, marginRight: '4px' }}
  >
    <g fill={color}>
      <path d="M5 13h14c0.552 0 1-0.448 1-1s-0.448-1-1-1h-14c-0.552 0-1 0.448-1 1s0.448 1 1 1z" />
    </g>
  </svg>
);
