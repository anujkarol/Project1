import styledComponents from 'styled-components';
import styledComponentsTS from 'styled-components-ts';
const FileButtonStyles = `
background: #6f7981;
color:#fff
`;
export const FileButton = styledComponentsTS<{ attached: boolean }>(
  styledComponents.div,
)`
      position: absolute;
      left:0;
      width: 115px;
      background:#dedede;
      border-radius: 15px;
      padding:8px 16px;
      color:#989898;
      font-size: 14px;
      font-weight: 600;
      height: 30px;
      top:0;
      letter-spacing: 0px;
      text-align: center;
      cursor: pointer;
      line-height: 14px;
      box-sizing: border-box;
      ${({ attached }) => !attached && FileButtonStyles}
  `;

FileButton.displayName = 'FileButton';

export const Wrapper = styledComponents.div`
    display: flex;
    word-break: break-all;
    flex-direction: row;
    width: auto;

    position:relative;
   `;

Wrapper.displayName = 'Wrapper';

export const Status = styledComponents.div`
    left: 30px;
    position: absolute;
    bottom: -18px;
    font-weight: 100;
   `;
Status.displayName = 'Status';

export const FileWrapper = styledComponents.div`
display: flex;
flex-direction: column;
width: 300px;
`;

FileWrapper.displayName = 'FileWrapper';
export const InputWrapper = styledComponents.input`
  border-radius: 4px;
  box-sizing:border-box;
  border: 1px solid rgb(199, 199, 199);
  padding: 0px 8px;
  margin-bottom: 0px;
  font-size:16px;
  height:40px;
  width:100%
  &:focus{
    border: 1px solid #000;
    outline:0
  }
  &.error{
    border: 1px solid #ff3333;
    font-size: 16px;
    font-weight: 300;
  }
  &:disabled{
    background: #f1f1f1;
    color: #000;
  }
  &:readonly{
    background: #f1f1f1;
    color: #000;
  }
 `;

InputWrapper.displayName = 'InputWrapper';

export const InputStyle = styledComponents.input`
    opacity: 0;
    width: 118px;
    height: 30px;
    position: relative;
    left: 0;
    margin: 0;
    z-index: 9;
    padding: 0;
    cursor: pointer;
`;
InputStyle.displayName = 'InputStyle';
export const UploadWrap = styledComponents.div`
  position: relative;
  display: flex;
  margin-bottom: 30px;
  height: auto;
  padding: 0;
`;
UploadWrap.displayName = 'UploadWrap';

export const Input = styledComponents.input`
  font-size: 18px;
  color: #000000;
  width: 100%;
  height: 40px;
  padding:2px 10px;
  border: 1px solid #dadee6;
  box-shadow: none;
  border-radius: 0;
  font-weight: 500;
  box-sizing:border-box;
  outline:0;
  &:focus{
    font-weight: 400;
  }
  &:disabled{
    background: #f1f1f1;
    color: #000;
  }
`;

Input.displayName = 'Input';
