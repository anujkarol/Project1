export interface IInputFileProps {
  label: string;
  type: string;
  value: any;
  name: string;
  onInputChange: any;
  error?: any;
  context?: string;
  fileName: string;
  attached: boolean;
}

export interface IInputProps {
  label: string;
  type: string;
  value: string;
  name: string;
  handleInputChange?: any;
  error?: any;
  context?: string;
  onBlur?: any;
  validation?: any;
  handleBlur?: any;
  disabled?: boolean;
  autoFocus?: boolean;
  errorMessage?: string;
  inFieldClear?: boolean;
  clearField?: () => void;
}
