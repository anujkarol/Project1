import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { Router } from 'react-router';
import { I18nextProvider } from 'react-i18next';

import { store } from './redux/store';
import Routes from './routes/Routes';
import * as serviceWorker from './serviceWorker';
import i18n from './i18n';
import RoutesConfig from './routes/RoutesConfig';
import { history } from './helpers/history';
import ErrorBoundary from './components/ErrorBoundary';
import Loader from './components/Loader';
import GlobalStyle from './GlobalStyle';
import './index.css';

ReactDOM.render(
  <I18nextProvider i18n={i18n}>
    <Provider store={store}>
      <GlobalStyle />
      <ErrorBoundary>
        <React.StrictMode>
          <React.Suspense fallback={<Loader />}>
            <Router history={history}>
              <Routes routes={RoutesConfig} />
            </Router>
          </React.Suspense>
        </React.StrictMode>
      </ErrorBoundary>
    </Provider>
  </I18nextProvider>,
  document.getElementById('root'),
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
