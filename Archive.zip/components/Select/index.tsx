import React, { ReactElement } from 'react';
import { Container, SelectBox } from './styles';

import { ISelectProps } from './interface';

const Select: React.FC<ISelectProps> = ({
  onChange,
  children,
  isDefault,
  defaultVal,
  disabled = false,
}): ReactElement => (
  <Container>
    <SelectBox onChange={onChange} disabled={disabled}>
      {isDefault && <option value={defaultVal}>{defaultVal}</option>}
      {children}
    </SelectBox>
  </Container>
);

SelectBox.defaultProps = {
  children: 'Please Select',
  disabled: false,
};

export default Select;
