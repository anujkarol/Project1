import styledComponents from 'styled-components';

export const Container = styledComponents.div`
  display: flex;
  flex-direction: column;
  position: relative;
  border: 1px solid #ccc;
`;
Container.displayName = 'Container';

export const SelectBox = styledComponents.select`
  background: transparent;
  font-weight: 300;
  font-size: 16px;
  padding:10px 4px;
  border: 0;
  outline: none;
  width:100%;
  height:40px;
  `;
SelectBox.displayName = 'SelectBox';
