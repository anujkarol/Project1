import styledComponents from 'styled-components';
import styledComponentsTS from 'styled-components-ts';

export const Container = styledComponentsTS<{ disabled: any }>(
  styledComponents.label,
)`
display: flex;
flex: 1 1 auto;
position: relative;
height: 26px;
  ${({ disabled }) =>
    disabled &&
    `
    color: #454f57;
    cursor: not-allowed;
  `}
`;

Container.displayName = 'Container';
export const Check = styledComponents.span`
  left: 8px;
  top: 4px;
  width: 7px;
  height: 13px;
  border: solid #fff;
  border-width: 0 3px 3px 0;
  transform: rotate(45deg);
  position: absolute;
`;
Check.displayName = 'Check';
export const Children = styledComponentsTS<{ style: any }>(
  styledComponents.span,
)`
  padding: 2px 0 0 20px;
  font-size: 16px;
  line-height: 1.357;
  color: #172633;
  font-weight: 700;
  cursor: pointer;
  ${({ style }) =>
    style &&
    `
    font-weight: 400
  `}
`;
Children.displayName = 'Children';

export const HiddenInput = styledComponents.input.attrs({ type: 'checkbox' })`
  border: 0;
  clip: rect(0 0 0 0);
  clippath: inset(50%);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  white-space: nowrap;
  width: 1px;
`;
HiddenInput.displayName = 'HiddenInput';

export const StyledCheckbox = styledComponentsTS<any>(styledComponents.div)`
  width: 24px;
  height: 24px;
  border-radius: 2px;
  border: 2px solid ${props => (props.checked ? 'transparent;' : '#c7cfd5;')}
  background: ${props => (props.checked ? '#13c998' : '#fff')}
  transition: all 150ms;
  ${Check} {
    visibility: ${props => (props.checked ? 'visible' : 'hidden')}
  }
`;
StyledCheckbox.displayName = 'StyledCheckbox';

export const TableCheckBox = styledComponents.div`
  position: absolute;
  left:-45px;
  top:15px
`;
