import React, { ReactElement } from 'react';
import { Container, Page, Title } from './styles';

import { IPaginationProps } from './interface';

const Pagination: React.FC<IPaginationProps> = ({
  itemsCount = 10,
  pageSize = 1,
  currentPage = 1,
  onPageChange,
}): ReactElement | null => {
  const pagesCount: number = Math.ceil(itemsCount / pageSize);
  if (pagesCount <= 1 || !pagesCount) return null;

  const pages: Array<number> = Array.from(Array(pagesCount + 1).keys()).splice(
    1,
  );
  const pagination: Array<object> = pages.map(
    (page: number): ReactElement => (
      <Page
        key={page}
        isActive={currentPage === page}
        onClick={() => onPageChange(page)}
      >
        {page}
      </Page>
    ),
  );
  return (
    <Container>
      <Title>Page</Title>
      {pagination}
    </Container>
  );
};

export default Pagination;
