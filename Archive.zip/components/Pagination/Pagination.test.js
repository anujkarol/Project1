import React from 'react';
import { shallow } from 'enzyme';
import Pagination from './index';

describe('Pagination', () => {
  it('should render correctly in "debug" mode', () => {
    const component = shallow(<Pagination />);

    expect(component).toMatchSnapshot();
  });

  it('should not render for page count < 1 or undefined', () => {
    const component = shallow(<Pagination itemsCount={1} />);

    expect(component.get(0)).toEqual(null);
  });

  it('should render two count page count > 10 and <=20', () => {
    const component = shallow(<Pagination itemsCount={20} />);

    expect(component.find('Page').length).toEqual(20);

    // const mockCallBack = jest.fn();
    // console.log(componentClick.debug());
    // expect(component.get
  });

  it('should test click event', () => {
    const mockCallBack = jest.fn();
    const component = shallow(
      <Pagination itemsCount={2} onClick={mockCallBack} />,
    );
    // const newcomp = component.find('Page');
    console.log(component.debug());
    component
      .find('Page')
      .at(0)
      .simulate('click');
    expect(mockCallBack.mock.calls.length).toEqual(1);
    // expect(component.get
  });
});
