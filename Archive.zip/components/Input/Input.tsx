import * as React from 'react';

import styledComponents from 'styled-components';
import Context from '../Context';
import Error from '../Error/Error';
import FormRow from './FormRow';
import { IInputProps } from './interface';
import { InputWrapper } from './styles';
import Label from './Label';

const Wrapper = styledComponents.div`
  display: flex;
  flex-direction: column;
  width: 300px;
  position: relative;
  margin-bottom: 10px;
  height: auto;
  padding: 0;
 `;

Wrapper.displayName = 'Wrapper';

const Input: React.FC<IInputProps> = ({
  label = 'Label',
  type = 'text',
  value = 'Please enter a Value',
  handleInputChange = () => { },
  name = 'Text Filed',
  error = '',
  context = '',
  handleBlur = () => { },
  disabled = false,
  autoFocus = false,
  errorMessage = '',
  inFieldClear = false,
  clearField = () => undefined

}) => (
    <FormRow inFieldClear={inFieldClear}>
      <Label name={name} label={label} />
      <InputWrapper
        type={type}
        name={name}
        value={value}
        autoFocus={autoFocus}
        onChange={e => {
          handleInputChange(e);
        }}
        disabled={disabled}
        onBlur={e => {
          handleBlur(e);
        }}
        className={error && 'error'}
        autoComplete="off"
      />
      <i
        style={{
          position: 'absolute',
          top: '38px',
          right: '10px'
        }}
        onClick={clearField}
      >
        ×
    </i>
      {context && <Context>{context}</Context>}
      <Error isShow={error}>{errorMessage}</Error>
    </FormRow>
  );

export default Input;
