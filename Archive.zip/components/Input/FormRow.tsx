import * as React from 'react';

import styledComponents from 'styled-components';
import styledComponentsTS from 'styled-components-ts';

interface IFormRowProps {
  children: any;
  inFieldClear?: boolean
}

const Container = styledComponentsTS<{ inFieldClear: boolean }>(
  styledComponents.div,
)`
  position: relative;
  display: flex;
  flex-direction:column;
  margin-bottom: 24px;
  height: auto;
  padding: 0;
  position:relative;

  & i {
    cursor:pointer;
    font-style: normal;
    ${({ inFieldClear }) =>
    !inFieldClear &&
    `
        display:none;
    `}
  }
`;

Container.displayName = 'Container';
const FormRow: React.FC<IFormRowProps> = ({ children, inFieldClear = false }) => (
  <Container inFieldClear={inFieldClear}>{children}</Container>
);

export default FormRow;
