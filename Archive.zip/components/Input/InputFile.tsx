import * as React from 'react';

import { useTranslation } from 'react-i18next';
import { FileButton, InputStyle, Status, UploadWrap } from './styles';

import Error from '../Error/Error';
import { IInputFileProps } from './interface';

const InputFile: React.FC<IInputFileProps> = ({
  onInputChange,
  name,
  error,
  context,
  attached,
  fileName,
}) => {
  const { t } = useTranslation();
  return (
    <>
      <UploadWrap>
        <InputStyle
          type="file"
          name={name}
          onChange={e => {
            onInputChange(e);
          }}
          className={error && 'error'}
        />

        <FileButton attached={attached}>
          {t('lbl_attach_file')}
          {attached && <Status>{t('attached')}</Status>}
        </FileButton>
      </UploadWrap>
      {attached && (
        <p style={{ margin: '5px 10px 0 5px' }} className="text-left">
          {fileName}
        </p>
      )}
      <Error isShow={!attached}>{error}</Error>
    </>
  );
};

export default InputFile;
