import * as React from 'react';

import styledComponents from 'styled-components';
import styledComponentsTS from 'styled-components-ts';

interface ILabelProps {
  label: string;
  name: string;
}

const Container = styledComponentsTS<{}>(styledComponents.label)`
  font-size: 16px;
  color: #172633;
  margin-bottom: 10px;
  text-align: left;
  display:block;
`;

Container.displayName = 'Label';

const Label: React.FC<ILabelProps> = ({ name, label }) => (
  <Container htmlFor={name}>{label}</Container>
);

export default Label;
