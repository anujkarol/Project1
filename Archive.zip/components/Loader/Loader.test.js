import React from 'react';
import { shallow } from 'enzyme';
import Loader from './index';

describe('Loader', () => {
  it('Loader should render correctly', () => {
    const component = shallow(<Loader />);
    expect(component).toMatchSnapshot();
  });

  it('Loader have Spinner component', () => {
    const component = shallow(<Loader />);
    expect(component.find('Spinner').length).toEqual(1);
  });
});
