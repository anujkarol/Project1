import React from 'react';
import { shallow } from 'enzyme';
import Context from './Context';

describe('Context', () => {
  it('Context should render correctly', () => {
    const component = shallow(<Context />);
    expect(component).toMatchSnapshot();
  });
});
