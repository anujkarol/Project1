import React, { ReactElement } from 'react';
import {
  Children,
  Container,
  Dot,
  HiddenInput,
  RadioWrapper,
  StyledRadio,
} from './styles';

import FormRow from '../Input/FormRow';
import { IRadioProps } from './interface';
import Label from '../Input/Label';

const Radio: React.FC<IRadioProps> = ({
  label = '',
  name,
  value,
  title,
  handleInputChange,
  isChecked,
}): ReactElement => {
  const radio = title.map(
    (item: string, index: number): ReactElement => (
      <Container key={`${index}-${label}`}>
        <HiddenInput
          name={name}
          value={item}
          checked={isChecked === item}
          onChange={(e: React.SyntheticEvent<HTMLInputElement>) =>
            handleInputChange(e)
          }
        />

        <StyledRadio checked={isChecked === item}>
          <Dot />
        </StyledRadio>
        <Children>{item}</Children>
      </Container>
    ),
  );

  return (
    <FormRow>
      {label && <Label name={name} label={label} />}
      <RadioWrapper>{radio}</RadioWrapper>
    </FormRow>
  );
};

export default Radio;
