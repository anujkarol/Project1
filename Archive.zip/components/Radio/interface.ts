import { ReactElement, ReactNode } from 'react';
export interface IRadioProps {
  children?: string | ReactNode | ReactElement;
  checked?: boolean;
  disabled?: boolean;
  handleInputChange: any;
  value: string;
  title: string[];
  label?: string;
  name: string;
  radioLayout?: string;
  isChecked?: string;
}
