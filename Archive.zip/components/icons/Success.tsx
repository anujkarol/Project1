import React from 'react';

export const Success = ({ height = '24px', width = '24px', color = '#333', top = '10px' }) => (


  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" style={{ width, height, position: 'relative', top, marginRight: '4px' }}>
    <g fill={color}>
      <path d="M9.984 17.016l9-9-1.406-1.453-7.594 7.594-3.563-3.563-1.406 1.406zM12 2.016q4.125 0 7.055 2.93t2.93 7.055-2.93 7.055-7.055 2.93-7.055-2.93-2.93-7.055 2.93-7.055 7.055-2.93z" />
    </g>
  </svg>


)
