import React from 'react';
import { shallow } from 'enzyme';
import Modal from './index';

describe('Modal', () => {
  it('Modal should render correctly', () => {
    const component = shallow(<Modal />);
    expect(component).toMatchSnapshot();
  });
});
