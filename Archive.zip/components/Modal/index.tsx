import React, { ReactElement } from 'react';
import { Close, Container, ContentWrapper, Title } from './styles';

import BackDrop from './Backdrop';
import { IModalProps } from './interface';
import { Cross } from '../icons/Cross';

const Modal: React.FC<IModalProps> = ({
  children,
  isCloseIcon = false,
  handleCloseModal,
  isShow,
  title = '',
  style,
}): ReactElement | null => {
  if (!isShow) {
    return null;
  }
  return (
    <>
      <Container>
        <ContentWrapper className={isShow ? 'active' : 'inactive'}>
          <Title style={style}>{title}</Title>
          {isCloseIcon && (
            <Close
              isCloseIcon={isCloseIcon}
              onClick={handleCloseModal}
              className="cursor"
            >
              <Cross />
            </Close>
          )}
          {children}
        </ContentWrapper>

      </Container>
      <BackDrop />
    </>
  );
};

export default Modal;
