export const GLOBAL_CONFIG = {
  FILE_SIZE: 20000000,
  WARNING_TIME: 1000 * 60 * 4,
  SIGN_OUT_TIME: 1000 * 60 * 5,
  FILE_TYPES: ['csv'],
  ITEMS_PER_PAGE: 20,
  DEFAULT_PAGE: 'Qr Code',
  PAGE1: 'Qr Code',
  PAGE2: 'Code Maintenance',
  PAGE3: 'Manage User',
  PAGE4: 'Audit',
  API_TIMEOUT: 5000,
};
