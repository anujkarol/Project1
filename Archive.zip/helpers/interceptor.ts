import axios, { AxiosInstance } from 'axios';
import * as actions from '../redux/actions';

import { GLOBAL_CONFIG } from './global';
import { store } from '../redux/store';

export const instance: AxiosInstance = axios.create({
  timeout: GLOBAL_CONFIG.API_TIMEOUT,
  baseURL: `${process.env.REACT_APP_API_ENDPOINT}`,
  headers: { Pragma: 'no-cache' },
});

instance.interceptors.response.use(
  function(response) {
    store.dispatch(
      actions.serverUpAction('Server UP from  INTERCEPTOR Response'),
    );
    return response;
  },
  error => {
    console.log(error.response);
    const ifServerError =
      error.response.status > 401 && error.response.status < 500;
    if (ifServerError) {
      store.dispatch(actions.serverDownAction('Server DOWN from  INTERCEPTOR'));
    } else {
      store.dispatch(actions.serverUpAction('Server UP from  INTERCEPTOR'));
      throw new Error(error.response.data.message);
    }

    // !expectedError && console.error(error);
    // return;
    return Promise.reject(error.response.status);
  },
);
