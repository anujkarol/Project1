export interface EndPoints {
  createUser: string;
  login: string;
  logout: string;
  upload: string;
  download: string;
  getPromoCode: string;
  adminDetails: string;
  getStaffData: string;
  sendEmail: string;
  partnerList: string;
}
