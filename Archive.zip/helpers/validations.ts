import { GLOBAL_CONFIG } from './global';

export const emailValidation: any = (data: string) => {
  const regEx: RegExp = /\w+([-+.']\w+)*[@+](1bank.dbs|dbs)\.com(\W|$)/;

  const results: string[] = data.replace(/\s/g, '').split(/,|;/);
  let error: boolean = false;
  results.forEach(result => {
    // eslint-disable-next-line no-unused-expressions
    regEx.test(result) ? (error = false) : (error = true);
  });

  return error;
};

export const checkFileSize = (file: File, size: number): boolean => {
  const fileObject: File = file;
  return fileObject.size < size;
};

export const checkMimeType = (file: File): boolean => {
  const fileObject: File = file;
  const fileName: string = fileObject.name;
  const fileType: string = fileName.substr(fileName.indexOf('.') + 1);

  const types: Array<string> = GLOBAL_CONFIG.FILE_TYPES;
  return types.includes(fileType.toLowerCase());
};

export const validateRegEx = (value: string) => {
  const regex = /^[a-z0-9]+$/i;
  return regex.test(value);
};

export const formatDate = (date: string): string => {
  const d = new Date(date);
  let month = `${d.getMonth() + 1}`;
  let day = `${d.getDate()}`;
  const year = d.getFullYear();
  if (month.length < 2) month = `0${month}`;
  if (day.length < 2) day = `0${day}`;
  return [day, month, year].join('/');
};

export const formatTime = (time: string): string => {
  let timeObj = new Date(time).toLocaleTimeString(navigator.language, {
    hour: '2-digit',
    minute: '2-digit',
  });
  if (timeObj.length < 8) timeObj = `0${timeObj}`;
  return timeObj;
};

export const formatTimestamp = (date: string): string => {
  return `${formatDate(date)} ${formatTime(date)}`;
};

export const stringToPascal = (value: string): string =>
  value.replace(/(\w)(\w*)/g, function(g0, g1, g2) {
    return g1.toUpperCase() + g2.toLowerCase();
  });
