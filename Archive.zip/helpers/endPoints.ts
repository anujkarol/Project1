import { EndPoints } from './interface';

const endPoints: EndPoints = {
  createUser: 'admin/create',
  login: 'login',
  logout: 'admin/logout',
  upload: 'promo/upload',
  download: 'promo/download',
  getPromoCode: 'qrCode/promos',
  getStaffData: 'qrCode/staffs',
  sendEmail: '/qr/generateQRCode',
  adminDetails: 'admin/details',
  partnerList: 'promo/details',
};

export default endPoints;
