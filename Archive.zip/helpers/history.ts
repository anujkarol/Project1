import { createBrowserHistory, History } from 'history';

export const history: History = createBrowserHistory();
