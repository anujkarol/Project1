/* eslint-disable no-alert */
import React from 'react';
import { GLOBAL_CONFIG } from '../../helpers/global';

function HoC(ComposedClass: any) {
  return class AutoLogout extends React.Component<any, any> {
    events: string[] | undefined;
    warnTimeout: any;
    logoutTimeout: any;

    constructor(props: any) {
      super(props);
      this.state = {
        warningTime: GLOBAL_CONFIG.WARNING_TIME,
        signOutTime: GLOBAL_CONFIG.SIGN_OUT_TIME,
      };
    }

    componentDidMount() {
      this.events = [
        'load',
        'mousemove',
        'mousedown',
        'click',
        'scroll',
        'keypress',
      ];

      for (const i in this.events) {
        window.addEventListener(this.events[i], this.resetTimeout);
      }
      this.setTimeout();
    }

    clearTimeoutFunc = () => {
      if (this.warnTimeout) clearTimeout(this.warnTimeout);
      if (this.logoutTimeout) clearTimeout(this.logoutTimeout);
    };

    setTimeout = () => {
      const { warningTime, signOutTime } = this.state;
      this.warnTimeout = setTimeout(this.warn, warningTime);
      this.logoutTimeout = setTimeout(this.logout, signOutTime);
    };

    resetTimeout = () => {
      this.clearTimeoutFunc();
      this.setTimeout();
    };

    warn = () => {
      const confirm = window.confirm(
        'Your session is expiring soon. Would you like to continue?',
      );
      if (!confirm) {
        this.destroy();
      }
    };

    logout = () => {
      this.destroy();
    };

    destroy = () => {
      window.location.assign('/');
    };

    render() {
      return <ComposedClass />;
    }
  };
}

export default HoC;
