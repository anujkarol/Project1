import * as React from 'react';
import styled from 'styled-components';

import Burger from '../../components/Burger/Burger';
import Controls from '../../components/Controls/Controls';

const BurgerContainer = styled.div`
    align-self: stretch;
    order: 0;
    flex: 0 0 0px;
    flex-grow: 0;
    flex-shrink: 0;
    flex-basis: 90px;

`


class BurgerBuilder extends React.Component { 
    state = {
        ingredients: {
            chese: 0,
            meat: 2,
            bacon: 3,
            salad:1
        }
    }
    render() {
        return(
            <BurgerContainer>
                <Burger ingredients = { this.state.ingredients }/>
                <Controls />
            </BurgerContainer>
        );
    }
}


export default BurgerBuilder;