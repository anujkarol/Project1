import React, { Fragment } from 'react';
import styled from 'styled-components'; 
import BurgerBuilder from '../../containers/BurgerBuilder/BurgerBuilder';


const Toolbar = styled.div `
    background:red
`;
const Layout = props => (
    <Fragment>
        <Toolbar>
            Toolbar
        </Toolbar>
        <div>
            SideDrawer,
            Backdrop
        </div>
        <main>
            {props.chilren}
        </main>
        <BurgerBuilder />
    </Fragment>
);

export default Layout;