import * as React from 'react';

class Controls extends React.Component {
    render() {
        return(
            <React.Fragment>
                Builder Controls
            </React.Fragment>
        );
    }
}


export default Controls;