import React from 'react';
import styled from 'styled-components';
import BurgerIngredients from '../BurgerIngredieants/BurgerIngredients'

//  Burger = styled.div`
//     width: 500px;
//     height:400px;
// `;

const BreadBottom = styled.div`
    height:50px;
    width: 200px;
    background: linear-gradient(#F08E4A, #e27b36);
    border-radius: 0 0 30px 30px;
    box-shadow: inset -15px 0 #c15711;
    margin: 2% auto;
`;
const BreadTop = styled.div`
    height:50px;
    width: 200px;
    background: linear-gradient(#bc581e, #e27b36);
    border-radius: 50% 50% 0 0;
    box-shadow: inset -15px 0 #c15711;
    margin: 2% auto;
    position: relative;
`;

const Burger = props => {
    console.log('props.ingredients', props.ingredients)
    const transformedIngredients = Object.keys(props.ingredients)
                                    .map(igKey => {
                                        return [...Array(props.ingredients[igKey])].map((_, index) => {
                                            return <BurgerIngredients key={igKey + index} ingredients={igKey}/>
                                        })
                                    });

    console.log('transformedIngredients', transformedIngredients)
    return (
        <div>
            <BreadTop />
            {transformedIngredients}
            <BreadBottom />
        </div>
    )
}

export default Burger;