import React from 'react';
import styled from 'styled-components';

const IngredientsContainer = styled.div`
    align-self: stretch;
    order: 0;
    flex: 0 0 0px;
    flex-grow: 0;
    flex-shrink: 0;
    flex-basis: 90px;
    ${props => {console.log('props', props.children)}}
    ${props => props.children} : {
        width: 200px;
    height: 10px;
    background: linear-gradient(#7f3608, #702e05);
    margin: 2% auto;
    border-radius: 15px;
    }
`;

const Seeds1 = styled.div`
    width: 10%;
    height: 15%;
    position: absolute;
    background-color: white;
    left: 30%;
    top: 50%;
    border-radius: 40%;
    transform: rotate(-20deg);
    box-shadow: inset -2px -3px #c9c9c9;
    &:after{
        content: "";
        width: 100%;
        height: 100%;
        position: absolute;
        background-color: white;
        left: -170%;
        top: -260%;
        border-radius: 40%;
        transform: rotate(60deg);
        box-shadow: inset -1px 2px #c9c9c9;
    }
    :before {
        content: "";
        width: 100%;
        height: 100%;
        position: absolute;
        background-color: white;
        left: 180%;
        top: -50%;
        border-radius: 40%;
        transform: rotate(60deg);
        box-shadow: inset -1px -3px #c9c9c9;
      }
`;
const Seeds2 = styled.div`
    align-self: stretch;
    order: 0;
    flex: 0 0 0px;
    flex-grow: 0;
    flex-shrink: 0;
    flex-basis: 90px;
    :before {
        content: "";
        width: 100%;
        height: 100%;
        position: absolute;
        background-color: white;
        left: 150%;
        top: -130%;
        border-radius: 40%;
        transform: rotate(90deg);
        box-shadow: inset 1px 3px #c9c9c9;
      }
`;

const Meat = styled.div`
    width: 200px;
    height: 10px;
    background: linear-gradient(#7f3608, #702e05);
    margin: 2% auto;
    border-radius: 15px;
`;

const Cheese = styled.div`
    width: 90%;
    height: 4.5%;
    margin: 2% auto;
    background: linear-gradient(#f4d004, #d6bb22);
    border-radius: 20px;
`;

const Salad = styled.div`
    width: 85%;
    height: 7%;
    margin: 2% auto;
    background: linear-gradient(#228c1d, #91ce50);
    border-radius: 20px;
`;
const Bacon = styled.div`
    width: 80%;
    height: 3%;
    background: linear-gradient(#bf3813, #c45e38);
    margin: 2% auto;
`;
const BurgerIngredients = props => {
    return (
        <IngredientsContainer>
            
                {props.ingredients}
            
        </IngredientsContainer>
    )
}

export default BurgerIngredients;