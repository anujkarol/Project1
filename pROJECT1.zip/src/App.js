import * as React from 'react';
import styled from 'styled-components';
import Layout from './components/Layout/Layout'


const AppContainer = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-start;
  align-items: stretch;
  align-content: stretch;
`;


class App extends React.Component {
  render() {
    return (
      <AppContainer>
        <Layout />
      </AppContainer>
    );
  }
}

export default App;
